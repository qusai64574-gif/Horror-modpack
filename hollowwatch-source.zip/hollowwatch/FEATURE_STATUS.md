# Feature status (updated). "WRITTEN, NEVER COMPILED" = code exists but no Gradle build could be run (sandbox cannot reach Fabric Maven; JDK 21 only). Nothing below was run inside Minecraft.
| Feature | Status |
|---|---|
| Core logic (core/*): sanity, stalker state machine, **per-creature AI for all 19 other creatures**, **keyframe animation + 2-tick blending**, mirages, items, **player persistence with v1->v2 migration**, chat bank (108 lines), fog math, cinematic timeline, config, circuit breaker, mesh builder | **COMPLETE AND VERIFIED by unit tests (103 passing, JDK 21)** |
| 20 models + textures + previews, 40 oggs, sounds.json, lang, item defs | COMPLETE AND VERIFIED STATICALLY (validate.py, 1040 checks); visual match APPROXIMATED |
| Entity rendering of JSON models with bone animation (HorrorRenderer, uses MeshBuilder + Anim, anim LOD by distance) | WRITTEN, NEVER COMPILED (26.x renderer API assumed; mesh/UV math itself is tested) |
| Keyframe animation driven by synced clip name | Logic VERIFIED (tests); entity data sync WRITTEN, NEVER COMPILED |
| Fog applied to renderer (FogMixin, require=0) | WRITTEN, NEVER COMPILED; **mixin target/method for 26.3 UNVERIFIED**. If it does not match, game still starts and a HUD-overlay fog fallback (no mixin) is used |
| FOV warp (FovMixin, require=0), camera takeover during cinematic (faces creature, damps movement, no input consumed, hard 4 s timeout, releases on death/screen/disconnect/error) | WRITTEN, NEVER COMPILED |
| Per-creature behaviours (E01-E14, hollow titan, marsh walker) wired into HorrorEntity + Spawner (night/cave/indoor/birch pools, caps by quality, out-of-view placement, Turner in-front exception) | Brains VERIFIED (tests); entity/spawner glue WRITTEN, NEVER COMPILED |
| Death jumpscare + cinematic kill (victim-only packet, camera lock, face sprite slam, FOV warp, shake, glitch noise overlay, stinger, then normal death) | WRITTEN, NEVER COMPILED; **APPROXIMATED**: no scripted lift/drag animation beyond the "grab" clip and a face-slam sprite |
| Items: Pale Mask Shard, Ember Core, Calming Tonic (registry, assets, use/cooldown, drops, duplicate-free reward) | Logic VERIFIED; registration WRITTEN, NEVER COMPILED. Ember Core safe-radius is a stored constant only (**NOT enforced in AI**) |
| Mirages (fake creature silhouette overlay, fake sound, flicker, fake chat, FOV warp; never damaging) | Scheduling VERIFIED; client visuals WRITTEN, NEVER COMPILED. Fake creature is a HUD sprite, not a world entity |
| Look-drain, friends-nearby, sleeping regen, kill restore, shard passive | WRITTEN, NEVER COMPILED |
| Admin panel: all 6 tabs with real server-checked actions (Entities: spawn each, remove near/all, block-break toggle; Debug: stats, orphan cleanup, save, state overlay) | WRITTEN, NEVER COMPILED. Per-entity toggle-by-type and "force state" buttons NOT implemented |
| Saving player data to world folder (`<world>/hollowwatch/<uuid>.properties`, atomic, on join/disconnect/5 min/server stop) | Format/migration/corruption VERIFIED by tests; Fabric wiring WRITTEN, NEVER COMPILED |
| LOD models, first-launch FPS probe | Animation LOD + FPS probe WRITTEN, NEVER COMPILED; cheaper-mesh LOD NOT implemented |
| Per-creature keyframe sets | NOT done: one shared clip library drives every creature (same bone names) |
| Built .jar, build log, .mrpack/CurseForge zip, headless server test, in-game test, FPS measurement | **NOT DONE** |
