# Installation
No installable jar exists yet. After you build it (README):
- Client: Java 25, Fabric Loader 0.19.5+, Fabric API 0.160.x+26.3; put `build/libs/hollowwatch-0.1.0.jar` in `mods/`.
- Dedicated server: same jar + Fabric API in the server `mods/`. Client-only classes are in the client source set and are not loaded on servers (untested).
- Optional performance mods (see MODPACK.md): Sodium and FerriteCore have 26.3 builds; verify the exact file on Modrinth before installing.
- Modpack import: no .mrpack/CurseForge zip was produced (cannot download files or compute hashes here). MODPACK.md lists the verified project pages to assemble one manually.

## Getting the .jar without a local setup (GitHub Actions, free)
1. Create a new GitHub repo, upload the contents of this project (unzip first; keep the `.github` folder).
2. Open the repo's **Actions** tab -> run "build". It runs the unit tests + validator, then builds for Minecraft 26.3 AND 26.1.2.
3. Open the finished run -> **Artifacts** -> download `hollowwatch-mc26.3` or `hollowwatch-mc26.1.2` (the jar is inside).
4. If a job fails, the log lists the compile errors (expected on the first run: the Minecraft-facing code has never been compiled). Paste the log to Claude to get them fixed.
