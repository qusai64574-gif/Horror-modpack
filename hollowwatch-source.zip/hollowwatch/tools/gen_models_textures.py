#!/usr/bin/env python3
"""Generates model JSONs (bones/cubes/UVs) + hand-painted 128x128 textures for every Hollow Watch creature.
Original art, painted procedurally with PIL/numpy. Run: python3 tools/gen_models_textures.py"""
import json, os, random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
ROOT = os.path.join(os.path.dirname(__file__), "..")
RES = os.path.join(ROOT, "src/main/resources/assets/hollowwatch")
PREV = os.path.join(ROOT, "docs/previews")
S = 256
D = 2  # texel density: 2 texels per model unit (face detail); sheet 256x256 (~256 KB), lazy-loaded

def cube_uv_size(w, h, d): return (2*d + 2*w, d + h)

class Sheet:
    def __init__(self): self.x = self.y = self.rowh = 0
    def place(self, w, h, d):
        cw, ch = cube_uv_size(w, h, d)
        if self.x + cw > S: self.x, self.y, self.rowh = 0, self.y + self.rowh, 0
        if self.y + ch > S: raise ValueError("sheet overflow")
        pos = (self.x, self.y); self.x += cw; self.rowh = max(self.rowh, ch); return pos

def faces(u, v, w, h, d):
    return {"top": (u+d, v, w, d), "bottom": (u+d+w, v, w, d), "left": (u, v+d, d, h),
            "front": (u+d, v+d, w, h), "right": (u+d+w, v+d, d, h), "back": (u+2*d+w, v+d, w, h)}

def build(spec):
    """spec: list of (bone, parent, pivot[x,y,z], [(name,size,origin,role)]) -> model dict + face rect table"""
    sh = Sheet(); bones = []; rects = []
    for bone, parent, pivot, cubes in spec:
        out = []
        for name, size, origin, role in cubes:
            w, h, d = size; dn = D if (D <= 2 or role == "hs") else D // 2   # only the face slabs get the high texel density
            u, v = sh.place(int(w*dn), int(h*dn), int(d*dn))
            out.append({"name": name, "size": size, "origin": origin, "uv": [u, v], "ts": dn})
            rects.append((name, role, faces(u, v, int(w*dn), int(h*dn), int(d*dn))))
        bones.append({"name": bone, "parent": parent, "pivot": pivot, "cubes": out})
    return {"texture_size": [S, S], "uv_scale": D, "bones": bones}, rects

# ---------- painting helpers ----------
def noise_fill(img, rect, base, var, seed, speck=None, speck_p=0.0):
    rnd = np.random.RandomState(seed); x, y, w, h = rect
    a = np.array(base, dtype=float)[None, None, :] + rnd.randint(-var, var + 1, (h, w, 1))
    if speck is not None:
        m = rnd.rand(h, w) < speck_p; a[m] = speck
    img.paste(Image.fromarray(np.clip(a, 0, 255).astype("uint8"), "RGB"), (x, y))

def paint_all(img, rects, base, var, seed, speck=None, p=0.0, only=None):
    for i, (name, role, fs) in enumerate(rects):
        if only and role not in only: continue
        for k, r in fs.items(): noise_fill(img, r, base, var, seed + i * 7 + hash(k) % 13, speck, p)

def face_rect(rects, role): 
    for name, r, fs in rects:
        if r == role: return fs["front"]
def rect_of(rects, role, face="front"):
    for name, r, fs in rects:
        if r == role: return fs[face]

def draw_in(img, rect):
    x, y, w, h = rect; layer = Image.new("RGB", (w * 8, h * 8), (0, 0, 0)); return layer, ImageDraw.Draw(layer), (x, y, w, h)
def commit(img, layer, box, base_img=None):
    x, y, w, h = box; img.paste(layer.resize((w, h), Image.LANCZOS), (x, y))

def dots(img, rect, pts, col, k=2):
    x, y, w, h = rect; d = ImageDraw.Draw(img)
    for fx, fy in pts: d.rectangle([x + int(w*fx), y + int(h*fy), x + int(w*fx) + k - 1, y + int(h*fy) + k - 1], fill=col)

def speckle(img, rect, col, p, seed):
    rnd = np.random.RandomState(seed); x, y, w, h = rect
    for yy in range(h):
        for xx in range(w):
            if rnd.rand() < p: img.putpixel((x + xx, y + yy), col)

# ---------- creature definitions ----------
C = {}
def biped(h_body=12, w_body=6, d_body=3, leg=12, arm=12, head=(6, 6, 6), lw=2):
    return [("body", None, [0, leg + h_body, 0], [("torso", [w_body, h_body, d_body], [-w_body/2, leg, -d_body/2], "body")]),
            ("head", "body", [0, leg + h_body, 0], [("head", list(head), [-head[0]/2, leg + h_body, -head[2]/2], "head")]),
            ("arm_l", "body", [w_body/2 + 1, leg + h_body - 1, 0], [("armL", [lw, arm, lw], [w_body/2, leg + h_body - arm - 1, -lw/2], "limb")]),
            ("arm_r", "body", [-w_body/2 - 1, leg + h_body - 1, 0], [("armR", [lw, arm, lw], [-w_body/2 - lw, leg + h_body - arm - 1, -lw/2], "limb")]),
            ("leg_l", "body", [1.5, leg, 0], [("legL", [lw, leg, lw], [0.5, 0, -lw/2], "limb")]),
            ("leg_r", "body", [-1.5, leg, 0], [("legR", [lw, leg, lw], [-0.5 - lw, 0, -lw/2], "limb")])]

# E01/REF-I tall beaked mask giant (scale 1/16 blocks; ~5 blocks tall at render scale 0.7... documented in docs)
import math
def chain(prefix, pts, t, dz, role="limb", step=1, z=0.0):
    """Angled/jointed limb built from unit slabs along a polyline in the front (x,y) plane -> real 3D stair-stepped bends, no rotation needed."""
    out = []; k = 0
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        L = max(abs(x1 - x0), abs(y1 - y0)); n = max(1, int(math.ceil(L / step)))
        for i in range(n):
            cx = x0 + (x1 - x0) * (i + .5) / n; cy = y0 + (y1 - y0) * (i + .5) / n
            if abs(y1 - y0) >= abs(x1 - x0): sz = [t, step, dz]; org = [round((cx - t / 2) * 2) / 2, round((cy - step / 2) * 2) / 2, z - dz / 2]
            else: sz = [step, t, dz]; org = [round((cx - step / 2) * 2) / 2, round((cy - t / 2) * 2) / 2, z - dz / 2]
            out.append(("%s%d" % (prefix, k), sz, org, role)); k += 1
    return out
def taper(prefix, y_top, y_bot, w_top, w_bot, d_top, d_bot, role="body", z=0.0, step=1):
    out = []; n = int(y_top - y_bot)
    for i in range(0, n, step):
        f = (i + .5) / n; w = round((w_top + (w_bot - w_top) * f) * 2) / 2; d = round((d_top + (d_bot - d_top) * f) * 2) / 2
        out.append(("%s%d" % (prefix, i), [w, step, d], [-w / 2, y_top - i - step, z - d / 2], role))
    return out
def cape(prefix, y_top, y_bot, w_top, w_bot, z):
    out = []; n = int(y_top - y_bot); rnd = random.Random(5)
    for i in range(n):
        f = (i + .5) / n; w = round((w_top + (w_bot - w_top) * f + rnd.uniform(-1, 1) * f * 2) * 2) / 2
        out.append(("%s%d" % (prefix, i), [w, 1, 1], [-w / 2, y_top - i - 1, z], "cape"))
    return out
def mask_head():
    """REF-I head: rounded (elliptical) cranium + long tapering beak, built from 1-unit slabs so the silhouette is truly round/3D."""
    cubes = []; slices = []; top = 62.0; N = 26; R = 12
    for i in range(N):
        if i < R: w = 9.0 * math.sqrt(max(0.02, 1 - ((i + 0.5 - R) / R) ** 2)); dd = 5.0 * math.sqrt(max(0.1, 1 - ((i + 0.5 - R) / R) ** 2)) + 1
        else: f = ((i - R + 0.5) / (N - R)) ** 0.8; w = 9.0 - 6.8 * f; dd = 5.5 - 3.0 * f
        w = max(2.0, round(w * 2) / 2); dd = max(2.0, round(dd * 2) / 2)
        cubes.append(("hs%d" % i, [w, 1, dd], [-w / 2, top - (i + 1), -dd / 2 - 3], "hs")); slices.append((("hs%d" % i), i, w))
    return cubes, slices
MASK_CUBES, MASK_SLICES = mask_head()
C["mask_giant"] = dict(scale=1.25, S=512, D=4, spec=[
  ("body", None, [0, 44, 0], taper("tor", 44, 24, 11, 6, 5, 3) + cape("cp", 44, 14, 9, 27, 2.5)),
  ("head", "body", [0, 46, -3], MASK_CUBES),
  ("arm_l", "body", [5, 44, 0], chain("al", [(5, 43), (11, 35), (15, 22), (14, 6)], 2, 2, "limb")),
  ("arm_r", "body", [-5, 44, 0], chain("ar", [(-5, 43), (-11, 35), (-15, 22), (-14, 6)], 2, 2, "limb")),
  ("leg_l", "body", [2, 25, 0], chain("ll", [(2.5, 25), (3.5, 13), (2.5, 0)], 2.5, 2.5, "limb")),
  ("leg_r", "body", [-2, 25, 0], chain("lr", [(-2.5, 25), (-3.5, 13), (-2.5, 0)], 2.5, 2.5, "limb"))])
C["rotted_skull"] = dict(scale=0.75, spec=biped(14, 8, 4, 12, 14, (10, 10, 8), 3))
C["horned_peeper"] = dict(scale=0.6, spec=[
  ("body", None, [0, 6, 0], [("torso", [8, 8, 5], [-4, 0, -2.5], "body")]),
  ("head", "body", [0, 8, 0], [("head", [7, 8, 6], [-3.5, 8, -3], "head")]),
  ("horn_l", "head", [3.5, 15, 0], [("hornL1", [2, 6, 2], [3.5, 14, -1], "horn"), ("hornL2", [5, 2, 2], [5, 19, -1], "horn")]),
  ("horn_r", "head", [-3.5, 15, 0], [("hornR1", [2, 6, 2], [-5.5, 14, -1], "horn"), ("hornR2", [5, 2, 2], [-10, 19, -1], "horn")]),
  ("arm_l", "body", [4, 7, 0], [("armL", [2, 9, 2], [4, -2, -1], "limb")]),
  ("arm_r", "body", [-4, 7, 0], [("armR", [2, 9, 2], [-6, -2, -1], "limb")])])
C["charred_brute"] = dict(scale=1.15, spec=[
  ("body", None, [0, 30, 0], taper("tor", 34, 10, 22, 12, 9, 7, step=3)),
  ("head", "body", [0, 34, -2], [("head", [8, 7, 8], [-4, 33, -6], "head")]),
  ("arm_l", "body", [11, 33, 0], chain("al", [(12, 32), (16, 20), (16, 6)], 6, 6, "limb", step=3)),
  ("arm_r", "body", [-11, 33, 0], chain("ar", [(-12, 32), (-16, 20), (-16, 6)], 6, 6, "limb", step=3)),
  ("leg_l", "body", [4, 10, 0], chain("ll", [(4, 10), (4.5, 0)], 6, 6, "limb", step=3)),
  ("leg_r", "body", [-4, 10, 0], chain("lr", [(-4, 10), (-4.5, 0)], 6, 6, "limb", step=3))])
C["long_crawler"] = dict(scale=1.0, spec=[
  ("body", None, [0, 20, 0], taper("tor", 24, 16, 6, 6, 12, 12, z=0)),
  ("head", "body", [0, 21, -6], [("head", [6, 5, 6], [-3, 17, -13], "head")] + [("fang%d" % i, [0.5, 4, 0.5], [-2.25 + i * 1.5, 13, -12.75], "fang") for i in range(4)]),
  ("arm_l", "body", [3, 22, -4], chain("al", [(3, 22), (9, 34), (14, 20), (16, 0)], 1.5, 1.5, "limb", z=-4)),
  ("arm_r", "body", [-3, 22, -4], chain("ar", [(-3, 22), (-9, 34), (-14, 20), (-16, 0)], 1.5, 1.5, "limb", z=-4)),
  ("leg_l", "body", [2, 18, 5], chain("ll", [(2, 18), (8, 26), (11, 12), (12, 0)], 1.5, 1.5, "limb", z=5)),
  ("leg_r", "body", [-2, 18, 5], chain("lr", [(-2, 18), (-8, 26), (-11, 12), (-12, 0)], 1.5, 1.5, "limb", z=5))])
C["broken_script"] = dict(scale=0.8, spec=[
  ("body", None, [0, 0, 0], [("arch", [14, 28, 3], [-7, 0, -1.5], "head")])])
C["pale_stalker"] = dict(scale=1.0, spec=[
  ("body", None, [0, 22, 0], taper("tor", 36, 14, 5, 3.5, 3, 2.5)),
  ("head", "body", [0, 36, -1], [("head", [5, 6, 5], [-2.5, 36, -3.5], "head")]),
  ("arm_l", "body", [2.5, 35, 0], chain("al", [(2.5, 35), (5, 24), (5.5, 10), (5, 0)], 1.5, 1.5, "limb", step=2)),
  ("arm_r", "body", [-2.5, 35, 0], chain("ar", [(-2.5, 35), (-5, 24), (-5.5, 10), (-5, 0)], 1.5, 1.5, "limb", step=2)),
  ("leg_l", "body", [1.2, 14, 0], chain("ll", [(1.5, 15), (1.8, 7), (1.5, 0)], 2, 2, "limb", step=2)),
  ("leg_r", "body", [-1.2, 14, 0], chain("lr", [(-1.5, 15), (-1.8, 7), (-1.5, 0)], 2, 2, "limb", step=2))])
C["cave_wall_face"] = dict(scale=1.0, spec=[("body", None, [0, 0, 0], [("slab", [16, 16, 2], [-8, 0, -1], "head")])])
C["birch_anomaly"] = dict(scale=2.5, spec=[("body", None, [0, 0, 0], [("log", [16, 16, 16], [-8, 0, -8], "head")])])
C["cave_colossus"] = dict(scale=1.3, spec=[
  ("body", None, [0, 70, 0], [("torso", [10, 12, 6], [-5, 62, -3], "body")]),
  ("head", "body", [0, 74, 0], [("head", [7, 8, 6], [-3.5, 74, -3], "head")]),
  ("arm_l", "body", [6, 72, 0], [("armL", [2, 30, 2], [6, 42, -1], "limb")]),
  ("arm_r", "body", [-6, 72, 0], [("armR", [2, 30, 2], [-8, 42, -1], "limb")]),
  ("leg_l", "body", [3, 62, 0], [("legL", [3, 62, 3], [1.5, 0, -1.5], "limb")]),
  ("leg_r", "body", [-3, 62, 0], [("legR", [3, 62, 3], [-4.5, 0, -1.5], "limb")])])
C["turner"] = dict(scale=0.95, spec=biped(14, 6, 3, 14, 14, (6, 6, 6), 2) + [("neck", "body", [0, 28, 0], [("neck", [2, 4, 2], [-1, 28, -1], "limb")])])
C["follower"] = dict(scale=0.9, spec=biped(12, 6, 3, 13, 18, (5, 6, 5), 2))
C["ceiling_hanger"] = dict(scale=0.9, spec=biped(10, 6, 3, 10, 18, (6, 6, 6), 2))
C["wall_crawler"] = dict(scale=0.9, spec=C["long_crawler"]["spec"])
C["fake_torch"] = dict(scale=0.7, spec=[("body", None, [0, 0, 0], [("stick", [2, 12, 2], [-1, 0, -1], "body"), ("flame", [3, 3, 3], [-1.5, 12, -1.5], "head")])])
C["window_face"] = dict(scale=0.8, spec=[("head", None, [0, 0, 0], [("head", [8, 10, 6], [-4, 0, -3], "head")])])
C["window_hand"] = dict(scale=0.8, spec=[("hand", None, [0, 0, 0], [("palm", [6, 7, 2], [-3, 0, -1], "body"), ("fingers", [6, 5, 1], [-3, 7, -0.5], "limb")])])
C["roof_silhouette"] = dict(scale=1.0, spec=biped(14, 6, 3, 14, 14, (6, 6, 6), 2))
C["hollow_titan"] = dict(scale=1.6, spec=biped(40, 18, 10, 36, 44, (14, 14, 12), 8))
C["marsh_walker"] = dict(scale=1.4, spec=biped(24, 12, 7, 40, 36, (8, 10, 8), 5))

def painter_for(name, img, rects):
    sx, sy = 0, 0
    if name == "mask_giant":
        paint_all(img, rects, (18, 17, 20), 8, 1, (60, 58, 52), 0.06, only={"body", "limb"})
        for nm, role, fs in rects:
            if role == "cape":
                for k, r in fs.items(): noise_fill(img, r, (14, 14, 16), 6, 9, (70, 66, 58), 0.1)
        FWu, FHu = 9, len(MASK_SLICES); FW, FH = FWu * D, FHu * D; SS = 8
        fl = Image.new("RGB", (FW * SS, FH * SS), (196, 170, 118)); d = ImageDraw.Draw(fl); R = 12
        for i, (nm, _, w) in enumerate(MASK_SLICES):   # beak: dark channel with a tan rim = thin curved mouth, U-shaped tip
            if i >= R:
                cw = max(0.35, w * 0.26) * D * SS; cx = FW * SS / 2; y0, y1 = i * D * SS, (i + 1) * D * SS
                d.rectangle([cx - cw / 2, y0, cx + cw / 2, y1], fill=(26, 18, 12))
        d.ellipse([FW*SS/2 - FW*SS*0.16, (FH - 4*D)*SS, FW*SS/2 + FW*SS*0.16, FH*SS], fill=(26, 18, 12)); 
        for ex in (0.27, 0.73):   # huge black oval eyes, tiny pale pupils
            d.ellipse([FW*SS*ex - FW*SS*0.205, D*SS*3.0, FW*SS*ex + FW*SS*0.205, D*SS*9.0], fill=(5, 5, 7))
            d.ellipse([FW*SS*ex - D*SS*0.22, D*SS*6.6, FW*SS*ex + D*SS*0.22, D*SS*6.6 + D*SS*0.5], fill=(228, 224, 210))
        face = fl.resize((FW, FH), Image.LANCZOS); fa = np.array(face).astype(int); rn = np.random.RandomState(3); fa += rn.randint(-12, 13, (FH, FW, 1))
        sp = rn.rand(FH, FW) < 0.07; fa[sp] = np.maximum(fa[sp] - 45, 0); face = Image.fromarray(np.clip(fa, 0, 255).astype("uint8"), "RGB")
        for (nm, role, fs), (_, i, w) in zip([r for r in rects if r[1] == "hs"], MASK_SLICES):
            fx, fy, fw_, fh_ = fs["front"]; cx0 = int((FW - fw_) / 2)
            img.paste(face.crop((cx0, i * D, cx0 + fw_, i * D + fh_)), (fx, fy))
            for k in ("top", "bottom", "left", "right", "back"): noise_fill(img, fs[k], (186, 160, 110), 12, 40 + i, (140, 116, 80), 0.07)
    elif name == "rotted_skull":
        paint_all(img, rects, (74, 54, 38), 14, 4, (40, 28, 20), 0.12)
        hf = rect_of(rects, "head"); layer, d, box = draw_in(img, hf); W, H = layer.size
        layer.paste((86, 62, 44), (0, 0, W, H))
        for i in range(0, H, 14): d.arc([-W*0.1, i - 20, W*1.1, i + 40], 190, 350, fill=(52, 36, 26), width=4)  # wrinkles
        d.ellipse([W*0.52, H*0.08, W*0.98, H*0.50], fill=(4, 3, 3))  # one huge socket
        d.ellipse([W*0.70, H*0.20, W*0.76, H*0.26], fill=(60, 58, 55))
        d.polygon([(W*0.16, H*0.42), (W*0.42, H*0.42), (W*0.29, H*0.68)], fill=(5, 4, 4))  # triangular nose cavity
        for x in range(int(W*0.05), int(W*0.95), 18): d.rectangle([x, H*0.74, x + 7, H*0.98], fill=(36, 24, 18))  # vertical tooth ridges
        commit(img, layer, box)
    elif name == "horned_peeper":
        paint_all(img, rects, (30, 28, 30), 6, 5, (70, 66, 64), 0.05)
        for nm, role, fs in rects:
            if role == "horn":
                for k, r in fs.items(): noise_fill(img, r, (24, 22, 24), 5, 6)
        hf = rect_of(rects, "head"); layer, d, box = draw_in(img, hf); W, H = layer.size
        layer.paste((196, 190, 182), (0, 0, W, H))
        d.ellipse([W*0.16, H*0.26, W*0.40, H*0.46], fill=(20, 18, 20)); d.ellipse([W*0.60, H*0.26, W*0.84, H*0.46], fill=(20, 18, 20))
        d.ellipse([W*0.34, H*0.62, W*0.66, H*0.92], fill=(16, 12, 12))
        commit(img, layer, box)
    elif name == "charred_brute":
        paint_all(img, rects, (44, 42, 44), 12, 7, (150, 40, 22), 0.025)
        rnd = random.Random(8)
        for nm, role, fs in rects:
            for k, r in fs.items():
                x, y, w, h = r; dr = ImageDraw.Draw(img)
                for _ in range(max(2, w * h // 90)):
                    px, py = x + rnd.randrange(w), y + rnd.randrange(h); dr.line([px, py, px + rnd.randint(-5, 5), py + rnd.randint(-5, 5)], fill=(18, 16, 16))
        hf = rect_of(rects, "head"); speckle(img, hf, (170, 50, 28), 0.04, 3)
        dots(img, hf, [(0.25, 0.33), (0.7, 0.33)], (210, 64, 40), 3)
    elif name == "long_crawler":
        paint_all(img, rects, (38, 28, 24), 7, 9)
        hf = rect_of(rects, "head")
        dots(img, hf, [(0.25, 0.33), (0.68, 0.33)], (248, 248, 248), 2)   # two tiny white dot eyes
        for nm, role, fs in rects:
            if role == "fang":
                for k, r in fs.items():
                    x, y, w, h = r; ImageDraw.Draw(img).rectangle([x, y, x + w - 1, y + h - 1], fill=(240, 236, 228))
                    if k in ("front", "left", "right", "back"): ImageDraw.Draw(img).rectangle([x, y + h - 2, x + w - 1, y + h - 1], fill=(196, 60, 60))  # red-tinged tips
    elif name == "broken_script":
        base = np.zeros((S, S, 3), dtype="uint8"); rnd = np.random.RandomState(11)
        base[:] = rnd.randint(0, 40, (S, S, 3)); img.paste(Image.fromarray(base, "RGB"))
        for nm, role, fs in rects:
            x, y, w, h = fs["front"]
            dr = ImageDraw.Draw(img)
            for yy in range(h):
                for xx in range(w):
                    cx = (xx - w/2) / (w/2); top = 1 - (1 - abs(cx)**2)**0.5 if abs(cx) < 1 else 1
                    if yy / h < top * 0.28: img.putpixel((x + xx, y + yy), (rnd.randint(0, 50),) * 3)  # arch-topped silhouette (static outside)
                    elif rnd.rand() < 0.35: img.putpixel((x + xx, y + yy), (rnd.randint(30, 160), rnd.randint(60, 200), rnd.randint(30, 160)))
            ey = y + int(h * 0.28)
            dr.rectangle([x + w//4 - 2, ey, x + w//4 + 2, ey + 3], fill=(40, 255, 70))   # green
            dr.rectangle([x + w//2, ey - 2, x + w//2 + 4, ey + 2], fill=(255, 255, 255))  # white
            dr.rectangle([x + 3*w//4 - 2, ey + 3, x + 3*w//4 + 1, ey + 5], fill=(255, 40, 255))  # magenta, asymmetric
    elif name == "pale_stalker":
        paint_all(img, rects, (22, 20, 22), 6, 12, (50, 46, 44), 0.04)
        hf = rect_of(rects, "head"); x, y, w, h = hf; d = ImageDraw.Draw(img)
        d.rectangle([x, y, x + w - 1, y + h - 1], fill=(206, 202, 190)); speckle(img, hf, (180, 176, 164), 0.1, 5)
        dots(img, hf, [(0.22, 0.3), (0.64, 0.3)], (8, 8, 8), 2); d.line([x + w*0.2, y + h*0.8, x + w*0.8, y + h*0.8], fill=(40, 30, 30), width=1)
    elif name == "cave_wall_face":
        paint_all(img, rects, (96, 94, 92), 10, 13, (60, 58, 56), 0.1)
        hf = rect_of(rects, "head"); x, y, w, h = hf; d = ImageDraw.Draw(img)
        d.ellipse([x + w*0.18, y + h*0.25, x + w*0.38, y + h*0.45], fill=(14, 14, 14)); d.ellipse([x + w*0.62, y + h*0.25, x + w*0.82, y + h*0.45], fill=(14, 14, 14)); d.line([x + w//2, y + h*0.5, x + w//2, y + h*0.75], fill=(24, 24, 24), width=2)
    elif name == "birch_anomaly":
        paint_all(img, rects, (150, 170, 205), 12, 14)
        rnd = random.Random(15)
        for nm, role, fs in rects:
            for k, r in fs.items():
                x, y, w, h = r; d = ImageDraw.Draw(img)
                for _ in range(max(2, w // 3)):
                    px, py = x + rnd.randrange(w - 3), y + rnd.randrange(h - 1); d.rectangle([px, py, px + rnd.randint(1, 3), py], fill=(24, 30, 44))
        x, y, w, h = rect_of(rects, "head"); d = ImageDraw.Draw(img)
        d.rectangle([x + w*0.18, y + h*0.3, x + w*0.38, y + h*0.5], fill=(235, 232, 220)); d.rectangle([x + w*0.62, y + h*0.3, x + w*0.82, y + h*0.5], fill=(235, 232, 220))  # two pale square eyes
    elif name == "cave_colossus":
        paint_all(img, rects, (28, 26, 30), 6, 16, (60, 58, 62), 0.05)
        x, y, w, h = rect_of(rects, "head"); d = ImageDraw.Draw(img); dots(img, (x, y, w, h), [(0.25, 0.33), (0.7, 0.33)], (200, 210, 230), 3)
    elif name == "turner":
        paint_all(img, rects, (36, 34, 38), 8, 17, (80, 76, 80), 0.04)
        x, y, w, h = rect_of(rects, "head"); d = ImageDraw.Draw(img); d.rectangle([x, y, x + w - 1, y + h - 1], fill=(190, 184, 176))
        dots(img, (x, y, w, h), [(0.2, 0.3), (0.65, 0.3)], (10, 10, 10), 3); d.ellipse([x + w*0.25, y + h*0.7, x + w*0.75, y + h*0.95], fill=(12, 8, 8))
    elif name == "follower":
        paint_all(img, rects, (20, 22, 26), 6, 18, (60, 62, 68), 0.05)
        x, y, w, h = rect_of(rects, "head"); dots(img, (x, y, w, h), [(0.2, 0.3), (0.65, 0.3)], (214, 214, 220), 3)
    elif name == "fake_torch":
        paint_all(img, rects, (96, 66, 36), 8, 19, None, 0, only={"body"})
        fr = rect_of(rects, "head"); paint_all(img, rects, (250, 190, 70), 8, 20, (255, 235, 150), 0.15, only={"head"})
    elif name in ("window_face",):
        paint_all(img, rects, (190, 184, 176), 8, 21)
        x, y, w, h = rect_of(rects, "head"); d = ImageDraw.Draw(img); d.ellipse([x + w*0.15, y + h*0.28, x + w*0.38, y + h*0.45], fill=(10, 10, 10)); d.ellipse([x + w*0.62, y + h*0.28, x + w*0.85, y + h*0.45], fill=(10, 10, 10)); d.ellipse([x + w*0.3, y + h*0.65, x + w*0.7, y + h*0.95], fill=(8, 6, 6))
    elif name == "window_hand":
        paint_all(img, rects, (170, 160, 150), 10, 22)
    else:  # ceiling_hanger, wall_crawler, roof_silhouette, hollow_titan, marsh_walker
        base = {"ceiling_hanger": (60, 52, 48), "wall_crawler": (42, 34, 30), "roof_silhouette": (10, 10, 12), "hollow_titan": (54, 60, 54), "marsh_walker": (34, 48, 40)}[name]
        paint_all(img, rects, base, 8, 23, (base[0] + 40, base[1] + 40, base[2] + 40), 0.04)
        for nm, role, fs in rects:
            if role == "head":
                x, y, w, h = fs["front"]; dots(img, (x, y, w, h), [(0.25, 0.33), (0.7, 0.33)], (222, 222, 204), 3)

def mkdirs():
    for p in ("textures/entity", "models/entity"): os.makedirs(os.path.join(RES, p), exist_ok=True)
    os.makedirs(PREV, exist_ok=True)

def preview(name, model, img):
    """Orthographic FRONT render of the real cubes (their front-face texels), scaled to ~560 px tall, plus a head close-up."""
    cubes = [c for bone in model["bones"] for c in bone["cubes"]]; cubes.sort(key=lambda c: -c["origin"][2])
    ys = [c["origin"][1] for c in cubes] + [c["origin"][1] + c["size"][1] for c in cubes]; xs = [c["origin"][0] for c in cubes] + [c["origin"][0] + c["size"][0] for c in cubes]
    miny, maxy, minx, maxx = min(ys), max(ys), min(xs), max(xs); k = 560.0 / max(1.0, maxy - miny)
    W, H = int((maxx - minx) * k) + 40, 600
    def render(cs, kk, ox, oy, w, h):
        cv = Image.new("RGB", (w, h), (14, 14, 18))
        for c in cs:
            cw, ch, dd = c["size"]; x0, y0, z0 = c["origin"]; u, v = c["uv"]; tn = c.get("ts", D)
            fr = img.crop((u + int(dd*tn), v + int(dd*tn), u + int(dd*tn) + int(cw*tn), v + int(dd*tn) + int(ch*tn))).resize((max(1, int(round(cw*kk))), max(1, int(round(ch*kk)))), Image.NEAREST)
            cv.paste(fr, (int(round((x0 - ox) * kk)), int(round(h - 10 - (y0 + ch - oy) * kk))))
        return cv
    full = render(cubes, k, minx, miny, W, H); heads = [c for c in cubes if c["name"].startswith(("hs", "head"))]
    if heads:
        hy0 = min(c["origin"][1] for c in heads); hy1 = max(c["origin"][1] + c["size"][1] for c in heads); hx0 = min(c["origin"][0] for c in heads); hx1 = max(c["origin"][0] + c["size"][0] for c in heads)
        hk = 560.0 / max(1.0, hy1 - hy0); close = render(heads, hk, hx0, hy0, int((hx1 - hx0) * hk) + 20, 600)
        out = Image.new("RGB", (W + close.width + 10, 600), (14, 14, 18)); out.paste(full, (0, 0)); out.paste(close, (W + 10, 0))
    else: out = full
    out.save(os.path.join(PREV, name + ".png"))

def main():
    mkdirs(); info = {}
    global S, D
    for name, c in C.items():
        S = c.get("S", 256); D = c.get("D", 2)
        model, rects = build(c["spec"]); model["scale"] = c["scale"]
        img = Image.new("RGB", (S, S), (0, 0, 0)); painter_for(name, img, rects)
        img.save(os.path.join(RES, "textures/entity", name + ".png"))
        json.dump(model, open(os.path.join(RES, "models/entity", name + ".json"), "w"), indent=1)
        preview(name, model, img); info[name] = len(sum([b["cubes"] for b in model["bones"]], []))
    # overlay / HUD textures (pre-baked sprites for cheap jumpscares)
    gui = os.path.join(RES, "textures/gui"); os.makedirs(gui, exist_ok=True)
    rnd = np.random.RandomState(99)
    Image.fromarray(rnd.randint(0, 255, (64, 64, 4)).astype("uint8"), "RGBA").save(os.path.join(gui, "glitch_noise.png"))
    v = np.zeros((128, 128, 4), dtype="uint8"); yy, xx = np.mgrid[0:128, 0:128]; r = np.sqrt(((xx - 64) / 64.0) ** 2 + ((yy - 64) / 64.0) ** 2)
    v[..., 3] = np.clip((r - 0.45) / 0.6, 0, 1) * 235; Image.fromarray(v, "RGBA").save(os.path.join(gui, "vignette.png"))
    red = v.copy(); red[..., 0] = 120; Image.fromarray(red, "RGBA").save(os.path.join(gui, "vignette_red.png"))
    # sanity HUD: 5-segment mind gauge sprite sheet (original design): 18x18 cells: empty, full, pulse
    hud = Image.new("RGBA", (54, 18), (0, 0, 0, 0)); d = ImageDraw.Draw(hud)
    for i, (fill, edge) in enumerate([(None, (70, 70, 80, 255)), ((120, 200, 255, 255), (230, 245, 255, 255)), ((255, 90, 90, 255), (255, 200, 200, 255))]):
        ox = i * 18; d.ellipse([ox + 2, 2, ox + 15, 15], outline=edge, fill=fill)
        d.line([ox + 9, 4, ox + 9, 13], fill=edge); d.arc([ox + 4, 5, ox + 9, 11], 90, 270, fill=edge); d.arc([ox + 9, 5, ox + 14, 11], 270, 90, fill=edge)
    hud.save(os.path.join(gui, "sanity_icons.png"))
    for n in ("shard", "ember_core", "calming_tonic"):
        os.makedirs(os.path.join(RES, "textures/item"), exist_ok=True)
        it = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(it)
        if n == "shard": d.polygon([(8, 1), (12, 8), (9, 15), (5, 9)], fill=(205, 200, 188, 255), outline=(60, 56, 52, 255))
        if n == "ember_core": d.ellipse([3, 3, 12, 12], fill=(40, 36, 38, 255), outline=(20, 18, 20, 255)); d.point([(6, 6), (9, 8), (7, 10)], fill=(220, 70, 30, 255))
        if n == "calming_tonic": d.rectangle([5, 5, 10, 14], fill=(110, 170, 230, 255), outline=(30, 40, 60, 255)); d.rectangle([6, 2, 9, 4], fill=(150, 110, 70, 255))
        it.save(os.path.join(RES, "textures/item", n + ".png"))
    print("OK", info)
main()
