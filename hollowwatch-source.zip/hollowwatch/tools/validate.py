#!/usr/bin/env python3
"""STATIC validator: models <-> textures <-> Creatures.java <-> lang <-> sounds.json/.ogg <-> registry sounds <-> payload ids <-> fabric.mod.json entrypoints."""
import json, os, re, sys
R = os.path.join(os.path.dirname(__file__), ".."); A = os.path.join(R, "src/main/resources/assets/hollowwatch"); err = []; ok = 0
def need(c, m):
    global ok
    if c: ok += 1
    else: err.append(m)
java = lambda p: open(os.path.join(R, p)).read()
cre = java("src/main/java/dev/hollowwatch/Creatures.java"); ids = re.findall(r'new Def\("(\w+)"', cre)
lang = json.load(open(A + "/lang/en_us.json")); sj = json.load(open(A + "/sounds.json")); reg = java("src/main/java/dev/hollowwatch/ModRegistry.java")
need(len(ids) >= 20, "fewer than 20 creatures")
for i in ids:
    mp, tp = f"{A}/models/entity/{i}.json", f"{A}/textures/entity/{i}.png"
    need(os.path.isfile(mp), "missing model " + i); need(os.path.isfile(tp), "missing texture " + i); need("entity.hollowwatch." + i in lang, "missing lang " + i)
    need(os.path.isfile(os.path.join(R, f"docs/previews/{i}.png")), "missing preview " + i)
    if os.path.isfile(mp):
        m = json.load(open(mp)); need(m["bones"] and all(b["cubes"] for b in m["bones"]), "empty bones " + i); names = [b["name"] for b in m["bones"]]
        need(len(set(names)) == len(names), "dup bones " + i); need(all(b["parent"] is None or b["parent"] in names for b in m["bones"]), "bad parent " + i)
        need("head" in names or i in ("broken_script", "cave_wall_face", "birch_anomaly", "window_hand", "fake_torch", "horned_peeper"), "no head bone " + i)
        for b in m["bones"]:
            for c in b["cubes"]:
                need(c["uv"][0] >= 0 and c["uv"][1] >= 0 and c["uv"][0] < m["texture_size"][0] and c["uv"][1] < m["texture_size"][1], f"uv oob {i}/{c['name']}")
for k, v in sj.items():
    need("hollowwatch.subtitle." + k in lang, "missing subtitle lang " + k); need(f'"{k}"' in reg, "sound not in ModRegistry: " + k)
    for s in v["sounds"]: need(os.path.isfile(f"{A}/sounds/{s['name'].split(':')[1]}.ogg"), "missing ogg " + s["name"])
pay = java("src/main/java/dev/hollowwatch/net/Payloads.java"); pids = re.findall(r'"hollowwatch", "(\w+)"', pay)
cl = java("src/client/java/dev/hollowwatch/client/HollowWatchClient.java") + java("src/main/java/dev/hollowwatch/HollowWatch.java")
for t in ("SanitySync", "FogSync", "Scare", "OpenAdmin", "AdminAction", "AdminOpenRequest"): need(f"{t}.TYPE" in cl, "payload unused/unregistered handler: " + t); need(f"{t}.TYPE, {t}.CODEC" in pay, "payload not registered: " + t)
fm = json.load(open(os.path.join(R, "src/main/resources/fabric.mod.json")))
for ep in fm["entrypoints"].values():
    for c in ep: need(os.path.isfile(os.path.join(R, ("src/client/java/" if ".client." in c else "src/main/java/") + c.replace(".", "/") + ".java")), "missing entrypoint class " + c)
for f in ("textures/gui/sanity_icons.png", "textures/gui/vignette.png", "textures/gui/vignette_red.png", "textures/gui/glitch_noise.png", "textures/item/shard.png", "textures/item/ember_core.png", "textures/item/calming_tonic.png"): need(os.path.isfile(f"{A}/{f}"), "missing " + f)
# new: every sound id used by AI/mirage/admin code is a registered sound with files; item defs; mixin classes; client+server classes exist
used = set(re.findall(r'(?:sound = |r\.sound = |SoundPlayer.play\()"(\w+)"', java("src/main/java/dev/hollowwatch/core/CreatureAI.java"))) | set(re.findall(r'"(\w+)"', re.search(r'FAKE_SOUNDS = \{(.*?)\}', java("src/main/java/dev/hollowwatch/core/Mirage.java")).group(1))) | set(re.findall(r'new ScareOnly\(c, "(\w+)"', java("src/main/java/dev/hollowwatch/core/CreatureAI.java")))
for u in sorted(used): need(u in sj, "sound used in code but not in sounds.json: " + u)
for it in ("shard", "ember_core", "calming_tonic"): need(os.path.isfile(f"{A}/items/{it}.json") and os.path.isfile(f"{A}/models/item/{it}.json") and f"item.hollowwatch.{it}" in lang, "item assets/lang " + it)
core_items = java("src/main/java/dev/hollowwatch/core/Items.java"); need('SHARD = "shard"' in core_items and 'EMBER = "ember_core"' in core_items and 'TONIC = "calming_tonic"' in core_items, "item ids mismatch assets")
mx = json.load(open(os.path.join(R, "src/client/resources/hollowwatch.client.mixins.json")))
for m in mx["client"]: need(os.path.isfile(os.path.join(R, f"src/client/java/dev/hollowwatch/client/mixin/{m}.java")), "missing mixin " + m)
for f in ("core/Anim", "core/CreatureAI", "core/PlayerStore", "core/Mirage", "core/Items", "core/MeshBuilder", "Spawner", "ModItems", "entity/HorrorEntity"): need(os.path.isfile(os.path.join(R, f"src/main/java/dev/hollowwatch/{f}.java")), "missing " + f)
for f in ("HorrorRenderer", "ClientEffects", "SoundPlayer"): need(os.path.isfile(os.path.join(R, f"src/client/java/dev/hollowwatch/client/{f}.java")), "missing " + f)
for t in ("MirageEvent", "PlaySound"): need(f"{t}.TYPE, {t}.CODEC" in pay, "payload not registered: " + t); need(f"{t}.TYPE" in cl or t in java("src/main/java/dev/hollowwatch/client_placeholder.txt") if False else f"{t}.TYPE" in java("src/client/java/dev/hollowwatch/client/HollowWatchClient.java"), "payload handler missing: " + t)
anim_clips = set(re.findall(r'LIB.put\("(\w+)"', java("src/main/java/dev/hollowwatch/core/Anim.java"))); ai_src = java("src/main/java/dev/hollowwatch/core/CreatureAI.java")
for c in set(re.findall(r'anim = "(\w+)"', ai_src)): need(c in anim_clips, "AI uses unknown clip " + c)
print(f"validate: {ok} checks passed, {len(err)} errors")
for e in err: print("  ERROR", e)
sys.exit(1 if err else 0)
