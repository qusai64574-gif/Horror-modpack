#!/bin/sh
# regenerate assets, validate, test, write MANIFEST, zip source project
set -e; cd "$(dirname "$0")/.."
python3 -I tools/gen_models_textures.py >/dev/null; python3 -I tools/gen_sounds.py >/dev/null; python3 -I tools/validate.py
mkdir -p /tmp/hwout && javac -d /tmp/hwout src/main/java/dev/hollowwatch/core/*.java src/test/java/CoreTest.java 2>&1 | grep -v JAVA_TOOL || true
java -cp /tmp/hwout CoreTest 2>&1 | grep -v JAVA_TOOL | tail -1
(find . -type f ! -name MANIFEST.txt ! -path './dist/*' | sort | xargs sha256sum) > MANIFEST.txt
mkdir -p dist && rm -f dist/hollowwatch-source.zip && (cd .. && zip -qr hollowwatch/dist/hollowwatch-source.zip hollowwatch -x 'hollowwatch/dist/*')
unzip -l dist/hollowwatch-source.zip | tail -1
