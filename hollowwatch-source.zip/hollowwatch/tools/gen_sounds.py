#!/usr/bin/env python3
"""Synthesizes original mono 32 kHz .ogg sounds (numpy + ffmpeg) and writes sounds.json. No samples used."""
import json, os, subprocess, wave, tempfile
import numpy as np
SR = 32000; rng = np.random.RandomState(7)
OUT = os.path.join(os.path.dirname(__file__), "../src/main/resources/assets/hollowwatch/sounds")
os.makedirs(OUT, exist_ok=True)
t = lambda d: np.arange(int(SR * d)) / SR
def lp(x, a):  # one-pole lowpass
    y = np.zeros_like(x); s = 0.0
    for i, v in enumerate(x): s += a * (v - s); y[i] = s
    return y
def lp_fast(x, cutoff):
    n = len(x); X = np.fft.rfft(x); f = np.fft.rfftfreq(n, 1 / SR); X[f > cutoff] = 0; return np.fft.irfft(X, n)
def bp(x, lo, hi):
    n = len(x); X = np.fft.rfft(x); f = np.fft.rfftfreq(n, 1 / SR); X[(f < lo) | (f > hi)] = 0; return np.fft.irfft(X, n)
def env(n, a=0.02, r=0.1):
    e = np.ones(n); na = max(1, int(a * SR)); nr = max(1, int(r * SR)); e[:na] = np.linspace(0, 1, na); e[-nr:] = np.minimum(e[-nr:], np.linspace(1, 0, nr)); return e
def norm(x, g=0.8): m = np.max(np.abs(x)) or 1; return x / m * g
def save(name, x):
    x = np.clip(x, -1, 1); w = (x * 32767).astype("<i2")
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f: p = f.name
    with wave.open(p, "wb") as wf: wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(SR); wf.writeframes(w.tobytes())
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", p, "-ac", "1", "-ar", str(SR), "-c:a", "libvorbis", "-q:a", "2", os.path.join(OUT, name + ".ogg")], check=True); os.remove(p)
def vowel(f0, forms, d, vib=0.0):
    tt = t(d); f = f0 * (1 + vib * np.sin(2 * np.pi * 5 * tt)); ph = 2 * np.pi * np.cumsum(f) / SR
    src = sum(np.sin(k * ph) / k for k in range(1, 30)); n = len(tt); X = np.fft.rfft(src); fr = np.fft.rfftfreq(n, 1 / SR); H = np.zeros_like(fr)
    for fc, bw, g in forms: H += g * np.exp(-0.5 * ((fr - fc) / bw) ** 2)
    return np.fft.irfft(X * H, n)

S = {}
def breathing(d=3.0):
    x = rng.randn(int(SR * d)); x = bp(x, 300, 2500); tt = t(d); m = (np.sin(2 * np.pi * 0.45 * tt - 1.2) * 0.5 + 0.5) ** 2; return norm(x * m * 0.9, 0.5)
S["breath"] = [breathing(3.0), breathing(2.4)]
def step(vol=1.0):
    d = 0.25; n = int(SR * d); x = rng.randn(n) * np.exp(-t(d) * 28); x = lp_fast(x, 700) + 0.8 * np.sin(2 * np.pi * 70 * t(d)) * np.exp(-t(d) * 22); return norm(x, 0.8 * vol)
S["step"] = [step(), step(0.9), step(1.0)]
def whisper(d=2.2):
    x = rng.randn(int(SR * d)); x = bp(x, 1200, 6000); tt = t(d)
    syl = (np.sin(2 * np.pi * (3.2 + rng.rand()) * tt + rng.rand() * 6) > 0.1) * 1.0; syl = lp_fast(syl, 18); return norm(x * syl * env(len(x), .2, .4), 0.45)
S["whisper"] = [whisper(2.2), whisper(1.8), whisper(2.6)]
def drone(f, d=5.0):
    tt = t(d); x = np.sin(2 * np.pi * f * tt) + 0.6 * np.sin(2 * np.pi * f * 1.5 * tt + 1) + 0.5 * np.sin(2 * np.pi * f * 1.01 * tt); return norm(x * env(len(tt), 1.2, 1.5), 0.5)
S["drone"] = [drone(55), drone(41.2), drone(73.4)]
def growl(f0=70, d=1.6):
    v = vowel(f0, [(300, 80, 1), (800, 120, .6)], d, 0.08); v *= 1 + 0.8 * np.sin(2 * np.pi * 28 * t(d)); v = np.tanh(v * 3) ; return norm(v * env(len(v), .05, .5), 0.7)
S["growl"] = [growl(70), growl(55, 2.0)]
def rumble(d=3.0):
    x = lp_fast(rng.randn(int(SR * d)), 90) * 8; x *= (1 + 0.5 * np.sin(2 * np.pi * 2.2 * t(d))); return norm(x * env(len(x), .3, .8), 0.9)
S["rumble"] = [rumble(3.0), rumble(4.0)]
def scratch(d=1.4):
    x = rng.randn(int(SR * d)); x = bp(x, 3500, 12000); m = (np.sin(2 * np.pi * 9 * t(d)) > 0.2) * np.linspace(1, 0.2, len(x)); return norm(x * lp_fast(m * 1.0, 40), 0.5)
S["scratch"] = [scratch(1.4), scratch(1.0)]
def knock(n=3):
    d = 0.9; x = np.zeros(int(SR * d))
    for i in range(n):
        s = int(SR * (0.05 + i * 0.28)); k = int(SR * 0.12); tt = np.arange(k) / SR
        x[s:s + k] += (np.sin(2 * np.pi * 150 * tt) + 0.5 * rng.randn(k) * 0.3) * np.exp(-tt * 40)
    return norm(lp_fast(x, 1800), 0.9)
S["knock"] = [knock(3), knock(2)]
def heartbeat(bpm=70):
    d = 60.0 / bpm + 0.0; x = np.zeros(int(SR * d))
    for off, g in ((0.0, 1.0), (0.22, 0.7)):
        s = int(SR * off); k = int(SR * 0.16); tt = np.arange(k) / SR; x[s:s + k] += g * np.sin(2 * np.pi * 52 * tt) * np.exp(-tt * 22)
    return norm(x, 0.9)
S["heartbeat"] = [heartbeat(60), heartbeat(100), heartbeat(140)]
def revreverb(d=2.0):
    x = rng.randn(int(SR * d)) * np.exp(-t(d) * 3); x = bp(x, 400, 3500)[::-1]; return norm(x * env(len(x), 1.5, .05), 0.5)
S["reverse"] = [revreverb(2.0), revreverb(2.8)]
def silence_hit():  # sudden-silence marker: loud thump then true silence
    d = 1.5; x = np.zeros(int(SR * d)); k = int(SR * .3); tt = np.arange(k) / SR; x[:k] = np.sin(2 * np.pi * 45 * tt) * np.exp(-tt * 14); return norm(x, 0.9)
S["silence_cut"] = [silence_hit()]
def scream(f0=640, d=1.4, rough=True):
    v = vowel(f0, [(800, 150, 1), (1500, 200, .8), (2800, 300, .4)], d, 0.03); v *= (1 + (0.5 * np.sin(2 * np.pi * 70 * t(d)) if rough else 0)); v = np.tanh(v * 2.5); f = np.linspace(1.0, 0.7, len(v)); return norm(v * env(len(v), .03, .4), 0.85)
S["scream_distant"] = [lp_fast(scream(620, 1.8), 4500) * 0.45, lp_fast(scream(780, 1.5), 4000) * 0.4]
def help_voice():  # fictional victim "help": formant synthesis  (h) + /e/ + /l/ + /p/-burst; distant and hoarse
    h = bp(rng.randn(int(SR * .10)), 1500, 5000) * 0.3
    e = vowel(250, [(600, 90, 1), (1900, 160, .7), (2600, 200, .3)], 0.38, 0.05) * env(int(SR * .38), .02, .08)
    l = vowel(250, [(350, 70, 1), (1000, 120, .5)], 0.12) * env(int(SR * .12), .02, .05)
    p = rng.randn(int(SR * .03)) * np.exp(-t(.03) * 120) * 0.4
    x = np.concatenate([h, e, l, p, np.zeros(int(SR * .3))]); x = lp_fast(x, 4200); return norm(x, 0.55)
S["help"] = [help_voice(), help_voice()[::1] * 0.9]
for nm, f in (("stalker", 190), ("giant", 110), ("skull", 140), ("crawler", 520), ("glitch", 900), ("colossus", 48), ("turner", 330), ("follower", 260)):
    S["stinger_" + nm] = [norm(np.tanh(vowel(f, [(f * 2, 200, 1), (f * 5, 400, .6)], 1.2, 0.05) * 3 + rng.randn(int(SR * 1.2)) * 0.15 * np.exp(-t(1.2) * 3)) * env(int(SR * 1.2), .005, .6), 0.9)]
def glitchy(d=0.9):
    x = np.zeros(int(SR * d))
    for _ in range(14):
        s = rng.randint(0, len(x) - 2000); k = rng.randint(200, 1800); x[s:s + k] += np.sign(np.sin(np.arange(k) * rng.rand() * 0.2)) * 0.4
    return norm(x, 0.6)
S["glitch"] = [glitchy(), glitchy(1.3)]
S["chime_calm"] = [norm(sum(np.sin(2 * np.pi * f * t(1.6)) * np.exp(-t(1.6) * 3) for f in (660, 990, 1320)), 0.5)]

if __name__ == "__main__":
    js = {}
    for name, variants in S.items():
        events = []
        for i, x in enumerate(variants):
            fn = f"{name}_{i + 1}"; save(fn, x); events.append({"name": f"hollowwatch:{fn}", "stream": name.startswith("drone")})
        js[name] = {"sounds": [{"name": f"hollowwatch:{n['name'].split(':')[1]}", "stream": n["stream"]} for n in events], "subtitle": f"hollowwatch.subtitle.{name}"}
    json.dump(js, open(os.path.join(OUT, "../sounds.json"), "w"), indent=1)
    print(len(js), "sound events,", sum(len(v) for v in S.values()), "files")
