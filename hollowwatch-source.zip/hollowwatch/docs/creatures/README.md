# Creature fidelity (Exact / Approximated / Unknown) — judged from the 12 screenshots you sent, by eye at low resolution
| Creature | Silhouette | Face | Palette | Notes |
|---|---|---|---|---|
| Mask Giant (REF-I) | Approximated: real 3D round head (26 stacked slabs: oval cranium + tapering beak), tapered torso, bat-wing cape-arms, thin legs (200 cubes; heavy, LOD not implemented) | Approximated (huge black ovals, tiny pale pupils, thin beak mouth) | Approximated | Arms/cape shape and exact height UNKNOWN; cape modelled as flat slab |
| Rotted Skull (REF-H) | Approximated (boxy head) | Approximated (one socket, triangle nose, tooth ridges) | Approximated | Only head visible in the shot; body UNKNOWN |
| Horned Peeper (REF-G) | Approximated | Approximated | Approximated | Horns are 2 stepped cubes each, not truly curved |
| Charred Brute (REF-F) | Approximated: wide trapezoid torso, huge dangling arms (rebuilt) | Unknown (head barely visible) | Approximated | Cracks/embers painted |
| Long-Limbed Crawler (REF-E) | Approximated: low body, very long jointed limbs with high elbows above the back, 4 real fang cubes (170 cubes) | Approximated | Approximated | Jointed high elbows only roughly matched |
| Broken Script (REF-D) | Approximated (flat arch slab) | Approximated | Approximated | Glitch overlay = textures/gui/glitch_noise.png (not wired) |
| Pale Stalker (REF-C) | Approximated: thin hunched body, long hanging arms, small pale mask head | Approximated | Approximated | Small in frame; details UNKNOWN |
| Cave-Wall Face (REF-A) | Approximated (flat slab) | Approximated | Approximated | Nose slit position estimated |
| Birch Anomaly (REF-B) | Approximated (single cube) | Approximated | Approximated | Two pale square eyes painted |
| E10-E14 originals | Original designs | Original | Original | No reference |
Previews: `docs/previews/<id>.png` (left: full front view, right: head close-up). Nothing here has been seen in-game.

**Not rebuilt yet (still simple boxes):** Rotted Skull body, Horned Peeper horns (stepped cubes), Cave Colossus, Turner, Follower, and the E13/E14 extras. Only the head/face of REF-H, REF-G, REF-A, REF-B, REF-D was visible in your screenshots.

Behaviours for every creature now exist as tested AI in core/CreatureAI.java (see FEATURE_STATUS).
