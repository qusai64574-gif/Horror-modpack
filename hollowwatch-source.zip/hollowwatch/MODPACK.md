# Modpack (manual assembly — no .mrpack produced)
A .mrpack needs download URLs plus sha1/sha512 of each file; this sandbox cannot download from Modrinth, so no hashes exist and none were invented.
| Mod | Status for 26.3 | Where verified |
|---|---|---|
| Fabric API 0.160.5+26.3 | VERIFIED (release) | https://modrinth.com/mod/fabric-api/version/0.160.5+26.3 |
| Sodium 0.9.2-beta.2 (mc26.3r1) | VERIFIED listed (pre-release) | https://modrinth.com/mod/sodium , https://github.com/CaffeineMC/sodium/releases/tag/mc26.3r1-0.9.2-beta.2 |
| FerriteCore | VERIFIED listed (exact file version NOT checked) | https://modrinth.com/mod/ferrite-core/versions |
| Lithium | NOT verified for 26.3 (latest found: 0.25.3 for 26.2.x) | https://github.com/CaffeineMC/lithium/releases/tag/mc26.2-0.25.3 |
| Hollow Watch | NOT BUILT | this repo |
Iris/shaders: not compatible with Sodium 0.9.2 yet per release notes; do not combine.
