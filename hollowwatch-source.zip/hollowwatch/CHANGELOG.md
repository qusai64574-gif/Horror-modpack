# Changelog
0.1.0 (unreleased): source project, 20 creature models/textures, 23 sound events (40 synthesized files), tested core logic, uncompiled Fabric glue.
0.2.0 (unreleased): added keyframe animation, AI for all creatures, renderer, fog/FOV mixins with fallback, cinematic camera, items, mirages, spawner, persistence, admin Entities/Debug tabs; 103 unit tests.
