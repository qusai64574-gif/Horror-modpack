# Troubleshooting
- First compile will probably fail: glue code uses assumed 26.3 names (Identifier, CustomPacketPayload, HudElementRegistry, permission API, KeyMappingHelper). Fix against the actual 26.3 jars/Fabric API sources.
- Loom id/version in gradle.properties is a placeholder; check https://fabricmc.net/develop for 26.3.
- Missing model/texture/sound logs one warning and uses a fallback box (ModelLoader); a feature that throws 3 times is disabled for the session (CircuitBreaker).
- Fog/FOV mixins target UNVERIFIED 26.3 class/method names. With require=0 a miss is harmless; check the in-game admin Debug overlay (fogMixin=false means the HUD fallback is active) and fix the target names against 26.3 sources.
- HorrorRenderer/ModItems/HorrorEntity use assumed 26.x APIs (render-state extraction, Item.Properties.setId, SynchedEntityData builder); expect compile fixes.
