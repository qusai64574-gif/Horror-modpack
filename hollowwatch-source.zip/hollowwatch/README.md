# Hollow Watch (Minecraft Java 26.3, Fabric) — SOURCE PROJECT, NOT YET COMPILED

> **Honest status:** the build sandbox could not reach Fabric's Maven, Fabric meta, Modrinth or Maven Central and has only Java 21 (26.3 needs Java 25). **No .jar and no .mrpack were produced.** The pure-logic core compiles and passes 103 unit tests on Java 21; assets are generated and statically validated; the Minecraft-facing glue (entities, renderer, networking, HUD, fog/FOV mixins, admin screen, spawner, items, persistence) is written against *assumed* 26.3 APIs and has **never been compiled or run in-game**. Expect to fix compile errors on first build (see TROUBLESHOOTING).

## Loader decision: Fabric
Evidence (web sources checked 2026-10-26):
- Fabric supports 26.3, Loader 0.19.5 (hub.tcno.co Fabric 26.3 guide, checked 18 Sep 2026).
- Fabric API 0.160.5+26.3 release on Modrinth (modrinth.com/mod/fabric-api/version/0.160.5+26.3); 0.160.7+26.3 on CurseForge (file 8902154); CurseForge page also shows 0.165.0+26.3 as latest.
- Sodium: Modrinth page lists 26.3; GitHub tag mc26.3r1-0.9.2-beta.2 (pre-release).
- FerriteCore: Modrinth page lists 26.3.
- Lithium: newest release found is 0.25.3 for 26.2.x -> **not verified for 26.3, excluded**.
- GeckoLib: no 26.3 build verified -> **not used**; animation is done by the mod's own JSON bone model + keyframe code. 
- Java 25 required (Modded Item Upgrader 26.3 release notes). Loom plugin version for 26.3: **UNVERIFIED** (gradle.properties has a placeholder).
Nothing showed Fabric lacking an essential dependency, so Fabric stays the loader.

## Layout
- `src/main/java/dev/hollowwatch/core/` pure logic (Quality, HorrorConfig, Sanity, StalkerBrain, ChatBank, FogController, Cinematic, CircuitBreaker) — tested.
- `src/main` Fabric glue (HollowWatch, ModRegistry, AdminActions, net/Payloads, entity/HorrorEntity) — uncompiled.
- `src/client` client-only code (HUD, fog, scare overlay, admin screen, model loader) — uncompiled; isolated so a dedicated server never loads it.
- `tools/gen_models_textures.py`, `tools/gen_sounds.py` regenerate every model/texture/sound; `tools/validate.py` checks references.
- `docs/previews/*.png` front-view renders of the real cube models.

Build (on a machine with network + JDK 25): `gradle wrapper && ./gradlew build` then fix any API mismatches.
