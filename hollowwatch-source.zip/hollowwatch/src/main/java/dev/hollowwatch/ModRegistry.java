package dev.hollowwatch;
// NOT COMPILED (assumed 26.3 registry API). Entities/items/sounds via vanilla Registry (Fabric registries wrap these).
import dev.hollowwatch.entity.HorrorEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry; import net.minecraft.core.registries.BuiltInRegistries; import net.minecraft.core.registries.Registries; import net.minecraft.resources.Identifier; import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvent; import net.minecraft.world.entity.*; import java.util.*;
public final class ModRegistry {
    public static final Map<String, EntityType<HorrorEntity>> ENTITIES = new LinkedHashMap<>(); public static final Map<String, SoundEvent> SOUNDS = new LinkedHashMap<>();
    private static Identifier id(String p) { return Identifier.fromNamespaceAndPath(HollowWatch.ID, p); }
    public static void init() {
        for (Creatures.Def d : Creatures.ALL) {
            ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, id(d.id()));
            EntityType<HorrorEntity> t = EntityType.Builder.<HorrorEntity>of((type, lvl) -> new HorrorEntity(type, lvl, d), MobCategory.MONSTER).sized(d.width(), d.height()).clientTrackingRange(10).build(key);
            Registry.register(BuiltInRegistries.ENTITY_TYPE, id(d.id()), t); FabricDefaultAttributeRegistry.register(t, HorrorEntity.attrs(d)); ENTITIES.put(d.id(), t);
        }
        for (String s : new String[]{"breath", "step", "whisper", "drone", "growl", "rumble", "scratch", "knock", "heartbeat", "reverse", "silence_cut", "scream_distant", "help", "stinger_stalker", "stinger_giant", "stinger_skull", "stinger_crawler", "stinger_glitch", "stinger_colossus", "stinger_turner", "stinger_follower", "glitch", "chime_calm"})
            SOUNDS.put(s, Registry.register(BuiltInRegistries.SOUND_EVENT, id(s), SoundEvent.createVariableRangeEvent(id(s))));
        // Items (Pale Mask Shard, Ember Core, Calming Tonic) are registered in ModItems (TODO: see FEATURE_STATUS: NOT IMPLEMENTED in this build).
    }
}
