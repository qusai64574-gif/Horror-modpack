package dev.hollowwatch.net;
// NOT COMPILED: written against assumed 26.3 Fabric API payload networking (CustomPacketPayload + StreamCodec). Verify names on first build.
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;

public final class Payloads {
    /** S2C: sanity sync (sent ONLY to the owning player). */
    public record SanitySync(float value, int tier) implements CustomPacketPayload {
        public static final Type<SanitySync> TYPE = new Type<>(Identifier.fromNamespaceAndPath("hollowwatch", "sanity_sync"));
        public static final StreamCodec<RegistryFriendlyByteBuf, SanitySync> CODEC = StreamCodec.composite(ByteBufCodecs.FLOAT, SanitySync::value, ByteBufCodecs.VAR_INT, SanitySync::tier, SanitySync::new);
        @Override public Type<? extends CustomPacketPayload> type() { return TYPE; } }
    /** S2C: fog target, sent only to that player. clear=true -> sudden total clearing. */
    public record FogSync(float intensity, boolean deepCave, boolean forestNight, float creatureProx, boolean clear) implements CustomPacketPayload {
        public static final Type<FogSync> TYPE = new Type<>(Identifier.fromNamespaceAndPath("hollowwatch", "fog_sync"));
        public static final StreamCodec<RegistryFriendlyByteBuf, FogSync> CODEC = StreamCodec.composite(ByteBufCodecs.FLOAT, FogSync::intensity, ByteBufCodecs.BOOL, FogSync::deepCave, ByteBufCodecs.BOOL, FogSync::forestNight, ByteBufCodecs.FLOAT, FogSync::creatureProx, ByteBufCodecs.BOOL, FogSync::clear, FogSync::new);
        @Override public Type<? extends CustomPacketPayload> type() { return TYPE; } }
    /** S2C: death jumpscare / cinematic kill / non-lethal scare. Sent ONLY to the victim; others see nothing. kind: 0 scare, 1 death jumpscare, 2 cinematic kill. */
    public record Scare(String creature, int kind, int lengthTicks) implements CustomPacketPayload {
        public static final Type<Scare> TYPE = new Type<>(Identifier.fromNamespaceAndPath("hollowwatch", "scare"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Scare> CODEC = StreamCodec.composite(ByteBufCodecs.STRING_UTF8, Scare::creature, ByteBufCodecs.VAR_INT, Scare::kind, ByteBufCodecs.VAR_INT, Scare::lengthTicks, Scare::new);
        @Override public Type<? extends CustomPacketPayload> type() { return TYPE; } }
    /** S2C: mirage (non-damaging fake) for ONE player. kind ordinal of core.Mirage.Kind. */
    public record MirageEvent(int kind, String id, int duration) implements CustomPacketPayload {
        public static final Type<MirageEvent> TYPE = new Type<>(Identifier.fromNamespaceAndPath("hollowwatch", "mirage"));
        public static final StreamCodec<RegistryFriendlyByteBuf, MirageEvent> CODEC = StreamCodec.composite(ByteBufCodecs.VAR_INT, MirageEvent::kind, ByteBufCodecs.STRING_UTF8, MirageEvent::id, ByteBufCodecs.VAR_INT, MirageEvent::duration, MirageEvent::new);
        @Override public Type<? extends CustomPacketPayload> type() { return TYPE; } }
    /** S2C: play a sound only for one player (fake sounds / positional-at-owner). */
    public record PlaySound(String sound, double x, double y, double z) implements CustomPacketPayload {
        public static final Type<PlaySound> TYPE = new Type<>(Identifier.fromNamespaceAndPath("hollowwatch", "play_sound"));
        public static final StreamCodec<RegistryFriendlyByteBuf, PlaySound> CODEC = StreamCodec.composite(ByteBufCodecs.STRING_UTF8, PlaySound::sound, ByteBufCodecs.DOUBLE, PlaySound::x, ByteBufCodecs.DOUBLE, PlaySound::y, ByteBufCodecs.DOUBLE, PlaySound::z, PlaySound::new);
        @Override public Type<? extends CustomPacketPayload> type() { return TYPE; } }
    /** S2C: open the admin GUI (server already verified op). */
    public record OpenAdmin(String snapshot) implements CustomPacketPayload {
        public static final Type<OpenAdmin> TYPE = new Type<>(Identifier.fromNamespaceAndPath("hollowwatch", "open_admin"));
        public static final StreamCodec<RegistryFriendlyByteBuf, OpenAdmin> CODEC = StreamCodec.composite(ByteBufCodecs.STRING_UTF8, OpenAdmin::snapshot, OpenAdmin::new);
        @Override public Type<? extends CustomPacketPayload> type() { return TYPE; } }
    /** C2S: admin action. The server re-checks operator permission on EVERY action (see HollowWatch.isOp). */
    public record AdminAction(String action, String arg, String target) implements CustomPacketPayload {
        public static final Type<AdminAction> TYPE = new Type<>(Identifier.fromNamespaceAndPath("hollowwatch", "admin_action"));
        public static final StreamCodec<RegistryFriendlyByteBuf, AdminAction> CODEC = StreamCodec.composite(ByteBufCodecs.STRING_UTF8, AdminAction::action, ByteBufCodecs.STRING_UTF8, AdminAction::arg, ByteBufCodecs.STRING_UTF8, AdminAction::target, AdminAction::new);
        @Override public Type<? extends CustomPacketPayload> type() { return TYPE; } }
    /** C2S: keybind asks for the admin screen; server answers with OpenAdmin only if op. */
    public record AdminOpenRequest() implements CustomPacketPayload {
        public static final Type<AdminOpenRequest> TYPE = new Type<>(Identifier.fromNamespaceAndPath("hollowwatch", "admin_open_request"));
        public static final StreamCodec<RegistryFriendlyByteBuf, AdminOpenRequest> CODEC = StreamCodec.unit(new AdminOpenRequest());
        @Override public Type<? extends CustomPacketPayload> type() { return TYPE; } }

    public static void registerCommon() {
        PayloadTypeRegistry.clientboundPlay().register(SanitySync.TYPE, SanitySync.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(FogSync.TYPE, FogSync.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(Scare.TYPE, Scare.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(MirageEvent.TYPE, MirageEvent.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(PlaySound.TYPE, PlaySound.CODEC);
        PayloadTypeRegistry.clientboundPlay().register(OpenAdmin.TYPE, OpenAdmin.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(AdminAction.TYPE, AdminAction.CODEC);
        PayloadTypeRegistry.serverboundPlay().register(AdminOpenRequest.TYPE, AdminOpenRequest.CODEC);
    }
}
