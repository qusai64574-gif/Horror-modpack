package dev.hollowwatch;
// NOT COMPILED. Pale Mask Shard (hold: passive sanity), Ember Core (drop, place-light safe radius via use), Calming Tonic (use: +30, cooldown). Dedup-free rewards: giveOnce checks the player's claimed set per killed entity.
import net.minecraft.core.Registry; import net.minecraft.core.registries.*; import net.minecraft.resources.*; import net.minecraft.world.item.Item; import net.minecraft.world.InteractionResult; import net.minecraft.server.level.ServerPlayer;
public final class ModItems {
    public static Item SHARD, EMBER, TONIC; private static final java.util.Map<java.util.UUID, Long> TONIC_CD = new java.util.concurrent.ConcurrentHashMap<>();
    private static Item reg(String id, java.util.function.Function<Item.Properties, Item> f) { ResourceKey<Item> k = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(HollowWatch.ID, id)); return Registry.register(BuiltInRegistries.ITEM, k, f.apply(new Item.Properties().setId(k).stacksTo(16))); }
    public static void init() {
        SHARD = reg(dev.hollowwatch.core.Items.SHARD, Item::new); EMBER = reg(dev.hollowwatch.core.Items.EMBER, Item::new);
        TONIC = reg(dev.hollowwatch.core.Items.TONIC, p -> new Item(p) { @Override public InteractionResult use(net.minecraft.world.level.Level l, net.minecraft.world.entity.player.Player pl, net.minecraft.world.InteractionHand h) { if (!l.isClientSide() && pl instanceof ServerPlayer sp) { long now = l.getGameTime(); long cd = TONIC_CD.getOrDefault(sp.getUUID(), 0L); long nxt = dev.hollowwatch.core.Items.useTonic(HollowWatch.sanityOf(sp), now, cd); if (nxt != cd) { TONIC_CD.put(sp.getUUID(), nxt); pl.getItemInHand(h).shrink(1); } } return InteractionResult.SUCCESS; } });
    }
    public static net.minecraft.world.item.ItemStack stack(String core) { return new net.minecraft.world.item.ItemStack(core.equals(dev.hollowwatch.core.Items.SHARD) ? SHARD : core.equals(dev.hollowwatch.core.Items.EMBER) ? EMBER : TONIC); }
}
