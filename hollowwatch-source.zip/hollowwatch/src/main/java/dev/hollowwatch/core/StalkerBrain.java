package dev.hollowwatch.core;
/** Explicit state machine for the Pale-Mask Stalker. Pure logic: caller feeds observations each slow tick (every 10 ticks), reads orders. */
public final class StalkerBrain {
    public enum State { DORMANT, DISTANT_WATCH, APPROACH_HIDDEN, FOLLOW, RETREAT_WHEN_OBSERVED, INVESTIGATE, STALK_CLOSE, ATTACK, ABANDON, RETURN_LATER }
    public static final class Obs { public double dist; public boolean observed, hasCover, targetLight, targetSprinting, targetGrouped, night, targetInCave; public float targetSanity = 100; public boolean hurtByTarget; }
    public State state = State.DORMANT; public int ticksInState, encounterTicks, hits, cooldownTicks;
    private final HorrorConfig cfg; public StalkerBrain(HorrorConfig c) { cfg = c; }
    private void go(State s) { state = s; ticksInState = 0; }
    public boolean wantsToSpawn(Obs o) { return state == State.DORMANT && cooldownTicks <= 0 && !o.observed && o.night; }
    public State tick(Obs o, int dt) {
        ticksInState += dt; if (cooldownTicks > 0) cooldownTicks -= dt;
        if (state != State.DORMANT && state != State.RETURN_LATER) encounterTicks += dt;
        // hard fairness caps: time cap, lethality cap, grouped & lit players discourage it
        if (state != State.DORMANT && state != State.RETURN_LATER && state != State.ABANDON && (encounterTicks > cfg.maxEncounterSeconds * 20 || hits >= maxHits() || o.hurtByTarget && o.targetLight)) { go(State.ABANDON); return state; }
        switch (state) {
            case DORMANT: if (wantsToSpawn(o)) go(State.DISTANT_WATCH); break;
            case DISTANT_WATCH: if (o.observed && ticksInState > 40) go(State.RETREAT_WHEN_OBSERVED); else if (ticksInState > 200 && !o.targetLight && !o.targetGrouped && o.hasCover) go(State.APPROACH_HIDDEN); else if (ticksInState > 1200) go(State.ABANDON); break;
            case APPROACH_HIDDEN: if (o.observed) go(State.RETREAT_WHEN_OBSERVED); else if (o.dist < 12 && o.targetSanity < 70) go(State.FOLLOW); else if (o.dist < 7) go(State.INVESTIGATE); break;
            case FOLLOW: if (o.observed) go(State.RETREAT_WHEN_OBSERVED); else if (o.targetLight || o.targetGrouped) go(State.DISTANT_WATCH); else if (o.dist < 8 && o.targetSanity < 45) go(State.STALK_CLOSE); else if (ticksInState > 900) go(State.INVESTIGATE); break;
            case RETREAT_WHEN_OBSERVED: if (ticksInState > 60 && !o.observed) go(o.dist < 14 ? State.FOLLOW : State.DISTANT_WATCH); break;
            case INVESTIGATE: if (ticksInState > 160) go(o.targetSanity < 60 ? State.STALK_CLOSE : State.ABANDON); break;
            case STALK_CLOSE: if (o.observed && o.dist > 6) go(State.RETREAT_WHEN_OBSERVED); else if (!o.observed && o.dist < 4 && o.targetSanity < 40 && !o.targetLight && !o.targetGrouped) go(State.ATTACK); else if (ticksInState > 700) go(State.ABANDON); break;
            case ATTACK: if (ticksInState > 160 || o.targetSprinting && o.dist > 9 || o.targetLight) go(State.ABANDON); break;
            case ABANDON: if (ticksInState > 40) { cooldownTicks = 20 * 60 * (4 - Math.min(3, cfg.difficulty)); encounterTicks = 0; hits = 0; go(State.RETURN_LATER); } break;
            case RETURN_LATER: if (cooldownTicks <= 0) go(State.DORMANT); break;
        }
        return state;
    }
    public void registerHit() { hits++; }
    public int maxHits() { return Math.max(1, Math.round(5 * cfg.lethalityCap)); } // fair: catches before it must give up
    /** movement speed in blocks/s for the current state (player walk ~4.3, sprint ~5.6) */
    public double speed() { switch (state) { case DISTANT_WATCH: return 0; case APPROACH_HIDDEN: return 2.5; case FOLLOW: return 3.6; case RETREAT_WHEN_OBSERVED: return 6.5; case INVESTIGATE: return 2.0; case STALK_CLOSE: return 3.2; case ATTACK: return 5.2; case ABANDON: return 7.0; default: return 0; } }
}
