package dev.hollowwatch.core;
import java.io.*; import java.nio.charset.StandardCharsets; import java.nio.file.*; import java.util.*;
/** Per-player persistent state with versioning + migration. Atomic write (tmp + move). Corrupt/missing file -> defaults, never a crash. */
public final class PlayerStore {
    public static final int VERSION = 2;
    public static final class Data { public float sanity = 100f; public long lastScareTick = 0; public int encounters = 0; public float personalIntensity = 1f; public boolean shardHeld;
        public String serialize() { return "version=" + VERSION + "\nsanity=" + sanity + "\nlastScareTick=" + lastScareTick + "\nencounters=" + encounters + "\npersonalIntensity=" + personalIntensity + "\n"; } }
    public static Data parse(String text) {
        Data d = new Data(); if (text == null) return d; Map<String, String> m = new HashMap<>();
        try { for (String line : text.split("\\R")) { int i = line.indexOf('='); if (i > 0) m.put(line.substring(0, i).trim(), line.substring(i + 1).trim()); }
            int v = (int) f(m.get("version"), 1);
            d.sanity = HorrorConfig.clamp(f(m.get("sanity"), 100f), 0, 100); d.encounters = (int) HorrorConfig.clamp(f(m.get("encounters"), 0), 0, 1_000_000);
            d.lastScareTick = (long) f(m.get("lastScareTick"), 0); d.personalIntensity = v >= 2 ? HorrorConfig.clamp(f(m.get("personalIntensity"), 1f), 0, 3) : 1f; // v1 -> v2 migration: personalIntensity added
        } catch (Throwable t) { return new Data(); } return d; }
    private static float f(String s, float def) { try { float x = Float.parseFloat(s); return Float.isNaN(x) || Float.isInfinite(x) ? def : x; } catch (Exception e) { return def; } }
    public static Data load(Path dir, UUID id) { try { Path p = dir.resolve(id + ".properties"); if (!Files.isRegularFile(p) || Files.size(p) > 4096) return new Data(); return parse(new String(Files.readAllBytes(p), StandardCharsets.UTF_8)); } catch (Throwable t) { return new Data(); } }
    public static boolean save(Path dir, UUID id, Data d) { try { Files.createDirectories(dir); Path tmp = dir.resolve(id + ".tmp"), fin = dir.resolve(id + ".properties"); Files.write(tmp, d.serialize().getBytes(StandardCharsets.UTF_8)); Files.move(tmp, fin, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); return true; } catch (Throwable t) { System.err.println("[hollowwatch] save failed: " + t); return false; } }
}
