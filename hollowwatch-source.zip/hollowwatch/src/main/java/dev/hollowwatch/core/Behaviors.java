package dev.hollowwatch.core;
/** Per-creature behaviour policies (pure logic, allocation-free). The entity feeds Ctx once per slow tick; Inst returns what to do. pale_stalker uses StalkerBrain instead. */
public final class Behaviors {
    public enum Order { IDLE, FROZEN, APPROACH, CHASE, FLEE, VANISH, DESPAWN }
    public static final class Ctx { public double dist; public boolean observed, targetLight, targetMoving, targetSprinting, grouped, night, inCave, capped; public float sanity = 100; }
    public static final class Act { public Order order = Order.IDLE; public float speedMult = 1; public String sound; public int animState; public boolean teleportBehind, teleportFront, catches, discard;
        void reset() { order = Order.IDLE; speedMult = 1; sound = null; animState = 0; teleportBehind = teleportFront = catches = discard = false; } }
    public static final String[] IDS = {"mask_giant", "rotted_skull", "horned_peeper", "charred_brute", "long_crawler", "broken_script", "pale_stalker", "cave_wall_face", "birch_anomaly", "cave_colossus", "turner", "follower", "ceiling_hanger", "wall_crawler", "fake_torch", "window_face", "window_hand", "roof_silhouette", "hollow_titan", "marsh_walker"};
    public static boolean supports(String id) { for (String s : IDS) if (s.equals(id)) return true; return false; }
    /** ticks the creature may exist before it must leave (hard anti-camping / anti-leak cap). */
    public static int maxAge(String id) { switch (id) { case "turner": return 20 * 14; case "follower": return 20 * 25; case "long_crawler": return 20 * 40; case "rotted_skull": return 20 * 20; case "cave_colossus": return 20 * 90; case "hollow_titan": case "marsh_walker": return 20 * 80; case "mask_giant": return 20 * 120; case "charred_brute": return 20 * 100; default: return 20 * 30; } }

    public static final class Inst {
        public final String id; private final HorrorConfig cfg; public int age, phase, timer, observedTicks, vanishTicks; private final Act act = new Act(); private boolean flippedBehind;
        public Inst(String id, HorrorConfig cfg) { this.id = id; this.cfg = cfg; }
        private boolean scareOnly() { switch (id) { case "horned_peeper": case "broken_script": case "cave_wall_face": case "birch_anomaly": case "ceiling_hanger": case "wall_crawler": case "fake_torch": case "window_face": case "window_hand": case "roof_silhouette": return true; default: return false; } }
        public Act tick(Ctx c, int dt) {
            act.reset(); age += dt; if (c.observed) observedTicks += dt;
            if (age > maxAge(id) || c.capped && !scareOnly()) { return leave(c, dt); }
            if (order() == Order.VANISH) return vanish(dt);
            switch (id) {
                case "mask_giant":
                    if (c.targetLight && c.dist > 6 && age > 200) { act.order = Order.FLEE; act.speedMult = 1.2f; }
                    else if (c.observed) { act.order = Order.FROZEN; }
                    else if (c.sanity < 50 || age > 400) { act.order = Order.CHASE; act.speedMult = c.sanity < 30 ? 1.4f : 1f; act.sound = age % 40 < dt ? "step" : null; act.catches = c.dist < 2.4; }
                    else { act.order = Order.APPROACH; act.speedMult = .6f; }
                    break;
                case "rotted_skull":
                    if (phase == 0) { act.order = Order.IDLE; act.animState = Animator.A_CROUCH; if (!c.observed && c.dist < 7 && (c.inCave || !c.targetLight)) { phase = 1; timer = 160; act.sound = "stinger_skull"; act.animState = Animator.A_SPAWN; } }
                    else { timer -= dt; act.order = Order.CHASE; act.speedMult = 1.2f; act.catches = c.dist < 2; if (c.targetLight || timer <= 0) startVanish(); }
                    break;
                case "horned_peeper":
                    if (phase == 0) { act.animState = Animator.A_CROUCH; if (observedTicks > 15) { phase = 1; timer = 60 + (age * 7 % 40); startVanish(); } }
                    else if (phase == 1) { timer -= dt; act.order = Order.DESPAWN; if (timer > 0) { act.discard = false; } else { act.sound = "knock"; phase = 2; } }
                    else act.discard = true;
                    if (phase == 1) { act.order = Order.IDLE; }
                    break;
                case "charred_brute":
                    act.order = Order.APPROACH; act.speedMult = c.targetLight ? .5f : 1f; act.catches = c.dist < 2.6; act.sound = age % 60 < dt ? "rumble" : null; break;
                case "long_crawler":
                    if (c.grouped && c.targetLight) { act.order = Order.FLEE; break; }
                    timer += dt; if (phase == 0) { act.order = Order.CHASE; act.speedMult = 1.6f; act.catches = c.dist < 2; act.animState = 0; if (timer > 30) { phase = 1; timer = 0; } } else { act.order = Order.IDLE; act.animState = Animator.A_CROUCH; act.sound = timer == dt ? "scratch" : null; if (timer > (c.observed ? 40 : 20)) { phase = 0; timer = 0; } }
                    break;
                case "broken_script":
                    act.order = Order.IDLE; if (age <= dt) act.sound = "glitch"; if (observedTicks > 20 || age > 400) startVanish(); break;
                case "cave_wall_face":
                    act.order = Order.IDLE; act.sound = age % 100 < dt ? "whisper" : null; if (observedTicks > 30) startVanish(); break;
                case "birch_anomaly":
                    act.order = Order.IDLE; if (c.night) act.discard = true; if (observedTicks > 60) startVanish(); break;
                case "cave_colossus":
                    if (c.grouped && age > 600) { act.order = Order.FLEE; break; }
                    if (phase == 0) { act.order = Order.IDLE; act.sound = age % 60 < dt ? "rumble" : null; if (age > 200) phase = 1; }
                    else if (phase == 1) { act.order = Order.APPROACH; act.speedMult = .5f; act.sound = age % 20 < dt ? "rumble" : null; if (c.dist < 14 || age > 800) phase = 2; }
                    else { act.order = Order.CHASE; act.speedMult = 1f; act.catches = c.dist < 3.2; act.sound = age % 20 < dt ? "rumble" : null; }
                    break;
                case "turner":
                    if (phase == 0) { act.order = Order.IDLE; act.animState = Animator.A_NECK_TWIST; timer += dt; if (timer == dt) act.sound = "stinger_turner"; if (timer >= 40) { phase = 1; timer = 0; } }
                    else if (phase == 1) { act.order = Order.CHASE; act.speedMult = 1.7f; if (!flippedBehind) { act.teleportBehind = true; flippedBehind = true; act.sound = "growl"; } act.catches = c.dist < 2; if (age > 20 * 11) { phase = 2; } }
                    else { act.order = Order.FLEE; }
                    break;
                case "follower":
                    if (c.observed && observedTicks > 40) { startVanish(); break; }
                    if (c.observed) { act.order = Order.FLEE; break; }
                    if (c.targetMoving) { act.order = Order.CHASE; act.speedMult = 1.3f; act.sound = age % 8 < dt ? "step" : null; act.catches = c.dist < 2; } else { act.order = Order.IDLE; act.sound = null; } // footsteps & breathing STOP when the player stops
                    break;
                case "hollow_titan": case "marsh_walker":
                    act.order = Order.APPROACH; act.speedMult = id.equals("marsh_walker") ? .6f : .5f; act.sound = age % 40 < dt ? "rumble" : null; act.catches = c.dist < 3.2; if (c.grouped && age > 900) act.order = Order.FLEE; break;
                case "pale_stalker": act.order = Order.IDLE; break;
                default: act.order = Order.IDLE; if (scareOnly() && observedTicks > 20) startVanish();   // window/ceiling/wall scares
            }
            if (scareOnly()) act.catches = false;
            if (order() == Order.VANISH) return vanish(dt);
            return act;
        }
        private Order pending = null; private Order order() { return pending; }
        private void startVanish() { pending = Order.VANISH; vanishTicks = 0; }
        private Act vanish(int dt) { act.reset(); act.order = Order.VANISH; act.animState = Animator.A_VANISH; vanishTicks += dt; if (id.equals("horned_peeper") && phase == 1) { act.order = Order.IDLE; act.animState = 0; act.discard = false; pending = Order.IDLE; if (vanishTicks >= 10) { } } if (vanishTicks >= 10 && !(id.equals("horned_peeper") && phase == 1)) act.discard = true; return act; }
        private Act leave(Behaviors.Ctx c, int dt) { act.reset(); act.order = Order.FLEE; act.speedMult = 1.3f; timer += dt; if (age > maxAge(id) + 60 || c.dist > 40) { act.order = Order.DESPAWN; act.discard = true; } return act; }
    }
}
