package dev.hollowwatch.core;
/** Camera-takeover timeline with a HARD timeout. Client calls tick(); release() on disconnect/death/dimension change/screen change/error. */
public final class Cinematic {
    public static final int HARD_TIMEOUT_TICKS = 80; // 4 s absolute ceiling, regardless of the scripted length
    public final String creature; public final int lengthTicks; private int age; private boolean released;
    public Cinematic(String creature, int lengthTicks) { this.creature = creature; this.lengthTicks = Math.min(lengthTicks, HARD_TIMEOUT_TICKS); }
    public boolean active() { return !released && age < lengthTicks; }
    public void tick() { if (!released && ++age >= lengthTicks) released = true; }
    public void release() { released = true; }
    public float progress() { return Math.min(1f, age / (float) lengthTicks); }
    /** FOV warp multiplier: slam in, hold, ease out. */
    public float fovScale() { float p = progress(); return p < 0.15f ? 1f - 0.45f * (p / 0.15f) : p < 0.8f ? 0.55f + 0.05f * (float) Math.sin(age * 1.7) : 0.55f + 0.45f * ((p - 0.8f) / 0.2f); }
    public float shake() { float p = progress(); return (p < 0.9f ? 1f : (1f - p) * 10f) * 1.5f; }
}
