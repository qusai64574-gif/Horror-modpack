package dev.hollowwatch.core;
import java.io.*; import java.util.Properties;
/** Config with safe defaults. Corrupt/missing file resets to defaults instead of crashing. */
public final class HorrorConfig {
    public boolean enabled = true, safeMode = false, jumpscares = true, cinematics = true, fog = true, sanity = true, fakeChat = true, blockBreaking = false;
    public float intensity = 1.0f, fogIntensity = 1.0f, lethalityCap = 0.6f; // lethalityCap: fraction of max health one encounter may remove before it must abandon
    public int difficulty = 2, maxEncounterSeconds = 150, jumpscareCooldownSeconds = 90, version = 1; public Quality quality = Quality.MEDIUM; public boolean qualityAuto = true;
    public static float clamp(float v, float lo, float hi) { return v < lo ? lo : Math.min(v, hi); }
    public void load(File f) {
        try (Reader r = new FileReader(f)) { Properties p = new Properties(); p.load(r);
            enabled = b(p, "enabled", enabled); safeMode = b(p, "safeMode", safeMode); jumpscares = b(p, "jumpscares", jumpscares); cinematics = b(p, "cinematics", cinematics);
            fog = b(p, "fog", fog); sanity = b(p, "sanity", sanity); fakeChat = b(p, "fakeChat", fakeChat); blockBreaking = b(p, "blockBreaking", blockBreaking);
            intensity = clamp(fl(p, "intensity", intensity), 0, 3); fogIntensity = clamp(fl(p, "fogIntensity", fogIntensity), 0, 2); lethalityCap = clamp(fl(p, "lethalityCap", lethalityCap), 0.1f, 1f);
            difficulty = (int) clamp(fl(p, "difficulty", difficulty), 0, 3); maxEncounterSeconds = (int) clamp(fl(p, "maxEncounterSeconds", maxEncounterSeconds), 20, 600);
            jumpscareCooldownSeconds = (int) clamp(fl(p, "jumpscareCooldownSeconds", jumpscareCooldownSeconds), 10, 1200);
            qualityAuto = b(p, "qualityAuto", qualityAuto); quality = Quality.parse(p.getProperty("quality", quality.name()), quality);
        } catch (Exception e) { System.err.println("[hollowwatch] config unreadable, using defaults: " + e); }
    }
    public void save(File f) {
        Properties p = new Properties(); p.setProperty("version", "1");
        p.setProperty("enabled", "" + enabled); p.setProperty("safeMode", "" + safeMode); p.setProperty("jumpscares", "" + jumpscares); p.setProperty("cinematics", "" + cinematics);
        p.setProperty("fog", "" + fog); p.setProperty("sanity", "" + sanity); p.setProperty("fakeChat", "" + fakeChat); p.setProperty("blockBreaking", "" + blockBreaking);
        p.setProperty("intensity", "" + intensity); p.setProperty("fogIntensity", "" + fogIntensity); p.setProperty("lethalityCap", "" + lethalityCap); p.setProperty("difficulty", "" + difficulty);
        p.setProperty("maxEncounterSeconds", "" + maxEncounterSeconds); p.setProperty("jumpscareCooldownSeconds", "" + jumpscareCooldownSeconds); p.setProperty("quality", quality.name()); p.setProperty("qualityAuto", "" + qualityAuto);
        try (Writer w = new FileWriter(f)) { p.store(w, "Hollow Watch config"); } catch (IOException e) { System.err.println("[hollowwatch] cannot save config: " + e); }
    }
    private static boolean b(Properties p, String k, boolean d) { String v = p.getProperty(k); return v == null ? d : Boolean.parseBoolean(v.trim()); }
    private static float fl(Properties p, String k, float d) { try { return Float.parseFloat(p.getProperty(k, "" + d).trim()); } catch (Exception e) { return d; } }
}
