package dev.hollowwatch.core;
import java.util.*;
/** Per-creature behaviour brains. Pure logic: server feeds Obs each slow tick (10 ticks), reads Order. Every attacker has time cap, counterplay and abandon. */
public final class CreatureAI {
    public static final class Obs { public double dist; public boolean observed, targetLight, targetGrouped, targetSprinting, targetInCave, targetIndoors, night, behindTarget, doorClosed; public float sanity = 100; public boolean hurtByTarget, targetStopped; }
    public static final class Order { public String anim = "idle"; public double speed; public boolean frozen, spawnInFront, spawnBehind, vanish, doScare, doKnock, melee, despawn, cinematicKill, targetWhisper, footstepsAudible; public String sound; public int scareKind = -1; }
    public interface Brain { Order tick(Obs o, int dt); String state(); void reset(); }
    private static abstract class Base implements Brain { final HorrorConfig cfg; int age, stateTicks, hits; String st = "SPAWN"; final Order ord = new Order();
        Base(HorrorConfig c) { cfg = c; }
        Order begin(int dt) { age += dt; stateTicks += dt; ord.anim = "idle"; ord.speed = 0; ord.frozen = ord.spawnInFront = ord.spawnBehind = ord.vanish = ord.doScare = ord.doKnock = ord.melee = ord.despawn = ord.cinematicKill = ord.targetWhisper = ord.footstepsAudible = false; ord.sound = null; ord.scareKind = -1; return ord; }
        void go(String s) { if (s.equals(st)) return; st = s; stateTicks = 0; }
        boolean capped(Obs o) { return age > cfg.maxEncounterSeconds * 20 || hits >= Math.max(1, Math.round(5 * cfg.lethalityCap)); }
        public String state() { return st; } public void reset() { age = stateTicks = hits = 0; st = "SPAWN"; }
        void hit() { hits++; } }
    /** E01: frozen while watched; chases at low sanity; cinematic kill on catch. */
    public static final class MaskGiant extends Base { public MaskGiant(HorrorConfig c) { super(c); }
        public Order tick(Obs o, int dt) { Order r = begin(dt);
            if (capped(o) || o.targetLight && o.dist < 6 || (st.equals("CHASE") && o.targetGrouped && o.dist > 4)) { go("ABANDON"); }
            switch (st) {
                case "SPAWN": r.anim = "spawn_reveal"; if (stateTicks > 20) go("STALK"); break;
                case "STALK": if (o.observed) { r.frozen = true; r.anim = "idle"; } else { r.speed = 2.2; r.anim = "walk"; if (o.sanity < 40 && o.dist < 30) go("CHASE"); } break;
                case "CHASE": if (o.observed && o.dist > 8) { r.frozen = true; } else { r.speed = 6.2; r.anim = "sprint"; r.sound = "stinger_giant"; } if (o.dist < 2.2) { r.cinematicKill = true; r.scareKind = 2; r.anim = "grab"; go("ABANDON"); } else if (stateTicks > 900) go("ABANDON"); break;
                case "ABANDON": r.anim = "vanish"; r.vanish = true; if (stateTicks > 20) { r.despawn = true; } break; }
            return r; } }
    /** E02: lurks in dark/cave; ambushes when player's back is turned; leaves if lit. */
    public static final class RottedSkull extends Base { public RottedSkull(HorrorConfig c) { super(c); }
        public Order tick(Obs o, int dt) { Order r = begin(dt);
            if (capped(o) || o.targetLight) go("ABANDON");
            switch (st) {
                case "SPAWN": case "LURK": st = "LURK"; r.anim = "crouch"; if (!o.observed && o.dist < 10 && o.sanity < 80) go("AMBUSH"); if (stateTicks > 1200) go("ABANDON"); break;
                case "AMBUSH": r.speed = 5.0; r.anim = "run"; r.sound = "growl"; r.melee = o.dist < 1.8; if (o.dist < 1.8) { r.scareKind = 1; hit(); go("LURK"); } if (stateTicks > 160) go("ABANDON"); break;
                case "ABANDON": r.anim = "vanish"; r.vanish = true; r.despawn = stateTicks > 20; break; }
            return r; } }
    /** E03: scare-only window peeper: appears at a window, vanishes when looked at, then knocks once. Never damages. */
    public static final class Peeper extends Base { boolean knocked; public Peeper(HorrorConfig c) { super(c); }
        public Order tick(Obs o, int dt) { Order r = begin(dt);
            switch (st) { case "SPAWN": case "PEEK": st = "PEEK"; r.anim = "peek"; if (o.observed && stateTicks > 20) { r.vanish = true; r.doScare = true; r.scareKind = 0; r.sound = "stinger_glitch"; go("VANISHED"); } else if (stateTicks > 400) go("VANISHED"); break;
                case "VANISHED": r.anim = "vanish"; r.vanish = true; if (stateTicks > 60 && !knocked) { r.doKnock = true; r.sound = "knock"; knocked = true; } if (stateTicks > 160) r.despawn = true; break; }
            return r; } @Override public void reset() { super.reset(); knocked = false; } }
    /** E04: slow, huge, night brute: approaches steadily, gives up at light or when the target is grouped or indoors with closed door. */
    public static final class CharredBrute extends Base { public CharredBrute(HorrorConfig c) { super(c); }
        public Order tick(Obs o, int dt) { Order r = begin(dt);
            if (capped(o) || o.targetLight && o.dist < 10 || o.doorClosed && o.dist < 3 || !o.night) go("ABANDON");
            switch (st) { case "SPAWN": case "APPROACH": st = "APPROACH"; r.speed = 2.4; r.anim = "walk"; r.sound = "step"; if (o.dist < 2.5) go("SMASH"); break;
                case "SMASH": r.anim = "attack"; r.melee = stateTicks == 10; if (stateTicks == 10) hit(); if (stateTicks > 30) go("APPROACH"); break;
                case "ABANDON": r.anim = "vanish"; r.vanish = true; r.despawn = stateTicks > 20; break; }
            return r; } }
    /** E05: fast skitterer: sprints at the target; sprinting players and lit areas shake it; it disengages on timers. */
    public static final class Crawler extends Base { public Crawler(HorrorConfig c) { super(c); }
        public Order tick(Obs o, int dt) { Order r = begin(dt);
            if (capped(o) || o.targetLight && o.dist < 5 || stateTicks > 700 && st.equals("CHASE")) go("ABANDON");
            switch (st) { case "SPAWN": case "SKITTER": st = "SKITTER"; r.anim = "scuttle"; r.speed = 3.0; r.sound = "scratch"; if (o.dist < 22 && o.sanity < 90) go("CHASE"); break;
                case "CHASE": r.anim = "scuttle"; r.speed = o.targetSprinting ? 6.0 : 7.0; r.sound = "stinger_crawler"; if (o.dist < 1.6) { r.melee = true; hit(); go("RECOIL"); } break;
                case "RECOIL": r.speed = -3; r.anim = "scuttle"; if (stateTicks > 40) go("CHASE"); break;
                case "ABANDON": r.anim = "vanish"; r.vanish = true; r.despawn = stateTicks > 20; break; }
            return r; } }
    /** E06: low-sanity apparition. Non-damaging. Flickers and drains a little sanity if observed. */
    public static final class Glitch extends Base { public Glitch(HorrorConfig c) { super(c); }
        public Order tick(Obs o, int dt) { Order r = begin(dt); r.anim = "glitch_flicker"; r.sound = o.observed ? "glitch" : null; if (o.observed && stateTicks > 30) { r.vanish = true; r.doScare = true; r.scareKind = 0; r.despawn = true; } if (stateTicks > 300) r.despawn = true; return r; } }
    /** E08: cave wall face. Whispers when near, scare-only. */
    public static final class WallFace extends Base { public WallFace(HorrorConfig c) { super(c); }
        public Order tick(Obs o, int dt) { Order r = begin(dt); r.frozen = true; r.targetWhisper = o.dist < 12 && stateTicks % 100 == 0; r.sound = r.targetWhisper ? "whisper" : null; if (o.observed && o.dist < 5 && stateTicks > 40) { r.doScare = true; r.scareKind = 0; r.despawn = true; } if (stateTicks > 1800) r.despawn = true; return r; } }
    /** E09: birch block anomaly. Floats; only observed event; vanishes after a few seconds or when approached. */
    public static final class BirchAnomaly extends Base { public BirchAnomaly(HorrorConfig c) { super(c); }
        public Order tick(Obs o, int dt) { Order r = begin(dt); r.frozen = true; r.anim = "idle"; if (o.dist < 10 || stateTicks > 400) { r.vanish = true; r.despawn = true; r.sound = "silence_cut"; } return r; } }
    /** E10: cave colossus: shadow first (footsteps heard, rumble), then hunts. Slow-ish but huge; light/grouped/daylight abandon. */
    public static final class Colossus extends Base { public Colossus(HorrorConfig c) { super(c); }
        public Order tick(Obs o, int dt) { Order r = begin(dt);
            if (capped(o) || !o.targetInCave) go("ABANDON");
            switch (st) { case "SPAWN": case "SHADOW": st = "SHADOW"; r.anim = "idle"; r.sound = "rumble"; r.footstepsAudible = true; if (stateTicks > 400 || o.dist < 24 && o.sanity < 70) go("HUNT"); break;
                case "HUNT": r.speed = 4.4; r.anim = "run"; r.sound = "rumble"; r.footstepsAudible = true; if (o.dist < 3) { r.cinematicKill = true; r.scareKind = 2; r.anim = "grab"; hit(); go("ABANDON"); } else if (stateTicks > 1000) go("ABANDON"); break;
                case "ABANDON": r.anim = "vanish"; r.vanish = true; r.despawn = stateTicks > 20; break; }
            return r; } }
    /** E11: spawns IN FRONT (rate-limited exception), twists neck past 180, sprints behind, then chases. */
    public static final class Turner extends Base { public Turner(HorrorConfig c) { super(c); }
        public Order tick(Obs o, int dt) { Order r = begin(dt);
            if (capped(o) || o.targetLight && st.equals("CHASE") && o.dist > 3) go("ABANDON");
            switch (st) { case "SPAWN": r.spawnInFront = true; r.anim = "spawn_reveal"; if (stateTicks > 20) go("TWIST"); break;
                case "TWIST": r.anim = "neck_twist"; r.sound = "stinger_turner"; if (stateTicks > 40) go("DASH"); break;
                case "DASH": r.anim = "sprint"; r.speed = 9.0; r.spawnBehind = stateTicks <= 10; if (stateTicks > 30) go("CHASE"); break;
                case "CHASE": r.anim = "sprint"; r.speed = o.targetSprinting ? 5.5 : 6.4; if (o.dist < 1.8) { r.melee = true; r.scareKind = 1; hit(); go("ABANDON"); } else if (stateTicks > 600) go("ABANDON"); break;
                case "ABANDON": r.anim = "vanish"; r.vanish = true; r.despawn = stateTicks > 20; break; }
            return r; } }
    /** E12: fast pursuer from behind. Breathing and footsteps audible only while the target is moving: they STOP when the player stops. */
    public static final class Follower extends Base { public Follower(HorrorConfig c) { super(c); }
        public Order tick(Obs o, int dt) { Order r = begin(dt);
            if (capped(o) || o.targetLight || o.targetGrouped) go("ABANDON");
            switch (st) { case "SPAWN": case "TRAIL": st = "TRAIL"; r.anim = o.targetStopped ? "idle" : "walk"; r.footstepsAudible = !o.targetStopped; r.sound = o.targetStopped ? null : "step"; r.speed = o.targetStopped ? 0 : 4.0; if (o.sanity < 55 && o.dist < 10) go("RUSH"); if (stateTicks > 1200) go("ABANDON"); break;
                case "RUSH": r.anim = "sprint"; r.speed = 7.0; r.sound = "stinger_follower"; r.footstepsAudible = true; if (o.dist < 1.7) { r.melee = true; hit(); go("TRAIL"); } if (stateTicks > 300) go("ABANDON"); break;
                case "ABANDON": r.anim = "vanish"; r.vanish = true; r.despawn = stateTicks > 20; break; }
            return r; } }
    /** Generic scare-only (ceiling hanger, wall crawler, fake torch, window face/hand, roof silhouette): shows itself, one rate-limited scare, leaves. */
    public static final class ScareOnly extends Base { final String stinger; public ScareOnly(HorrorConfig c, String s) { super(c); stinger = s; }
        public Order tick(Obs o, int dt) { Order r = begin(dt); r.frozen = true; r.anim = "peek"; if (o.observed && stateTicks > 15) { r.doScare = true; r.scareKind = 0; r.sound = stinger; r.vanish = true; r.despawn = true; } if (stateTicks > 600) r.despawn = true; return r; } }
    /** Big original creatures (hollow titan, marsh walker): slow, huge, hunt by line of sight, abandon on light/group/timer, no block breaking unless opt-in (server decides). */
    public static final class BigWalker extends Base { public BigWalker(HorrorConfig c) { super(c); }
        public Order tick(Obs o, int dt) { Order r = begin(dt); if (capped(o) || o.targetLight && o.dist < 8 || o.targetGrouped && o.dist > 10) go("ABANDON");
            switch (st) { case "SPAWN": case "WANDER": st = "WANDER"; r.speed = 1.5; r.anim = "walk"; r.sound = "rumble"; if (o.dist < 28 && !o.observed) go("HUNT"); break;
                case "HUNT": r.speed = 3.8; r.anim = "run"; r.sound = "rumble"; if (o.dist < 3.5) { r.melee = true; hit(); go("WANDER"); } if (stateTicks > 900) go("ABANDON"); break;
                case "ABANDON": r.anim = "vanish"; r.vanish = true; r.despawn = stateTicks > 20; break; }
            return r; } }
    public static Brain create(String id, HorrorConfig c) {
        switch (id) { case "mask_giant": return new MaskGiant(c); case "rotted_skull": return new RottedSkull(c); case "horned_peeper": return new Peeper(c); case "charred_brute": return new CharredBrute(c); case "long_crawler": return new Crawler(c);
            case "broken_script": return new Glitch(c); case "cave_wall_face": return new WallFace(c); case "birch_anomaly": return new BirchAnomaly(c); case "cave_colossus": return new Colossus(c); case "turner": return new Turner(c); case "follower": return new Follower(c);
            case "ceiling_hanger": return new ScareOnly(c, "stinger_skull"); case "wall_crawler": return new ScareOnly(c, "scratch"); case "fake_torch": return new ScareOnly(c, "whisper"); case "window_face": return new ScareOnly(c, "stinger_glitch"); case "window_hand": return new ScareOnly(c, "scratch"); case "roof_silhouette": return new ScareOnly(c, "drone");
            case "hollow_titan": case "marsh_walker": return new BigWalker(c); default: return null; } }
}
