package dev.hollowwatch.core;
import java.util.*;
/** Zero-delay keyframe animation. Clips are baked keyframe tracks (rx,ry,rz in degrees; px,py,pz in model units). Crossfade <= 2 ticks. Allocation-free sampling. Pure Java. */
public final class Animator {
    public static final int CH = 6; public static final float BLEND_TICKS = 2f;
    public static final String[] BONES = {"body", "head", "neck", "arm_l", "arm_r", "leg_l", "leg_r", "horn_l", "horn_r", "hand"};
    public static final class Track { final float[] t; final float[][] v; Track(float[] t, float[][] v) { this.t = t; this.v = v; }
        void sample(float time, float[] out) { int n = t.length; if (time <= t[0]) { System.arraycopy(v[0], 0, out, 0, CH); return; } if (time >= t[n - 1]) { System.arraycopy(v[n - 1], 0, out, 0, CH); return; }
            int i = 1; while (t[i] < time) i++; float f = (time - t[i - 1]) / (t[i] - t[i - 1]); for (int c = 0; c < CH; c++) out[c] = v[i - 1][c] + (v[i][c] - v[i - 1][c]) * f; } }
    public static final class Clip { public final String name; public final float length; public final boolean loop; final Map<String, Track> tracks = new HashMap<>();
        Clip(String n, float len, boolean loop) { name = n; length = len; this.loop = loop; }
        void sample(String bone, float time, float[] out) { Track tr = tracks.get(bone); if (tr == null) { Arrays.fill(out, 0); return; } float tt = loop ? (time % length + length) % length : Math.min(Math.max(time, 0), length); tr.sample(tt, out); } }
    interface Gen { void at(String bone, float p, float[] o); }
    private static Clip bake(String name, float len, boolean loop, Gen g) {
        Clip c = new Clip(name, len, loop); int N = 9; for (String b : BONES) { float[] t = new float[N]; float[][] v = new float[N][CH];
            for (int i = 0; i < N; i++) { t[i] = len * i / (N - 1); g.at(b, loop ? i / (float) (N - 1) : i / (float) (N - 1), v[i]); } c.tracks.put(b, new Track(t, v)); } return c; }
    private static float s(float p) { return (float) Math.sin(p * 2 * Math.PI); }
    private static float ease(float p) { return p * p * (3 - 2 * p); }
    /** Builds the 12 required clips. amp scales gait (big creatures stride less/slower), twist = max neck rotation. */
    public static Map<String, Clip> library(float amp, float twistDeg) {
        Map<String, Clip> m = new LinkedHashMap<>();
        m.put("idle", bake("idle", 40, true, (b, p, o) -> { switch (b) { case "body": o[0] = 1.5f * s(p); break; case "head": o[1] = 3 * s(p + .2f); o[0] = 1.5f * s(p + .5f); break; case "arm_l": case "arm_r": o[0] = 2 * s(p + (b.equals("arm_l") ? 0 : .5f)); break; default: } }));
        m.put("walk", bake("walk", 20, true, (b, p, o) -> { switch (b) { case "leg_l": o[0] = 32 * amp * s(p); break; case "leg_r": o[0] = -32 * amp * s(p); break; case "arm_l": o[0] = -24 * amp * s(p); break; case "arm_r": o[0] = 24 * amp * s(p); break; case "body": o[2] = 2 * s(p); o[4] = .3f * Math.abs(s(p)); break; case "head": o[1] = -2 * s(p); break; default: } }));
        m.put("run", bake("run", 12, true, (b, p, o) -> { switch (b) { case "leg_l": o[0] = 52 * amp * s(p); break; case "leg_r": o[0] = -52 * amp * s(p); break; case "arm_l": o[0] = -48 * amp * s(p); break; case "arm_r": o[0] = 48 * amp * s(p); break; case "body": o[0] = 12; break; case "head": o[0] = -8; break; default: } }));
        m.put("sprint", bake("sprint", 8, true, (b, p, o) -> { switch (b) { case "leg_l": o[0] = 68 * amp * s(p); break; case "leg_r": o[0] = -68 * amp * s(p); break; case "arm_l": o[0] = -62 * amp * s(p); break; case "arm_r": o[0] = 62 * amp * s(p); break; case "body": o[0] = 22; break; case "head": o[0] = -14; break; default: } }));
        m.put("attack", bake("attack", 12, false, (b, p, o) -> { float a = (float) Math.sin(Math.PI * p); switch (b) { case "arm_l": case "arm_r": o[0] = -100 * a; break; case "body": o[0] = 16 * a; break; case "head": o[0] = 10 * a; break; default: } }));
        m.put("grab", bake("grab", 20, true, (b, p, o) -> { switch (b) { case "arm_l": o[0] = -85; o[2] = -8; break; case "arm_r": o[0] = -85; o[2] = 8; break; case "body": o[0] = 20 + 2 * s(p); break; case "head": o[0] = 14; break; default: } }));
        m.put("look", bake("look", 40, true, (b, p, o) -> { switch (b) { case "head": o[1] = 42 * s(p); o[0] = 4 * s(p * 2); break; case "neck": o[1] = 14 * s(p); break; default: } }));
        m.put("crouch", bake("crouch", 30, true, (b, p, o) -> { switch (b) { case "body": o[0] = 38; o[4] = -6; break; case "head": o[0] = -26; break; case "leg_l": o[0] = -50; break; case "leg_r": o[0] = -50; break; case "arm_l": o[0] = -30; break; case "arm_r": o[0] = -30; break; default: } o[0] += 1.2f * (b.equals("body") ? s(p) : 0); }));
        m.put("neck_twist", bake("neck_twist", 40, false, (b, p, o) -> { float e = p < .55f ? .12f * ease(p / .55f) : .12f + .88f * ease((p - .55f) / .45f); switch (b) { case "neck": o[1] = twistDeg * e; break; case "head": o[1] = twistDeg * .8f * e; o[2] = 6 * e; break; default: } }));
        m.put("spawn_reveal", bake("spawn_reveal", 16, false, (b, p, o) -> { float e = 1 - ease(p); switch (b) { case "body": o[0] = 40 * e; o[4] = -8 * e; break; case "head": o[0] = 60 * e; break; case "arm_l": case "arm_r": o[0] = 30 * e; break; default: } }));
        m.put("vanish", bake("vanish", 10, false, (b, p, o) -> { if (b.equals("body")) o[4] = -30 * ease(p); if (b.equals("head")) o[0] = 25 * ease(p); }));
        m.put("death", bake("death", 20, false, (b, p, o) -> { float e = ease(p); switch (b) { case "body": o[0] = 90 * e; o[4] = -6 * e; break; case "head": o[0] = 30 * e; break; case "arm_l": case "arm_r": o[0] = -40 * e; break; default: } }));
        return m;
    }
    /** anim state codes synced from the server entity. */
    public static final int A_NONE = 0, A_ATTACK = 1, A_GRAB = 2, A_LOOK = 3, A_CROUCH = 4, A_NECK_TWIST = 5, A_SPAWN = 6, A_VANISH = 7, A_DEATH = 8;
    private static final String[] BY_STATE = {null, "attack", "grab", "look", "crouch", "neck_twist", "spawn_reveal", "vanish", "death"};
    public static String choose(int state, double speed) { if (state > 0 && state < BY_STATE.length) return BY_STATE[state]; return speed < 0.02 ? "idle" : speed < 0.12 ? "walk" : speed < 0.3 ? "run" : "sprint"; }

    private final Map<String, Clip> lib; private Clip cur, prev; private float curStart, prevStart, blendStart = -100; private final float[] a = new float[CH], b = new float[CH];
    public Animator(Map<String, Clip> library) { lib = library; cur = lib.get("idle"); } // starts in idle: never a T-pose
    public String current() { return cur.name; }
    public void play(String clip, float now) { if (clip == null || cur.name.equals(clip)) return; Clip n = lib.get(clip); if (n == null) return; prev = cur; prevStart = curStart; cur = n; curStart = now; blendStart = now; }
    /** writes pose for bone into out[0..5]; never allocates. */
    public void pose(String bone, float now, float[] out) {
        cur.sample(bone, now - curStart, a); float w = prev == null ? 1f : Math.min(1f, (now - blendStart) / BLEND_TICKS);
        if (w >= 1f) { System.arraycopy(a, 0, out, 0, CH); return; } prev.sample(bone, now - prevStart, b); for (int i = 0; i < CH; i++) out[i] = b[i] + (a[i] - b[i]) * w; }
}
