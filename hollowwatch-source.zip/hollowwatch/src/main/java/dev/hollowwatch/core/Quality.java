package dev.hollowwatch.core;
/** Quality presets. Every cap scales with the preset. Pure Java (no Minecraft imports). */
public enum Quality {
    POTATO(2, 0, 4, 6, 0.5f, false), LOW(3, 8, 8, 10, 0.7f, false), MEDIUM(4, 24, 12, 16, 0.85f, false), HIGH(6, 64, 16, 24, 1.0f, true);
    public final int maxHorrorEntitiesPerPlayer, groundMistParticles, maxSoundsInFlight, animUpdateDistance; public final float fogDetail; public final boolean shaders;
    Quality(int e, int p, int s, int a, float f, boolean sh) { maxHorrorEntitiesPerPlayer = e; groundMistParticles = p; maxSoundsInFlight = s; animUpdateDistance = a; fogDetail = f; shaders = sh; }
    public static Quality fromFps(double fps) { return fps < 25 ? POTATO : fps < 45 ? LOW : fps < 90 ? MEDIUM : HIGH; }
    public static Quality parse(String s, Quality def) { try { return valueOf(s.trim().toUpperCase()); } catch (Exception e) { return def; } }
}
