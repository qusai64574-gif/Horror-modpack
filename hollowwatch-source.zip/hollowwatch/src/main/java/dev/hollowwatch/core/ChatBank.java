package dev.hollowwatch.core;
import java.util.*;
/** 108 original unsettling lines in 12 categories. Lines never claim knowledge the game cannot observe (no coordinates, names, items, real-world info).
 *  Per-player cooldown + no repeats until a category is exhausted. Delivery is private (to one player only). */
public final class ChatBank {
    public static final Map<String, String[]> LINES = new LinkedHashMap<>();
    static {
        LINES.put("watching", new String[]{"...still here.", "Don't turn around yet.", "The trees lean closer when you look away.", "Eyes. Many, patient, unblinking.", "Keep walking. It likes that.", "You felt that, didn't you?", "Something stopped breathing when you did.", "Between the trunks. No, further left.", "It has all night."});
        LINES.put("pursuit", new String[]{"Faster.", "It learned your rhythm.", "Run. Stop. Run. It enjoys the pauses.", "Behind. Always behind.", "Don't count the steps. They're not yours.", "Closer than the last time you checked.", "The ground remembers weight.", "You can't outwalk what doesn't tire.", "Light. Find light."});
        LINES.put("isolation", new String[]{"Nobody is coming.", "The quiet is not empty.", "Even the wind went home.", "Alone is a loud word out here.", "No one else is listening. Almost no one.", "How far from warmth are you?", "The night is wider than your torch.", "Call out. See who answers.", "Quiet. Too quiet to be true."});
        LINES.put("mockery", new String[]{"Nice shelter. Thin walls.", "Brave. Pointless, but brave.", "Keep digging. Deeper is its favorite place.", "That sword is for show.", "Count your torches. Count again.", "You flinch so honestly.", "Adorable, the way you check the corners.", "Did you think the door was a promise?", "Run along."});
        LINES.put("whispers", new String[]{"shhh", "listen... listen...", "Almost... almost...", "come closer, closer", "the third one is wrong", "we heard you laugh", "not yet, not yet", "ssh... it's looking", "hush now"});
        LINES.put("false_comfort", new String[]{"It's gone. Probably.", "Safe now. Mostly.", "Nothing there. Look again, you'll see nothing.", "You imagined it. Everyone does.", "Sleep. It's fine.", "That sound was only the house settling.", "Relax. The dark is friendly tonight.", "See? Nothing happened.", "Breathe. Slower.", "Not tonight.", "Goodnight.", "Until next time.", "Gone for now."});
        LINES.put("environment", new String[]{"The mist is thicker than it was.", "Every shadow here has an edge.", "The leaves stopped moving.", "Cold, suddenly. Notice it.", "The birches are too pale tonight.", "Stone listens.", "The cave exhales.", "Torches burn lower down here.", "Something's wrong with the sky."});
        LINES.put("glitch", new String[]{"E̷r̷r̷o̷r̷: world not found", "ref://null / null / null", "tick tick tick tick tick", "[missing texture]", "undefined is standing behind you", "!!SCRIPT BREAK!!", "reload reload reload", "this line already happened", "NaN"});
        LINES.put("dread", new String[]{"It isn't hunting. It's waiting.", "Some doors only open from the dark side.", "You won't hear it end.", "Dawn is a long way off.", "Everything heavy is coming this way.", "The count is almost up.", "A little longer.", "It has been practicing your name.", "This was always going to be a long night."});
        LINES.put("warnings", new String[]{"Stay out of the dark.", "Don't look at it.", "Keep your light lit.", "Stay together.", "Doors help. Walls help more.", "Sprint breaks its line.", "Don't mine toward the sound.", "It hates fire. Mostly.", "Group up before nightfall."});
        LINES.put("curiosity", new String[]{"What are you looking at?", "Did that block move?", "That tree wasn't there.", "Why is it quiet?", "Is that a footprint?", "Whose torch is that?", "Did you leave that open?", "Hello? Anyone?", "Check behind you. Go on."});
        LINES.put("lost", new String[]{"This isn't the way you came.", "Same tree. Same tree. Same tree.", "The path rearranged itself.", "Which way was home?", "You walked in a circle. We counted.", "Nothing here looks familiar anymore.", "Lost is only a feeling. Mostly.", "The map is lying.", "Turn back? Turn which way?"});
    }
    public static int total() { int n = 0; for (String[] a : LINES.values()) n += a.length; return n; }
    private final Map<String, ArrayDeque<Integer>> bag = new HashMap<>(); private final Random rnd; private long nextAllowedTick = 0; private final int cooldownTicks;
    public ChatBank(long seed, int cooldownTicks) { rnd = new Random(seed); this.cooldownTicks = cooldownTicks; }
    /** @return a line or null if on cooldown. Never repeats until the category is exhausted (shuffled bag). */
    public String next(String cat, long nowTick) {
        String[] arr = LINES.get(cat); if (arr == null || nowTick < nextAllowedTick) return null;
        ArrayDeque<Integer> q = bag.computeIfAbsent(cat, k -> new ArrayDeque<>());
        if (q.isEmpty()) { List<Integer> idx = new ArrayList<>(); for (int i = 0; i < arr.length; i++) idx.add(i); Collections.shuffle(idx, rnd); q.addAll(idx); }
        nextAllowedTick = nowTick + cooldownTicks; return arr[q.poll()];
    }
}
