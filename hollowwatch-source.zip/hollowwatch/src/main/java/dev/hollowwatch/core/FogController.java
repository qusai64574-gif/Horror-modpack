package dev.hollowwatch.core;
/** Client-side fog target math + smoothing. Output is applied via the vanilla fog path (start/end/color). Never full blindness unless allowed. */
public final class FogController {
    public float start = 64, end = 128, r = .6f, g = .6f, b = .6f; // current
    private float tStart = 64, tEnd = 128, tR = .6f, tG = .6f, tB = .6f;
    public float minEnd = 14; // survivable floor (blocks)
    public void target(float baseStart, float baseEnd, boolean caveDeep, boolean forestNight, float sanityThickening, float redTint, float creatureProx01, float intensity, boolean allowBlind) {
        float k = 1f; if (forestNight) k += 0.9f; if (caveDeep) k += 1.2f; k += sanityThickening * 0.9f + creatureProx01 * 0.8f; k = 1f + (k - 1f) * intensity;
        tEnd = Math.max(allowBlind ? 4f : minEnd, baseEnd / k); tStart = Math.min(tEnd - 4f, baseStart / (k * 1.6f));
        float dark = caveDeep ? 0.06f : forestNight ? 0.14f : 0.55f; tR = dark + redTint * 0.45f; tG = dark * (1f - redTint * 0.8f); tB = dark * (1f - redTint * 0.8f) + (forestNight ? 0.04f : 0f);
        if (!forestNight && !caveDeep && sanityThickening == 0 && creatureProx01 == 0) { tR = tG = tB = 0.62f; }
    }
    public void clearInstantly() { tStart = 120; tEnd = 256; tR = tG = tB = 0.7f; } // "sudden total clearing" for contrast
    public void step(float dtSeconds) { float a = 1f - (float) Math.exp(-dtSeconds * 1.4f); start += (tStart - start) * a; end += (tEnd - end) * a; r += (tR - r) * a; g += (tG - g) * a; b += (tB - b) * a; }
}
