package dev.hollowwatch.core;
import java.util.*;
/** Per-feature circuit breaker: after N failures a feature is disabled for the session, with exactly one logged warning. */
public final class CircuitBreaker {
    private final Map<String, Integer> fails = new HashMap<>(); private final Set<String> tripped = new HashSet<>(); private final int limit; public CircuitBreaker(int limit) { this.limit = limit; }
    public boolean ok(String feature) { return !tripped.contains(feature); }
    public void fail(String feature, Throwable t, Runnable onTrip) {
        int n = fails.merge(feature, 1, Integer::sum);
        if (n >= limit && tripped.add(feature)) { System.err.println("[hollowwatch] feature '" + feature + "' disabled for this session after repeated errors: " + t); if (onTrip != null) onTrip.run(); }
    }
    public void run(String feature, Runnable body, Runnable onTrip) { if (!ok(feature)) return; try { body.run(); } catch (Throwable t) { fail(feature, t, onTrip); } }
}
