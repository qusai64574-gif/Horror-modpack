package dev.hollowwatch.core;
import java.util.*;
/** Zero-delay keyframe animation. Clips are data (bone -> keyframes of rot/pos). Driven by a synced state id; blends over 2 ticks; no T-pose (rest pose = identity). Pure Java. */
public final class Anim {
    public record Key(float t, float rx, float ry, float rz, float px, float py, float pz) {}
    public static final class Clip { public final String name; public final float length; public final Map<String, List<Key>> tracks = new HashMap<>();
        public final boolean loopFlag; public Clip(String n, float len, boolean loop) { name = n; length = len; this.loopFlag = loop; }
        public Clip track(String bone, Key... k) { tracks.put(bone, Arrays.asList(k)); return this; } }
    public static final float[] ZERO = new float[6];
    /** Sample a bone at time t (seconds). Linear interpolation, loops if clip.loop. Returns {rx,ry,rz,px,py,pz} in degrees/model units. */
    public static void sample(Clip c, String bone, float t, float[] out) {
        List<Key> ks = c.tracks.get(bone); Arrays.fill(out, 0); if (ks == null || ks.isEmpty()) return;
        if (c.loopFlag && c.length > 0) t = t % c.length; else t = Math.min(t, c.length);
        Key a = ks.get(0), b = ks.get(ks.size() - 1); if (t <= a.t) { put(a, a, 0, out); return; } if (t >= b.t) { put(b, b, 0, out); return; }
        for (int i = 0; i + 1 < ks.size(); i++) if (t >= ks.get(i).t && t <= ks.get(i + 1).t) { a = ks.get(i); b = ks.get(i + 1); break; }
        put(a, b, b.t == a.t ? 0 : (t - a.t) / (b.t - a.t), out);
    }
    private static void put(Key a, Key b, float f, float[] o) { o[0] = a.rx + (b.rx - a.rx) * f; o[1] = a.ry + (b.ry - a.ry) * f; o[2] = a.rz + (b.rz - a.rz) * f; o[3] = a.px + (b.px - a.px) * f; o[4] = a.py + (b.py - a.py) * f; o[5] = a.pz + (b.pz - a.pz) * f; }
    private static Key k(float t, float rx, float ry, float rz) { return new Key(t, rx, ry, rz, 0, 0, 0); }
    private static Key kp(float t, float rx, float ry, float rz, float px, float py, float pz) { return new Key(t, rx, ry, rz, px, py, pz); }
    /** Generic clip library; every creature uses the same bone names (body, head, neck, arm_l, arm_r, leg_l, leg_r) so one set drives all. */
    public static final Map<String, Clip> LIB = new LinkedHashMap<>();
    static {
        LIB.put("idle", new Clip("idle", 3f, true).track("body", k(0, 0, 0, 0), k(1.5f, 1.5f, 0, 0), k(3, 0, 0, 0)).track("arm_l", k(0, 0, 0, 2), k(1.5f, 0, 0, 5), k(3, 0, 0, 2)).track("arm_r", k(0, 0, 0, -2), k(1.5f, 0, 0, -5), k(3, 0, 0, -2)));
        LIB.put("walk", new Clip("walk", 1f, true).track("leg_l", k(0, 30, 0, 0), k(.5f, -30, 0, 0), k(1, 30, 0, 0)).track("leg_r", k(0, -30, 0, 0), k(.5f, 30, 0, 0), k(1, -30, 0, 0)).track("arm_l", k(0, -20, 0, 0), k(.5f, 20, 0, 0), k(1, -20, 0, 0)).track("arm_r", k(0, 20, 0, 0), k(.5f, -20, 0, 0), k(1, 20, 0, 0)));
        LIB.put("run", new Clip("run", .5f, true).track("body", k(0, 12, 0, 0), k(.25f, 16, 0, 0), k(.5f, 12, 0, 0)).track("leg_l", k(0, 55, 0, 0), k(.25f, -55, 0, 0), k(.5f, 55, 0, 0)).track("leg_r", k(0, -55, 0, 0), k(.25f, 55, 0, 0), k(.5f, -55, 0, 0)).track("arm_l", k(0, -60, 0, 0), k(.25f, 60, 0, 0), k(.5f, -60, 0, 0)).track("arm_r", k(0, 60, 0, 0), k(.25f, -60, 0, 0), k(.5f, 60, 0, 0)));
        LIB.put("sprint", new Clip("sprint", .36f, true).track("body", k(0, 22, 0, 0), k(.18f, 26, 0, 0), k(.36f, 22, 0, 0)).track("leg_l", k(0, 70, 0, 0), k(.18f, -70, 0, 0), k(.36f, 70, 0, 0)).track("leg_r", k(0, -70, 0, 0), k(.18f, 70, 0, 0), k(.36f, -70, 0, 0)).track("arm_l", k(0, -80, 0, 0), k(.18f, 80, 0, 0), k(.36f, -80, 0, 0)).track("arm_r", k(0, 80, 0, 0), k(.18f, -80, 0, 0), k(.36f, 80, 0, 0)));
        LIB.put("attack", new Clip("attack", .5f, false).track("arm_l", k(0, 0, 0, 0), k(.15f, -120, 0, 0), k(.5f, 0, 0, 0)).track("arm_r", k(0, 0, 0, 0), k(.15f, -120, 0, 0), k(.5f, 0, 0, 0)).track("body", k(0, 0, 0, 0), k(.15f, 15, 0, 0), k(.5f, 0, 0, 0)));
        LIB.put("grab", new Clip("grab", .8f, false).track("arm_l", k(0, 0, 0, 0), k(.3f, -150, 0, -20), k(.8f, -150, 0, -20)).track("arm_r", k(0, 0, 0, 0), k(.3f, -150, 0, 20), k(.8f, -150, 0, 20)).track("head", k(0, 0, 0, 0), k(.3f, 20, 0, 0), k(.8f, 20, 0, 0)));
        LIB.put("look", new Clip("look", 2f, true).track("head", k(0, 0, 0, 0), k(.7f, 0, 40, 0), k(1.3f, 0, -40, 0), k(2, 0, 0, 0)));
        LIB.put("crouch", new Clip("crouch", 1f, false).track("body", kp(0, 0, 0, 0, 0, 0, 0), kp(.4f, 40, 0, 0, 0, -8, 0), kp(1, 40, 0, 0, 0, -8, 0)).track("leg_l", k(0, 0, 0, 0), k(.4f, -60, 0, 0), k(1, -60, 0, 0)).track("leg_r", k(0, 0, 0, 0), k(.4f, -60, 0, 0), k(1, -60, 0, 0)));
        LIB.put("peek", new Clip("peek", 1.2f, false).track("head", kp(0, 0, 0, 25, -4, 0, 0), kp(.5f, 0, 0, 25, 0, 0, 0), kp(1.2f, 0, 0, 25, 0, 0, 0)));
        LIB.put("neck_twist", new Clip("neck_twist", 1.6f, false).track("head", k(0, 0, 0, 0), k(.4f, 0, 90, 0), k(.9f, 0, 200, 0), k(1.6f, 0, 270, 0)).track("neck", k(0, 0, 0, 0), k(.9f, 0, 60, 0), k(1.6f, 0, 90, 0)));
        LIB.put("spawn_reveal", new Clip("spawn_reveal", .8f, false).track("body", kp(0, 0, 0, 0, 0, -6, 0), kp(.8f, 0, 0, 0, 0, 0, 0)).track("head", k(0, 30, 0, 0), k(.8f, 0, 0, 0)));
        LIB.put("vanish", new Clip("vanish", .5f, false).track("body", kp(0, 0, 0, 0, 0, 0, 0), kp(.5f, 0, 0, 0, 0, -10, 0)));
        LIB.put("death", new Clip("death", 1f, false).track("body", kp(0, 0, 0, 0, 0, 0, 0), kp(1, -90, 0, 0, 0, -14, 0)));
        LIB.put("scuttle", new Clip("scuttle", .3f, true).track("arm_l", k(0, -40, 0, 20), k(.15f, 40, 0, 20), k(.3f, -40, 0, 20)).track("arm_r", k(0, 40, 0, -20), k(.15f, -40, 0, -20), k(.3f, 40, 0, -20)).track("leg_l", k(0, 40, 0, 0), k(.15f, -40, 0, 0), k(.3f, 40, 0, 0)).track("leg_r", k(0, -40, 0, 0), k(.15f, 40, 0, 0), k(.3f, -40, 0, 0)));
        LIB.put("glitch_flicker", new Clip("glitch_flicker", .4f, true).track("body", kp(0, 0, 0, 0, 0, 0, 0), kp(.1f, 0, 4, 0, 2, 0, 0), kp(.2f, 0, -4, 0, -2, 0, 0), kp(.4f, 0, 0, 0, 0, 0, 0)));
    }
    /** Per-entity animation state: current + previous clip blended over BLEND_TICKS. No allocation per tick (preallocated arrays). */
    public static final class Player {
        public static final int BLEND_TICKS = 2; private String cur = "idle", prev = "idle"; private float tCur, tPrev; private int blend = BLEND_TICKS; private final float[] a = new float[6], b = new float[6];
        public void play(String clip) { if (clip == null || !LIB.containsKey(clip) || clip.equals(cur)) return; prev = cur; tPrev = tCur; cur = clip; tCur = 0; blend = 0; }
        public void tick(float dt) { tCur += dt; tPrev += dt; if (blend < BLEND_TICKS) blend++; }
        public String current() { return cur; }
        public boolean finished() { Clip c = LIB.get(cur); return !c.loopFlag && tCur >= c.length; }
        public void pose(String bone, float[] out) { sample(LIB.get(cur), bone, tCur, a); if (blend >= BLEND_TICKS) { System.arraycopy(a, 0, out, 0, 6); return; } sample(LIB.get(prev), bone, tPrev, b); float f = blend / (float) BLEND_TICKS; for (int i = 0; i < 6; i++) out[i] = b[i] + (a[i] - b[i]) * f; }
    }
    /** Chooses a clip from synced entity state. */
    public static String choose(String stateName, double speedBps) {
        switch (stateName) { case "ATTACK": return "attack"; case "GRAB": return "grab"; case "LOOK": return "look"; case "PEEK": return "peek"; case "TWIST": return "neck_twist"; case "SPAWN": return "spawn_reveal"; case "VANISH": return "vanish"; case "DEATH": return "death"; case "GLITCH": return "glitch_flicker"; case "CROUCH": return "crouch"; case "SCUTTLE": return "scuttle"; default: }
        return speedBps > 5.5 ? "sprint" : speedBps > 3.2 ? "run" : speedBps > 0.3 ? "walk" : "idle";
    }
}
