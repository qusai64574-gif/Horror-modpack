package dev.hollowwatch.core;
import java.util.*;
/** Mirages: NON-DAMAGING fakes shown only to the low-sanity player (client-side), plus fake sounds / flicker / fake chat. Pure scheduling logic, bounded. */
public final class Mirage {
    public enum Kind { FAKE_CREATURE, FAKE_SOUND, LIGHT_FLICKER, FAKE_CHAT, FOV_WARP }
    public record Event(Kind kind, String id, int durationTicks) {}
    private final Random rnd; private int cooldown; private final Quality q; public Mirage(long seed, Quality q) { rnd = new Random(seed); this.q = q; }
    private static final String[] FAKE_IDS = {"pale_stalker", "mask_giant", "rotted_skull", "turner", "long_crawler", "broken_script"};
    private static final String[] FAKE_SOUNDS = {"step", "breath", "knock", "whisper", "scratch", "help"};
    /** Called once per second with the player's sanity object. Returns an event or null. Max 1 per call, cooldown-limited, scales with quality caps. */
    public Event tick(Sanity s, boolean intensityOn) {
        if (!intensityOn) return null; if (cooldown > 0) { cooldown--; return null; }
        float p = s.mirageChance() * (q == Quality.POTATO ? 0.5f : 1f); if (p <= 0 || rnd.nextFloat() > p * 0.25f) return null;
        cooldown = (int) (12 - 8 * p); int r = rnd.nextInt(10);
        if (r < 3) return q == Quality.POTATO ? new Event(Kind.FAKE_SOUND, FAKE_SOUNDS[rnd.nextInt(FAKE_SOUNDS.length)], 20) : new Event(Kind.FAKE_CREATURE, FAKE_IDS[rnd.nextInt(FAKE_IDS.length)], 60 + rnd.nextInt(60));
        if (r < 6) return new Event(Kind.FAKE_SOUND, FAKE_SOUNDS[rnd.nextInt(FAKE_SOUNDS.length)], 20);
        if (r < 8) return new Event(Kind.LIGHT_FLICKER, "", 30); if (r < 9) return new Event(Kind.FAKE_CHAT, "whispers", 1); return new Event(Kind.FOV_WARP, "", 40);
    }
    public static boolean damages(Event e) { return false; } // mirages are never able to hurt: documented invariant, tested
}
