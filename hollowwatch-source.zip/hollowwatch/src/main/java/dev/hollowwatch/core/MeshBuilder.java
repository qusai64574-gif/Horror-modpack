package dev.hollowwatch.core;
/** Turns one model cube into 24 vertices (6 faces x 4), each {x,y,z,u,v,nx,ny,nz}, using the same box-UV layout the texture generator paints. Model units are 1/16 block. Pure Java; unit-tested. */
public final class MeshBuilder {
    public static final int VERTS = 24, STRIDE = 8;
    public static float[] cube(float[] size, float[] origin, int[] uv, int texelsPerUnit, int texW, int texH) {
        float w = size[0], h = size[1], d = size[2], x0 = origin[0], y0 = origin[1], z0 = origin[2], x1 = x0 + w, y1 = y0 + h, z1 = z0 + d; int n = texelsPerUnit;
        float u0 = uv[0], v0 = uv[1], dw = d * n, ww = w * n, hh = h * n; float[] o = new float[VERTS * STRIDE]; int[] i = {0};
        // layout: [d][w][d][w] across, top/bottom above: top=(u0+dw, v0), bottom=(u0+dw+ww, v0), left=(u0, v0+dw), front=(u0+dw, v0+dw), right=(u0+dw+ww, v0+dw), back=(u0+2dw+ww, v0+dw)
        // Minecraft convention: model -Z is front (faces the viewer when entity yaw=0 after the standard 180 flip applied by the renderer).
        face(o, i, new float[]{x0, y1, z0, x1, y1, z0, x1, y0, z0, x0, y0, z0}, 0, 0, -1, u0 + dw, v0 + dw, ww, hh, texW, texH);          // front (-Z)
        face(o, i, new float[]{x1, y1, z1, x0, y1, z1, x0, y0, z1, x1, y0, z1}, 0, 0, 1, u0 + 2 * dw + ww, v0 + dw, ww, hh, texW, texH);   // back (+Z)
        face(o, i, new float[]{x1, y1, z0, x1, y1, z1, x1, y0, z1, x1, y0, z0}, 1, 0, 0, u0, v0 + dw, dw, hh, texW, texH);                // left (+X) side
        face(o, i, new float[]{x0, y1, z1, x0, y1, z0, x0, y0, z0, x0, y0, z1}, -1, 0, 0, u0 + dw + ww, v0 + dw, dw, hh, texW, texH);      // right (-X)
        face(o, i, new float[]{x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0}, 0, 1, 0, u0 + dw, v0, ww, dw, texW, texH);                // top
        face(o, i, new float[]{x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1}, 0, -1, 0, u0 + dw + ww, v0, ww, dw, texW, texH);          // bottom
        return o;
    }
    private static void face(float[] o, int[] idx, float[] p, float nx, float ny, float nz, float fu, float fv, float fw, float fh, int tw, int th) {
        float[][] uv = {{fu, fv}, {fu + fw, fv}, {fu + fw, fv + fh}, {fu, fv + fh}};
        for (int k = 0; k < 4; k++) { int b = idx[0]++ * STRIDE; o[b] = p[k * 3] / 16f; o[b + 1] = p[k * 3 + 1] / 16f; o[b + 2] = p[k * 3 + 2] / 16f; o[b + 3] = uv[k][0] / tw; o[b + 4] = uv[k][1] / th; o[b + 5] = nx; o[b + 6] = ny; o[b + 7] = nz; }
    }
}
