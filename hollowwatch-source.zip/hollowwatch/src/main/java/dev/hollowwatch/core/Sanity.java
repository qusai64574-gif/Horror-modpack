package dev.hollowwatch.core;
/** Per-player sanity (0..100). Original design; values are defaults, not copied from any other mod. Server-authoritative. */
public class Sanity {
    public enum Tier { STABLE(70, 0xFF78C8FF), UNEASY(45, 0xFFE6D26E), FRAYED(20, 0xFFE69A4A), BROKEN(0, 0xFFE64A4A);
        public final int min, color; Tier(int m, int c) { min = m; color = c; } }
    public static final int SEGMENTS = 5; public static final float MAX = 100f;
    private float value = 100f; private int lastDelta;
    public float get() { return value; }
    public void set(float v) { value = Float.isNaN(v) ? 100f : HorrorConfig.clamp(v, 0, MAX); }
    public void add(float d) { set(value + d); lastDelta = d == 0 ? 0 : d > 0 ? 1 : -1; }
    public int lastDelta() { return lastDelta; }
    public Tier tier() { for (Tier t : Tier.values()) if (value >= t.min && t != Tier.BROKEN) return t; return Tier.BROKEN; }
    /** HUD: 5 segments, each 20 points, fills left to right. Returns 0..1 fill of segment i. */
    public float segmentFill(int i) { return HorrorConfig.clamp((value - i * (MAX / SEGMENTS)) / (MAX / SEGMENTS), 0, 1); }
    /** Seconds-based drain/regen applied every 20 ticks by the server. */
    public static float tickDelta(boolean dark, boolean nightOutdoors, boolean inCave, boolean lightNearby, boolean friendsNear, boolean fed, boolean sleptRecently) {
        float d = 0; if (dark) d -= 0.25f; if (nightOutdoors) d -= 0.10f; if (inCave) d -= 0.05f;
        if (lightNearby) d += 0.20f; if (friendsNear) d += 0.20f; if (fed) d += 0.05f; if (sleptRecently) d += 0.10f; return d;
    }
    /** Looking at a creature drains by type. */
    public static float lookDrain(String type) { switch (type) { case "mask_giant": return -4f; case "rotted_skull": return -3f; case "pale_stalker": return -2f; case "broken_script": return -3f; case "cave_colossus": return -4f; case "turner": return -3f; default: return -1.5f; } }
    public static final float KILL_RESTORE = 8f, SHARD_PASSIVE_PER_SEC = 0.15f, TONIC_RESTORE = 30f, BED_RESTORE = 25f;
    /** Spawn-weight multiplier from sanity: 1x at 100, up to 3x at 0. */
    public float spawnWeight() { return 1f + 2f * (1f - value / MAX); }
    public float mirageChance() { return value >= 45 ? 0f : (45 - value) / 45f * 0.5f; }
    public float fogThickening() { return value >= 70 ? 0f : (70 - value) / 70f; }
    public float redTint() { return value >= 20 ? 0f : (20 - value) / 20f; }
    public float hudShake() { return value >= 20 ? 0f : (20 - value) / 20f * 2.0f; }
    public float hudPulseHz() { return value >= 45 ? 0f : 1f + (45 - value) / 45f * 2f; }
    public String serialize() { return "v1:" + value; }
    public static Sanity deserialize(String s) { Sanity x = new Sanity(); try { if (s != null && s.startsWith("v1:")) x.set(Float.parseFloat(s.substring(3))); } catch (Exception e) { /* corrupt -> default 100 */ } return x; }
}
