package dev.hollowwatch.core;
/** Item effects as pure functions (server applies them). Pale Mask Shard, Ember Core, Calming Tonic. */
public final class Items {
    public static final String SHARD = "shard", EMBER = "ember_core", TONIC = "calming_tonic";
    public static final int TONIC_COOLDOWN_TICKS = 20 * 60;
    /** Calming tonic: +30 sanity, 60 s cooldown. Returns new cooldown-end tick or the same if still cooling. */
    public static long useTonic(Sanity s, long now, long cooldownEnd) { if (now < cooldownEnd) return cooldownEnd; s.add(Sanity.TONIC_RESTORE); return now + TONIC_COOLDOWN_TICKS; }
    /** Holding a shard: +0.15/s passive (called each second) but it draws the stalker's attention (weight multiplier). */
    public static void holdShard(Sanity s) { s.add(Sanity.SHARD_PASSIVE_PER_SEC); }
    public static float stalkerAttentionMult(boolean holdingShard) { return holdingShard ? 1.5f : 1f; }
    /** Kill reward: restores sanity, drops shard (stalker) or ember core (brute) with fixed per-creature chance; duplicate-free: caller passes a killer id set per entity. */
    public static float killRestore(String creature) { return Sanity.KILL_RESTORE; }
    public static String dropFor(String creature, double roll) { if (creature.equals("pale_stalker") && roll < 0.6) return SHARD; if (creature.equals("charred_brute") && roll < 0.5) return EMBER; return null; }
    /** Ember core: lights a radius where chasers refuse to enter (counterplay). */
    public static double emberSafeRadius() { return 6.0; }
}
