package dev.hollowwatch.entity;
// NOT COMPILED (26.3 API assumed). Brain = core.CreatureAI (per creature) / StalkerBrain for the pale stalker. Server decides everything; clip name is synced to clients for instant animation.
import dev.hollowwatch.*; import dev.hollowwatch.core.*; import net.minecraft.network.syncher.*; import net.minecraft.network.protocol.game.ClientboundSetEntityDataPacket;
import net.minecraft.world.entity.*; import net.minecraft.world.entity.ai.attributes.*; import net.minecraft.world.entity.player.Player; import net.minecraft.world.level.Level; import net.minecraft.server.level.ServerPlayer; import net.minecraft.world.phys.Vec3;
public class HorrorEntity extends PathfinderMob {
    private static final EntityDataAccessor<String> CLIP = SynchedEntityData.defineId(HorrorEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Integer> VANISH = SynchedEntityData.defineId(HorrorEntity.class, EntityDataSerializers.INT);
    public final Creatures.Def def; private final CreatureAI.Brain brain; private final StalkerBrain stalker; private int life; private ServerPlayer owner; private boolean frozen;
    private float clientTime; private static final int MAX_LIFE_TICKS = 20 * 60 * 5;   // hard despawn cap
    public HorrorEntity(EntityType<? extends HorrorEntity> t, Level l, Creatures.Def d) { super(t, l); def = d; setPersistenceRequired(); brain = CreatureAI.create(d.id(), HollowWatch.CFG); stalker = d.id().equals("pale_stalker") ? new StalkerBrain(HollowWatch.CFG) : null; }
    public static AttributeSupplier.Builder attrs(Creatures.Def d) { return PathfinderMob.createMobAttributes().add(Attributes.MOVEMENT_SPEED, Math.max(0.01, d.speed())).add(Attributes.MAX_HEALTH, d.attacker() ? 40 : 6).add(Attributes.FOLLOW_RANGE, 48).add(Attributes.ATTACK_DAMAGE, 6); }
    @Override protected void defineSynchedData(SynchedEntityData.Builder b) { super.defineSynchedData(b); b.define(CLIP, "spawn_reveal").define(VANISH, 0); }
    public String syncedClip() { return entityData.get(CLIP); }
    public float clipTime(float pt) { clientTime += 0.05f * (pt > 0 ? 1 : 0); return (tickCount + pt) * 0.05f; }
    public float visibleAlpha() { int v = entityData.get(VANISH); return v <= 0 ? Math.min(1f, tickCount / 10f) : Math.max(0f, 1f - v / 10f); }
    public void setOwner(ServerPlayer p) { owner = p; }
    @Override public boolean isPushable() { return !frozen; }
    /** Do not hurt or target anyone but the owner for scare-only creatures; attackers target their owner only (no bystander griefing). */
    @Override public void tick() {
        super.tick(); if (level().isClientSide()) return; if (++life > MAX_LIFE_TICKS || owner == null || owner.isRemoved() || owner.level() != level()) { discard(); return; }
        if (entityData.get(VANISH) > 0) { entityData.set(VANISH, entityData.get(VANISH) + 1); if (entityData.get(VANISH) > 10) { discard(); } return; }
        if (tickCount % 10 != 0) { if (frozen) setDeltaMovement(Vec3.ZERO); return; }
        CreatureAI.Obs o = observe(owner); CreatureAI.Order od;
        if (stalker != null) { StalkerBrain.Obs so = new StalkerBrain.Obs(); so.dist = o.dist; so.observed = o.observed; so.hasCover = true; so.targetLight = o.targetLight; so.targetGrouped = o.targetGrouped; so.targetSprinting = o.targetSprinting; so.night = o.night; so.targetSanity = o.sanity; stalker.tick(so, 10);
            od = new CreatureAI.Order(); od.speed = stalker.speed(); od.anim = Anim.choose(stalker.state().equals("ATTACK") ? "ATTACK" : "", od.speed); od.melee = stalker.state() == StalkerBrain.State.ATTACK && o.dist < 1.8; od.despawn = stalker.state() == StalkerBrain.State.RETURN_LATER; od.frozen = od.speed == 0; od.vanish = stalker.state() == StalkerBrain.State.ABANDON; if (od.melee) stalker.registerHit(); }
        else od = brain.tick(o, 10);
        apply(od, o);
    }
    private CreatureAI.Obs observe(ServerPlayer p) { CreatureAI.Obs o = new CreatureAI.Obs(); o.dist = distanceTo(p); var look = p.getLookAngle().normalize(); var to = position().add(0, getBbHeight() / 2, 0).subtract(p.getEyePosition()).normalize(); o.observed = look.dot(to) > 0.88 && p.hasLineOfSight(this);
        int light = level().getMaxLocalRawBrightness(p.blockPosition()); o.targetLight = light > 11 || p.getMainHandItem().is(net.minecraft.world.item.Items.TORCH) || p.getOffhandItem().is(net.minecraft.world.item.Items.TORCH);
        o.targetGrouped = level().getEntitiesOfClass(Player.class, p.getBoundingBox().inflate(10), q -> q != p && q.isAlive() && !q.isSpectator()).size() > 0; o.targetSprinting = p.isSprinting(); o.targetInCave = p.getY() < 50 && !level().canSeeSky(p.blockPosition()); o.targetIndoors = !level().canSeeSky(p.blockPosition()); o.night = level().isDarkOutside();
        o.sanity = HollowWatch.sanityOf(p).get(); o.targetStopped = p.getDeltaMovement().horizontalDistanceSqr() < 1e-4; return o; }
    private void apply(CreatureAI.Order od, CreatureAI.Obs o) {
        frozen = od.frozen; entityData.set(CLIP, od.anim == null ? "idle" : od.anim);
        if (od.despawn) { discard(); return; } if (od.vanish) { entityData.set(VANISH, 1); }
        if (od.speed > 0 && !frozen) { getNavigation().moveTo(owner, Math.max(0.5, od.speed / 4.3)); } else { getNavigation().stop(); }
        if (od.speed < 0) { Vec3 away = position().subtract(owner.position()).normalize().scale(0.25); setDeltaMovement(away.x, getDeltaMovement().y, away.z); }
        lookAt(owner, 60, 60);
        if (od.sound != null) HollowWatch.playAt(this, od.sound, owner);
        if (od.targetWhisper) HollowWatch.whisper(owner, "whispers", level().getGameTime());
        if (od.doKnock) HollowWatch.playAt(this, "knock", owner);
        if (od.doScare && od.scareKind >= 0) HollowWatch.scare(owner, def.id(), od.scareKind, 30, level().getGameTime());
        if (od.cinematicKill) { HollowWatch.scare(owner, def.id(), 2, 60, level().getGameTime()); damageOwner(true); }
        else if (od.melee && o.dist < 2.2) { damageOwner(false); }
    }
    /** STRONG catch: difficulty-scaled damage + knockdown/stun; repeated catches kill. Cinematic kill = lethal blow (owner dies, normal death screen follows after the victim-only cinematic). */
    private void damageOwner(boolean lethal) { float base = 4 + 2 * HollowWatch.CFG.difficulty; float dmg = lethal ? owner.getHealth() + 1 : base * HollowWatch.CFG.intensity; owner.hurt(damageSources().mobAttack(this), dmg); if (!lethal) { owner.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.SLOWNESS, 30, 3)); Vec3 kb = owner.position().subtract(position()).normalize().scale(0.8); owner.setDeltaMovement(kb.x, 0.3, kb.z); }
        if (lethal || owner.getHealth() <= 0) HollowWatch.scare(owner, def.id(), 1, 50, level().getGameTime()); }
    @Override public void die(net.minecraft.world.damagesource.DamageSource src) { super.die(src); if (src.getEntity() instanceof ServerPlayer killer && !level().isClientSide()) { HollowWatch.sanityOf(killer).add(Items.killRestore(def.id())); String drop = Items.dropFor(def.id(), random.nextDouble()); if (drop != null) HollowWatch.giveOnce(killer, drop); } }
}
