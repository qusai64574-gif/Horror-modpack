package dev.hollowwatch;
// NOT COMPILED. Server-side spawning: per-player, rate-limited, bounded by Quality caps, never in line of sight except the Turner (rate-limited exception).
import dev.hollowwatch.core.*; import dev.hollowwatch.entity.HorrorEntity; import net.minecraft.server.level.*; import net.minecraft.core.BlockPos; import net.minecraft.world.phys.Vec3; import java.util.*;
public final class Spawner {
    private static final Map<UUID, Long> NEXT = new HashMap<>(); private static final Random RND = new Random();
    public static int countFor(ServerPlayer p) { return p.level().getEntitiesOfClass(HorrorEntity.class, p.getBoundingBox().inflate(80), e -> true).size(); }
    /** Called once per second per player. Staggered: each player rolls at most once every 20-60 s (shorter at low sanity), caps enforced. */
    public static void maybeSpawn(ServerPlayer p, long now) {
        if (!HollowWatch.CFG.enabled) return; Long n = NEXT.get(p.getUUID()); if (n != null && now < n) return; Sanity s = HollowWatch.sanityOf(p);
        NEXT.put(p.getUUID(), now + (long) ((400 + RND.nextInt(800)) / Math.max(0.5f, s.spawnWeight() * HollowWatch.CFG.intensity))); if (countFor(p) >= HollowWatch.CFG.quality.maxHorrorEntitiesPerPlayer) return; if (RND.nextFloat() > 0.35f * s.spawnWeight() * HollowWatch.CFG.intensity) return;
        ServerLevel lvl = p.level(); boolean night = lvl.isDarkOutside(), sky = lvl.canSeeSky(p.blockPosition()), cave = !sky && p.getY() < 50, indoors = !sky && !cave, birch = lvl.getBiome(p.blockPosition()).is(net.minecraft.world.level.biome.Biomes.BIRCH_FOREST);
        List<String> pool = new ArrayList<>();
        if (night && sky) { pool.add("pale_stalker"); pool.add("pale_stalker"); pool.add("charred_brute"); pool.add("follower"); pool.add("turner"); pool.add("roof_silhouette"); pool.add("window_face"); if (s.get() < 40) { pool.add("long_crawler"); pool.add("mask_giant"); pool.add("marsh_walker"); } }
        if (cave) { pool.add("rotted_skull"); pool.add("cave_wall_face"); pool.add("ceiling_hanger"); pool.add("wall_crawler"); pool.add("fake_torch"); if (s.get() < 60) pool.add("cave_colossus"); if (s.get() < 50) pool.add("hollow_titan"); }
        if (indoors && night) { pool.add("horned_peeper"); pool.add("window_hand"); pool.add("window_face"); }
        if (!night && sky && birch && lvl.isBrightOutside()) pool.add("birch_anomaly"); if (s.get() < 25) pool.add("broken_script");
        if (pool.isEmpty()) return; String id = pool.get(RND.nextInt(pool.size())); spawn(p, id, id.equals("turner"));
    }
    /** Place 18-32 blocks away on solid ground OUT of the player's view cone (hidden behind terrain), unless inFront (Turner: 6 blocks ahead). Returns the entity or null. */
    public static HorrorEntity spawn(ServerPlayer p, String id, boolean inFront) {
        var type = ModRegistry.ENTITIES.get(id); if (type == null) return null; ServerLevel lvl = p.level(); Vec3 look = p.getLookAngle().multiply(1, 0, 1).normalize();
        for (int i = 0; i < 12; i++) { double ang = RND.nextDouble() * Math.PI * 2, dist = inFront ? 6 : 18 + RND.nextInt(15); Vec3 d = inFront ? look : new Vec3(Math.cos(ang), 0, Math.sin(ang)); double dot = d.dot(look); if (!inFront && dot > 0.2) continue; // behind/side only
            BlockPos bp = BlockPos.containing(p.getX() + d.x * dist, p.getY(), p.getZ() + d.z * dist); for (int dy = 4; dy >= -6; dy--) { BlockPos q = bp.above(dy); if (lvl.getBlockState(q).isAir() && lvl.getBlockState(q.above()).isAir() && lvl.getBlockState(q.below()).isSolid()) { HorrorEntity e = type.create(lvl, net.minecraft.world.entity.EntitySpawnReason.EVENT); if (e == null) return null; e.setPos(q.getX() + .5, q.getY(), q.getZ() + .5); e.setOwner(p); lvl.addFreshEntity(e); return e; } } }
        return null;
    }
    public static int removeAll(MinecraftServerAccess s) { return 0; }
    public interface MinecraftServerAccess {}
}
