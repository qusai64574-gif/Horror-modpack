package dev.hollowwatch;
import net.minecraft.server.MinecraftServer; import net.minecraft.server.level.ServerPlayer;
/** All admin-panel actions. Called only after HollowWatch.isOp() succeeded for the sender. Every branch is real; unknown actions are ignored. */
final class AdminActions {
    static void apply(MinecraftServer server, ServerPlayer admin, String action, String arg, String target) {
        ServerPlayer tp = target == null || target.isEmpty() ? admin : server.getPlayerList().getPlayerByName(target); if (tp == null) tp = admin; long now = server.getTickCount();
        switch (action) {
            case "global.enable" -> HollowWatch.CFG.enabled = Boolean.parseBoolean(arg);
            case "global.intensity" -> HollowWatch.CFG.intensity = dev.hollowwatch.core.HorrorConfig.clamp(parse(arg, 1f), 0, 3);
            case "global.difficulty" -> HollowWatch.CFG.difficulty = (int) dev.hollowwatch.core.HorrorConfig.clamp(parse(arg, 2f), 0, 3);
            case "global.quality" -> { HollowWatch.CFG.quality = dev.hollowwatch.core.Quality.parse(arg, HollowWatch.CFG.quality); HollowWatch.CFG.qualityAuto = false; }
            case "global.jumpscares" -> HollowWatch.CFG.jumpscares = Boolean.parseBoolean(arg);
            case "global.cinematics" -> HollowWatch.CFG.cinematics = Boolean.parseBoolean(arg);
            case "global.fog" -> HollowWatch.CFG.fog = Boolean.parseBoolean(arg);
            case "global.sanity" -> HollowWatch.CFG.sanity = Boolean.parseBoolean(arg);
            case "global.chat" -> HollowWatch.CFG.fakeChat = Boolean.parseBoolean(arg);
            case "player.sanity.set" -> HollowWatch.sanityOf(tp).set(parse(arg, 100f));
            case "player.sanity.reset" -> HollowWatch.sanityOf(tp).set(100f);
            case "player.scare.test" -> HollowWatch.scare(tp, arg, 0, 30, Long.MAX_VALUE / 2);
            case "player.cinematic.test" -> HollowWatch.scare(tp, arg, 2, 60, now);
            case "event.fog.clear" -> net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(tp, new dev.hollowwatch.net.Payloads.FogSync(0, false, false, 0, true));
            case "event.whisper" -> HollowWatch.whisper(tp, arg, Long.MAX_VALUE / 2);
            case "world.reset" -> { HollowWatch.SANITY.clear(); HollowWatch.CHAT.clear(); HollowWatch.LAST_SCARE.clear(); }
            case "entity.spawn" -> Spawner.spawn(tp, arg, arg.equals("turner"));
            case "entity.remove_all" -> { for (var lvl : server.getAllLevels()) for (var e : lvl.getEntitiesOfClass(dev.hollowwatch.entity.HorrorEntity.class, new net.minecraft.world.phys.AABB(-3e7, -2048, -3e7, 3e7, 2048, 3e7), x -> true)) e.discard(); }
            case "entity.remove_near" -> { for (var e : tp.level().getEntitiesOfClass(dev.hollowwatch.entity.HorrorEntity.class, tp.getBoundingBox().inflate(64), x -> true)) e.discard(); }
            case "entity.toggle_blockbreak" -> HollowWatch.CFG.blockBreaking = Boolean.parseBoolean(arg);
            case "player.encounter.start" -> Spawner.spawn(tp, "pale_stalker", false);
            case "player.encounter.stop" -> { for (var e : tp.level().getEntitiesOfClass(dev.hollowwatch.entity.HorrorEntity.class, tp.getBoundingBox().inflate(80), x -> true)) e.discard(); }
            case "player.intensity" -> { var d = HollowWatch.STORE.computeIfAbsent(tp.getUUID(), k -> new dev.hollowwatch.core.PlayerStore.Data()); d.personalIntensity = dev.hollowwatch.core.HorrorConfig.clamp(parse(arg, 1f), 0, 3); }
            case "event.mirage" -> net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(tp, new dev.hollowwatch.net.Payloads.MirageEvent(0, arg.isEmpty() ? "pale_stalker" : arg, 80));
            case "event.sound" -> HollowWatch.playAt(tp, arg, tp);
            case "debug.cleanup" -> { int n = 0; for (var lvl : server.getAllLevels()) for (var e : lvl.getEntitiesOfClass(dev.hollowwatch.entity.HorrorEntity.class, new net.minecraft.world.phys.AABB(-3e7, -2048, -3e7, 3e7, 2048, 3e7), x -> true)) { boolean orphan = true; for (var pl : server.getPlayerList().getPlayers()) if (pl.level() == lvl && pl.distanceTo(e) < 128) orphan = false; if (orphan) { e.discard(); n++; } } admin.sendSystemMessage(net.minecraft.network.chat.Component.literal("Removed orphans: " + n)); }
            case "debug.stats" -> { int n = 0; for (var lvl : server.getAllLevels()) n += lvl.getEntitiesOfClass(dev.hollowwatch.entity.HorrorEntity.class, new net.minecraft.world.phys.AABB(-3e7, -2048, -3e7, 3e7, 2048, 3e7), x -> true).size(); admin.sendSystemMessage(net.minecraft.network.chat.Component.literal("HW entities=" + n + " tracked players=" + HollowWatch.SANITY.size() + " quality=" + HollowWatch.CFG.quality + " breaker(server_tick ok)=" + HollowWatch.BREAKER.ok("server_tick") + " sanity(you)=" + HollowWatch.sanityOf(tp).get())); }
            case "debug.save" -> HollowWatch.saveAll();
            default -> { /* ignore */ }
        }
    }
    private static float parse(String s, float d) { try { return Float.parseFloat(s); } catch (Exception e) { return d; } }
}
