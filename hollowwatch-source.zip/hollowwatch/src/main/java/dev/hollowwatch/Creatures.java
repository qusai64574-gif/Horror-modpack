package dev.hollowwatch;
/** Registry table of every creature id. Each has a model JSON + texture + sound identity (checked by tools/validate.py). */
public final class Creatures {
    public record Def(String id, String name, String kind, float width, float height, double speed, boolean attacker) {}
    public static final Def[] ALL = {
        new Def("mask_giant", "Tall Mask Giant", "E01 apex, frozen while watched", 1.1f, 5.0f, 0.34, true),
        new Def("rotted_skull", "Rotted Skull Face", "E02 cave/dark ambusher", 0.9f, 2.6f, 0.30, true),
        new Def("horned_peeper", "Horned Window Peeper", "E03 scare-only", 0.6f, 1.2f, 0.0, false),
        new Def("charred_brute", "Charred Window Brute", "E04 slow night brute", 1.4f, 3.2f, 0.20, true),
        new Def("long_crawler", "Long-Limbed Crawler", "E05 fast skitterer", 0.8f, 1.6f, 0.45, true),
        new Def("broken_script", "Broken Script", "E06 glitch apparition", 0.8f, 2.0f, 0.0, false),
        new Def("pale_stalker", "Pale-Mask Stalker", "E07 primary stalker", 0.6f, 2.4f, 0.30, true),
        new Def("cave_wall_face", "Cave-Wall Mask Face", "E08 cave watcher", 1.0f, 1.0f, 0.0, false),
        new Def("birch_anomaly", "Birch Block Anomaly", "E09 daylight event", 2.5f, 2.5f, 0.0, false),
        new Def("cave_colossus", "Cave Colossus", "E10 big cave hunter", 1.6f, 6.0f, 0.28, true),
        new Def("turner", "The Turner", "E11 appears in front, neck twist, chases", 0.6f, 2.0f, 0.42, true),
        new Def("follower", "Follower-Behind", "E12 pursuer from behind", 0.6f, 2.1f, 0.40, true),
        new Def("ceiling_hanger", "Ceiling Hanger", "E13 cave scare-only", 0.6f, 2.0f, 0.0, false),
        new Def("wall_crawler", "Wall Crawler", "E13 cave scare-only", 0.8f, 1.2f, 0.0, false),
        new Def("fake_torch", "Fake Miner's Torch", "E13 cave scare-only", 0.3f, 0.9f, 0.0, false),
        new Def("window_face", "Window Face", "E14 house scare-only", 0.6f, 0.8f, 0.0, false),
        new Def("window_hand", "Window Hand", "E14 house scare-only", 0.4f, 0.5f, 0.0, false),
        new Def("roof_silhouette", "Rooftop Silhouette", "E14 house scare-only", 0.6f, 2.0f, 0.0, false),
        new Def("hollow_titan", "Hollow Titan", "E13 big creature", 2.4f, 7.0f, 0.22, true),
        new Def("marsh_walker", "Marsh Walker", "E13 big creature (swamp)", 1.6f, 6.0f, 0.26, true),
    };
}
