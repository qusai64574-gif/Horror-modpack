package dev.hollowwatch;
// NOT COMPILED against 26.3 (build sandbox could not reach Fabric Maven). Pure logic lives in dev.hollowwatch.core and IS unit-tested (tools/ + src/test).
import dev.hollowwatch.core.*; import dev.hollowwatch.core.Items; import dev.hollowwatch.net.Payloads;
import net.fabricmc.api.ModInitializer; import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.*; import net.fabricmc.fabric.api.networking.v1.*;
import net.minecraft.commands.Commands; import net.minecraft.server.level.ServerPlayer; import net.minecraft.server.MinecraftServer;
import java.io.File; import java.util.*; import java.util.concurrent.ConcurrentHashMap;

public class HollowWatch implements ModInitializer {
    public static final String ID = "hollowwatch";
    public static final HorrorConfig CFG = new HorrorConfig();
    public static final CircuitBreaker BREAKER = new CircuitBreaker(3);
    /** Per-player state keyed by UUID; survives death/respawn/dimension change; removed on disconnect after saving. */
    public static final Map<UUID, Sanity> SANITY = new ConcurrentHashMap<>();
    public static final Map<UUID, ChatBank> CHAT = new ConcurrentHashMap<>();
    public static final Map<UUID, Long> LAST_SCARE = new ConcurrentHashMap<>();
    public static final Map<UUID, PlayerStore.Data> STORE = new ConcurrentHashMap<>();
    public static final Map<UUID, Mirage> MIRAGES = new ConcurrentHashMap<>();
    private static final Set<String> CLAIMED = ConcurrentHashMap.newKeySet();   // "playerUUID:entityUUID" -> duplicate-free rewards
    private static java.nio.file.Path storeDir; private static File cfgFile;
    private int tick;

    @Override public void onInitialize() {
        cfgFile = new File(FabricLoader.getInstance().getConfigDir().toFile(), "hollowwatch.properties"); CFG.load(cfgFile); CFG.save(cfgFile);
        Payloads.registerCommon(); ModRegistry.init(); ModItems.init();
        ServerPlayNetworking.registerGlobalReceiver(Payloads.AdminOpenRequest.TYPE, (p, ctx) -> ctx.server().execute(() -> { if (isOp(ctx.player())) ServerPlayNetworking.send(ctx.player(), new Payloads.OpenAdmin(snapshot())); }));
        ServerPlayNetworking.registerGlobalReceiver(Payloads.AdminAction.TYPE, (p, ctx) -> ctx.server().execute(() -> {
            if (!isOp(ctx.player())) return;          // SERVER-SIDE AUTHORIZATION: re-checked on every single action; client UI is never trusted
            try { AdminActions.apply(ctx.server(), ctx.player(), p.action(), p.arg(), p.target()); } catch (Throwable t) { BREAKER.fail("admin", t, null); } }));
        CommandRegistrationCallback.EVENT.register((d, access, env) -> d.register(Commands.literal("horror").requires(s -> s.hasPermission(2))
            .then(Commands.literal("admin").executes(c -> { ServerPlayer sp = c.getSource().getPlayerOrException(); ServerPlayNetworking.send(sp, new Payloads.OpenAdmin(snapshot())); return 1; }))
            .then(Commands.literal("pause").executes(c -> { CFG.enabled = false; CFG.save(cfgFile); return 1; }))
            .then(Commands.literal("resume").executes(c -> { CFG.enabled = true; CFG.save(cfgFile); return 1; }))
            .then(Commands.literal("reset").executes(c -> { SANITY.clear(); return 1; }))));
        ServerTickEvents.END_SERVER_TICK.register(server -> { if (++tick % 20 == 0) BREAKER.run("server_tick", () -> slowTick(server), () -> CFG.enabled = false); if (tick % (20 * 300) == 0) saveAll(); });
        ServerLifecycleEvents.SERVER_STARTED.register(s -> storeDir = s.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT).resolve("hollowwatch"));
        ServerPlayConnectionEvents.JOIN.register((h, sender, s) -> { if (storeDir == null) return; PlayerStore.Data d = PlayerStore.load(storeDir, h.player.getUUID()); STORE.put(h.player.getUUID(), d); Sanity sn = new Sanity(); sn.set(d.sanity); SANITY.put(h.player.getUUID(), sn); });
        ServerPlayConnectionEvents.DISCONNECT.register((h, s) -> { UUID id = h.player.getUUID(); saveOne(id); SANITY.remove(id); CHAT.remove(id); LAST_SCARE.remove(id); STORE.remove(id); MIRAGES.remove(id); CLAIMED.removeIf(c -> c.startsWith(id.toString())); });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> { saveAll(); SANITY.clear(); STORE.clear(); MIRAGES.clear(); CLAIMED.clear(); CHAT.clear(); LAST_SCARE.clear(); CFG.save(cfgFile); });
    }
    /** Death resets nothing but gives a small relief so respawn is not instantly punishing; state survives respawn/dimension change because it is keyed by UUID. */
    public static void saveOne(UUID id) { if (storeDir == null) return; Sanity s = SANITY.get(id); PlayerStore.Data d = STORE.computeIfAbsent(id, k -> new PlayerStore.Data()); if (s != null) d.sanity = s.get(); PlayerStore.save(storeDir, id, d); }
    public static void saveAll() { for (UUID id : new ArrayList<>(SANITY.keySet())) saveOne(id); }
    public static void playAt(net.minecraft.world.entity.Entity src, String sound, ServerPlayer only) { ServerPlayNetworking.send(only, new Payloads.PlaySound(sound, src.getX(), src.getY(), src.getZ())); } // only the owner hears it
    /** Duplicate-free: one reward per (player, killed entity). */
    public static void giveOnce(ServerPlayer p, String item) { if (!CLAIMED.add(p.getUUID() + ":" + item + ":" + p.level().getGameTime() / 20)) return; p.getInventory().add(ModItems.stack(item)); }
    public static boolean isOp(ServerPlayer p) { return p != null && p.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_GAMEMASTER); } // UNVERIFIED permission API for 26.x
    public static String snapshot() { return "enabled=" + CFG.enabled + ";intensity=" + CFG.intensity + ";quality=" + CFG.quality + ";difficulty=" + CFG.difficulty; }
    public static Sanity sanityOf(ServerPlayer p) { return SANITY.computeIfAbsent(p.getUUID(), k -> new Sanity()); }
    /** Runs once per second. Staggered, cached, no world scans beyond the player's own surroundings. */
    private void slowTick(MinecraftServer server) {
        if (!CFG.enabled || !CFG.sanity) return;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            Sanity s = sanityOf(p); int light = p.level().getMaxLocalRawBrightness(p.blockPosition()); boolean dark = light < 5; boolean night = p.level().isDarkOutside();
            float d = Sanity.tickDelta(dark, night && p.level().canSeeSky(p.blockPosition()), p.getY() < 40, light > 11, false, p.getFoodData().getFoodLevel() > 14, false);
            if (p.getMainHandItem().is(ModItems.SHARD) || p.getOffhandItem().is(ModItems.SHARD)) Items.holdShard(s);
            if (p.level().getEntitiesOfClass(net.minecraft.world.entity.player.Player.class, p.getBoundingBox().inflate(10), q -> q != p && q.isAlive()).size() > 0) s.add(0.2f);       // friends nearby
            if (p.isSleeping()) s.add(Sanity.BED_RESTORE / 8f);                                                                                                                       // sleeping restores over the night
            for (var he : p.level().getEntitiesOfClass(dev.hollowwatch.entity.HorrorEntity.class, p.getBoundingBox().inflate(32), e -> true)) { var look = p.getLookAngle().normalize(); var to = he.position().add(0, he.getBbHeight() / 2, 0).subtract(p.getEyePosition()).normalize(); if (look.dot(to) > 0.9 && p.hasLineOfSight(he) && he.def.attacker()) { s.add(Sanity.lookDrain(he.def.id()) / 4f); break; } } // looking at a creature drains by type
            Mirage mg = MIRAGES.computeIfAbsent(p.getUUID(), k -> new Mirage(k.getLeastSignificantBits(), CFG.quality)); Mirage.Event me = mg.tick(s, CFG.intensity > 0);
            if (me != null) { if (me.kind() == Mirage.Kind.FAKE_CHAT) whisper(p, me.id(), server.getTickCount()); else ServerPlayNetworking.send(p, new Payloads.MirageEvent(me.kind().ordinal(), me.id(), me.durationTicks())); }
            Spawner.maybeSpawn(p, server.getTickCount());
            s.add(d * CFG.intensity); ServerPlayNetworking.send(p, new Payloads.SanitySync(s.get(), s.tier().ordinal()));
            ServerPlayNetworking.send(p, new Payloads.FogSync(CFG.fogIntensity, p.getY() < 20, night && p.level().canSeeSky(p.blockPosition()), 0f, false));
        }
    }
    /** Private message to exactly one player; rate-limited by that player's ChatBank cooldown. */
    public static void whisper(ServerPlayer p, String category, long now) {
        if (!CFG.fakeChat) return; ChatBank cb = CHAT.computeIfAbsent(p.getUUID(), k -> new ChatBank(p.getUUID().getLeastSignificantBits(), 20 * 45)); String line = cb.next(category, now);
        if (line != null) p.sendSystemMessage(net.minecraft.network.chat.Component.literal(line).withStyle(net.minecraft.ChatFormatting.DARK_GRAY, net.minecraft.ChatFormatting.ITALIC));
    }
    /** Scare packet goes ONLY to `victim`; nobody else's screen is touched. Enforces cooldown + config toggles. */
    public static void scare(ServerPlayer victim, String creature, int kind, int len, long now) {
        if (!CFG.enabled || (kind == 2 ? !CFG.cinematics : !CFG.jumpscares)) return;
        if (kind != 1) { Long last = LAST_SCARE.get(victim.getUUID()); if (last != null && now - last < CFG.jumpscareCooldownSeconds * 20L) return; LAST_SCARE.put(victim.getUUID(), now); } // death scares are never rate-limited away
        ServerPlayNetworking.send(victim, new Payloads.Scare(creature, kind, len));
    }
}
