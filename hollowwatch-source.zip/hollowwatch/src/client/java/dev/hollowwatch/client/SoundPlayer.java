package dev.hollowwatch.client;
// NOT COMPILED. Plays a registered hollowwatch sound for the local player only; positional, randomized pitch, concurrent sounds capped by Quality.
import net.minecraft.client.Minecraft; import net.minecraft.client.resources.sounds.SimpleSoundInstance; import net.minecraft.sounds.*; import net.minecraft.util.RandomSource;
public final class SoundPlayer {
    private static int inFlight; private static long windowStart;
    public static void play(String id, double x, double y, double z) {
        long now = System.currentTimeMillis(); if (now - windowStart > 2000) { windowStart = now; inFlight = 0; } if (inFlight >= HollowWatchClient.quality().maxSoundsInFlight) return; var ev = dev.hollowwatch.ModRegistry.SOUNDS.get(id); if (ev == null) return; inFlight++;
        Minecraft.getInstance().getSoundManager().play(new SimpleSoundInstance(ev, SoundSource.HOSTILE, 0.8f, 0.9f + (float) Math.random() * 0.2f, RandomSource.create(), x, y, z));
    }
}
