package dev.hollowwatch.client;
// NOT COMPILED. Renders the JSON bone models: per-bone rotation/translation from core.Anim, cubes via core.MeshBuilder. Written against assumed 26.x EntityRenderer/RenderState API (extract-state pattern).
import com.mojang.blaze3d.vertex.*; import dev.hollowwatch.Creatures; import dev.hollowwatch.core.*; import dev.hollowwatch.entity.HorrorEntity;
import net.minecraft.client.renderer.*; import net.minecraft.client.renderer.entity.*; import net.minecraft.client.renderer.entity.state.EntityRenderState; import net.minecraft.resources.Identifier; import net.minecraft.client.renderer.rendertype.RenderTypes; import java.util.*;
public class HorrorRenderer extends EntityRenderer<HorrorEntity, HorrorRenderer.State> {
    public static final class State extends EntityRenderState { public String id = "pale_stalker"; public String clip = "idle"; public float clipTime; public float alpha = 1f; public float headYaw, headPitch; public double distToCamera; }
    private final Map<String, float[][]> meshCache = new HashMap<>(); private final Map<String, Identifier> texCache = new HashMap<>(); private static final float[] POSE = new float[6]; // reused: no per-frame allocation
    public HorrorRenderer(EntityRendererProvider.Context ctx) { super(ctx); }
    @Override public State createRenderState() { return new State(); }
    @Override public void extractRenderState(HorrorEntity e, State s, float pt) { super.extractRenderState(e, s, pt); s.id = e.def.id(); s.clip = e.syncedClip(); s.clipTime = e.clipTime(pt); s.alpha = e.visibleAlpha(); s.headYaw = e.getYHeadRot() - e.getYRot(); s.headPitch = e.getXRot(); s.distToCamera = s.distanceToCameraSq; }
    @Override public void submit(State s, PoseStack ps, net.minecraft.client.renderer.SubmitNodeCollector out, net.minecraft.client.renderer.state.CameraRenderState cam) {
        HollowWatchClient.BREAKER.run("entity_render", () -> draw(s, ps, out), null);
    }
    private void draw(State s, PoseStack ps, net.minecraft.client.renderer.SubmitNodeCollector out) {
        if (s.alpha <= 0.01f) return; ModelLoader.Model m = ModelLoader.get(s.id); Identifier tex = texCache.computeIfAbsent(s.id, k -> Identifier.fromNamespaceAndPath("hollowwatch", "textures/entity/" + k + ".png"));
        // Anim LOD: beyond the quality's animUpdateDistance use the idle pose (skip keyframe sampling)
        double lim = HollowWatchClient.quality().animUpdateDistance; boolean animate = s.distToCamera < lim * lim; Anim.Clip clip = Anim.LIB.getOrDefault(s.clip, Anim.LIB.get("idle"));
        float[][] meshes = meshCache.computeIfAbsent(s.id, k -> buildMeshes(m)); ps.pushPose(); ps.scale(m.scale(), m.scale(), m.scale()); ps.mulPose(com.mojang.math.Axis.YP.rotationDegrees(180f - s.bodyRot));
        int ci = 0; for (ModelLoader.Bone b : m.bones()) { ps.pushPose(); ps.translate(b.pivot()[0] / 16f, b.pivot()[1] / 16f, b.pivot()[2] / 16f);
            Anim.sample(clip, b.name(), animate ? s.clipTime : 0f, POSE); float yawAdd = b.name().equals("head") ? s.headYaw : 0f;
            ps.translate(POSE[3] / 16f, POSE[4] / 16f, POSE[5] / 16f); ps.mulPose(new org.joml.Quaternionf().rotationZYX((float) Math.toRadians(POSE[2]), (float) Math.toRadians(POSE[1] + yawAdd), (float) Math.toRadians(POSE[0]))); ps.translate(-b.pivot()[0] / 16f, -b.pivot()[1] / 16f, -b.pivot()[2] / 16f);
            final int base = ci; final int cnt = b.cubes().size(); ps.scale(1f, -1f, 1f); // model Y-up -> render Y-down convention
            out.submitCustomGeometry(ps, RenderTypes.entityCutoutNoCull(tex), (pose, vc) -> { for (int c = 0; c < cnt; c++) emit(vc, pose, meshes[base + c], s.lightCoords, s.alpha); });
            ci += cnt; ps.popPose(); } ps.popPose();
    }
    private static void emit(VertexConsumer vc, PoseStack.Pose pose, float[] mesh, int light, float alpha) { int a = (int) (alpha * 255); for (int v = 0; v < MeshBuilder.VERTS; v++) { int o = v * MeshBuilder.STRIDE; vc.addVertex(pose, mesh[o], mesh[o + 1], mesh[o + 2]).setColor(255, 255, 255, a).setUv(mesh[o + 3], mesh[o + 4]).setOverlay(net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose, mesh[o + 5], mesh[o + 6], mesh[o + 7]); } }
    private static float[][] buildMeshes(ModelLoader.Model m) { List<float[]> l = new ArrayList<>(); for (ModelLoader.Bone b : m.bones()) for (ModelLoader.Cube c : b.cubes()) l.add(MeshBuilder.cube(c.size(), c.origin(), c.uv(), c.texelsPerUnit(), m.tex(), m.tex())); return l.toArray(new float[0][]); }
}
