package dev.hollowwatch.client;
// NOT COMPILED against 26.3. Client-only (client source set): HUD, fog, scare overlay, admin screen, keybind.
import dev.hollowwatch.*; import dev.hollowwatch.core.*; import dev.hollowwatch.net.Payloads;
import net.fabricmc.api.ClientModInitializer; import net.fabricmc.fabric.api.client.networking.v1.*; import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents; import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping; import net.minecraft.client.Minecraft; import com.mojang.blaze3d.platform.InputConstants;
public class HollowWatchClient implements ClientModInitializer {
    public static final CircuitBreaker BREAKER = new CircuitBreaker(3);
    public static volatile Sanity sanity = new Sanity(); public static final FogController FOG = new FogController(); public static volatile Cinematic active;
    public static float baseFogIntensity = 1f; public static boolean deepCave, forestNight; public static float prox;
    static KeyMapping adminKey; private static int fpsSamples, fpsSum, fpsTicks;
    /** Quality preset used for client-side LOD/caps: config value, auto-picked once from a ~10 s FPS probe on first launch. */
    public static Quality quality() { return dev.hollowwatch.HollowWatch.CFG.quality; }
    private static void autoQuality(Minecraft mc) { if (!dev.hollowwatch.HollowWatch.CFG.qualityAuto || fpsSamples >= 10 || mc.level == null) return; if (++fpsTicks % 20 != 0) return; fpsSum += mc.getFps(); if (++fpsSamples == 10) { dev.hollowwatch.HollowWatch.CFG.quality = Quality.fromFps(fpsSum / 10.0); dev.hollowwatch.HollowWatch.CFG.qualityAuto = false; } }
    @Override public void onInitializeClient() {
        adminKey = KeyMappingHelper.registerKeyMapping(new KeyMapping("key.hollowwatch.admin", InputConstants.Type.KEYSYM, org.lwjgl.glfw.GLFW.GLFW_KEY_H, KeyMapping.Category.MISC));
        ClientPlayNetworking.registerGlobalReceiver(Payloads.SanitySync.TYPE, (p, ctx) -> ctx.client().execute(() -> { Sanity s = new Sanity(); s.set(p.value()); sanity = s; }));
        ClientPlayNetworking.registerGlobalReceiver(Payloads.FogSync.TYPE, (p, ctx) -> ctx.client().execute(() -> { if (p.clear()) FOG.clearInstantly(); else { baseFogIntensity = p.intensity(); deepCave = p.deepCave(); forestNight = p.forestNight(); prox = p.creatureProx(); } }));
        ClientPlayNetworking.registerGlobalReceiver(Payloads.Scare.TYPE, (p, ctx) -> ctx.client().execute(() -> BREAKER.run("cinematic", () -> { active = new Cinematic(p.creature(), p.lengthTicks()); ScareOverlay.start(p.creature(), p.kind()); }, ScareOverlay::stop)));
        ClientPlayNetworking.registerGlobalReceiver(Payloads.OpenAdmin.TYPE, (p, ctx) -> ctx.client().execute(() -> Minecraft.getInstance().setScreen(new AdminScreen(p.snapshot()))));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> BREAKER.run("client_tick", () -> {
            while (adminKey.consumeClick()) ClientPlayNetworking.send(new Payloads.AdminOpenRequest());   // server answers only if op
            Cinematic c = active; if (c != null) { if (mc.player == null || mc.player.isDeadOrDying() || mc.screen != null) c.release(); c.tick(); if (!c.active()) { active = null; ScareOverlay.stop(); } }
            float t = 0.05f; FOG.target(mc.options.renderDistance().get() * 8f, mc.options.renderDistance().get() * 16f, deepCave, forestNight, sanity.fogThickening(), sanity.redTint(), prox, baseFogIntensity, false); FOG.step(t);
        }, () -> { active = null; ScareOverlay.stop(); }));
        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.DISCONNECT.getClass(); // (no-op reference; disconnect cleanup below)
        ClientPlayConnectionEvents.DISCONNECT.register((h, mc) -> { active = null; ScareOverlay.stop(); sanity = new Sanity(); });
        ClientPlayNetworking.registerGlobalReceiver(Payloads.MirageEvent.TYPE, (p, ctx) -> ctx.client().execute(() -> BREAKER.run("mirage", () -> {
            switch (Mirage.Kind.values()[Math.max(0, Math.min(p.kind(), Mirage.Kind.values().length - 1))]) {
                case FAKE_CREATURE -> { ClientEffects.fakeCreature = p.id(); ClientEffects.fakeCreatureTicks = p.duration(); } case LIGHT_FLICKER -> ClientEffects.flickerTicks = p.duration(); case FOV_WARP -> ClientEffects.fovWarpTicks = p.duration();
                case FAKE_SOUND -> SoundPlayer.play(p.id(), Minecraft.getInstance().player.getX() + 3, Minecraft.getInstance().player.getY(), Minecraft.getInstance().player.getZ() - 3); default -> { } } }, null)));
        ClientPlayNetworking.registerGlobalReceiver(Payloads.PlaySound.TYPE, (p, ctx) -> ctx.client().execute(() -> BREAKER.run("sound", () -> SoundPlayer.play(p.sound(), p.x(), p.y(), p.z()), null)));
        for (var e : dev.hollowwatch.ModRegistry.ENTITIES.values()) net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry.register(e, HorrorRenderer::new);
        net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry.addLast(net.minecraft.resources.Identifier.fromNamespaceAndPath("hollowwatch", "overlays"), (g, tk) -> BREAKER.run("overlay", () -> ClientEffects.drawOverlays(g), null));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> BREAKER.run("effects_tick", () -> { ClientEffects.tick(); ClientEffects.cinematicCamera(mc); autoQuality(mc); }, null));
        SanityHud.register(); ModelLoader.preload();
    }
}
