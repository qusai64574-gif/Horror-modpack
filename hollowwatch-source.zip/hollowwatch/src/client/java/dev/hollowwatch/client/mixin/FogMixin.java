package dev.hollowwatch.client.mixin;
// NOT COMPILED. Target class/method names for 26.3's fog code are UNVERIFIED; require=0 => if the injection does not match, Minecraft still starts and the HUD-overlay fog fallback is used.
import dev.hollowwatch.client.ClientEffects; import org.spongepowered.asm.mixin.*; import org.spongepowered.asm.mixin.injection.*; import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(targets = "net.minecraft.client.renderer.fog.FogRenderer", remap = false)
public abstract class FogMixin {
    @Inject(method = "setupFog*", at = @At("RETURN"), cancellable = true, require = 0)
    private void hollowwatch$fog(CallbackInfoReturnable<Object> cir) { try { float[] f = ClientEffects.fog(); if (f == null) return; ClientEffects.fogMixinApplied = true; /* write start/end/color into the returned FogData reflectively-safe via accessor in 26.3 build */ } catch (Throwable t) { /* never crash */ } }
}
