package dev.hollowwatch.client.mixin;
import dev.hollowwatch.client.ClientEffects; import org.spongepowered.asm.mixin.*; import org.spongepowered.asm.mixin.injection.*; import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(targets = "net.minecraft.client.renderer.GameRenderer", remap = false)
public abstract class FovMixin {   // UNVERIFIED target for 26.3; require=0 keeps the game starting if it does not match
    @Inject(method = "getFov*", at = @At("RETURN"), cancellable = true, require = 0)
    private void hollowwatch$fov(CallbackInfoReturnable<Float> cir) { try { float s = ClientEffects.fovScale(); if (s != 1f) { ClientEffects.fovMixinApplied = true; cir.setReturnValue(cir.getReturnValue() * s); } } catch (Throwable t) { } }
}
