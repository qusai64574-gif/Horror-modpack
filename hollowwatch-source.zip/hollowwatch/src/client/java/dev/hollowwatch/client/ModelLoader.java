package dev.hollowwatch.client;
import com.google.gson.*; import dev.hollowwatch.Creatures; import java.io.*; import java.util.*;
/** Loads assets/hollowwatch/models/entity/<id>.json (bones/cubes/uv). A missing or corrupt model NEVER crashes: logs one warning and falls back to a single box. */
public final class ModelLoader {
    public record Cube(String name, float[] size, float[] origin, int[] uv, int texelsPerUnit) {}
    public record Bone(String name, String parent, float[] pivot, List<Cube> cubes) {}
    public record Model(int tex, int uvScale, float scale, List<Bone> bones) {}
    private static final Map<String, Model> CACHE = new HashMap<>(); private static final Set<String> WARNED = new HashSet<>();
    public static void preload() { for (Creatures.Def d : Creatures.ALL) get(d.id()); }
    public static Model get(String id) { return CACHE.computeIfAbsent(id, ModelLoader::load); }
    private static Model load(String id) {
        try (InputStream in = ModelLoader.class.getResourceAsStream("/assets/hollowwatch/models/entity/" + id + ".json")) {
            if (in == null) throw new FileNotFoundException(id); JsonObject o = JsonParser.parseReader(new InputStreamReader(in)).getAsJsonObject(); List<Bone> bones = new ArrayList<>();
            for (JsonElement be : o.getAsJsonArray("bones")) { JsonObject b = be.getAsJsonObject(); List<Cube> cs = new ArrayList<>();
                for (JsonElement ce : b.getAsJsonArray("cubes")) { JsonObject c = ce.getAsJsonObject(); cs.add(new Cube(c.get("name").getAsString(), f3(c.getAsJsonArray("size")), f3(c.getAsJsonArray("origin")), new int[]{c.getAsJsonArray("uv").get(0).getAsInt(), c.getAsJsonArray("uv").get(1).getAsInt()}, c.has("ts") ? c.get("ts").getAsInt() : o.get("uv_scale").getAsInt())); }
                bones.add(new Bone(b.get("name").getAsString(), b.get("parent").isJsonNull() ? null : b.get("parent").getAsString(), f3(b.getAsJsonArray("pivot")), cs)); }
            return new Model(o.getAsJsonArray("texture_size").get(0).getAsInt(), o.get("uv_scale").getAsInt(), o.get("scale").getAsFloat(), bones);
        } catch (Throwable t) { if (WARNED.add(id)) System.err.println("[hollowwatch] model '" + id + "' unavailable, using fallback box: " + t);
            return new Model(16, 1, 1f, List.of(new Bone("body", null, new float[]{0, 0, 0}, List.of(new Cube("box", new float[]{8, 24, 8}, new float[]{-4, 0, -4}, new int[]{0, 0}, 1))))); }
    }
    private static float[] f3(JsonArray a) { return new float[]{a.get(0).getAsFloat(), a.get(1).getAsFloat(), a.get(2).getAsFloat()}; }
}
