package dev.hollowwatch.client;
/** Pre-baked sprite overlay (textures/gui + entity face) + FOV/shake driven by Cinematic. Releases on any error; never traps input (no screen is opened, no input is consumed). */
public final class ScareOverlay {
    private static String creature; private static int kind;
    public static void start(String c, int k) { creature = c; kind = k; }
    public static void stop() { creature = null; }
    public static boolean active() { return creature != null; }
    public static String creature() { return creature; }
    /** Called from the FOV / camera-shake hooks: returns FOV multiplier (1 = none). */
    public static float fovScale() { var c = HollowWatchClient.active; return c != null && c.active() ? c.fovScale() : 1f; }
}
