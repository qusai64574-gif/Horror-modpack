package dev.hollowwatch.client;
// NOT COMPILED. Real GUI: every button sends a server packet; server verifies op on every action.
import dev.hollowwatch.net.Payloads; import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.components.Button; import net.minecraft.client.gui.screens.Screen; import net.minecraft.network.chat.Component;
public class AdminScreen extends Screen {
    private final String snap; private int tab = 0; public static boolean dbg; private static final String[] TABS = {"Global", "Entities", "Players", "Events", "World", "Debug"};
    public AdminScreen(String snapshot) { super(Component.literal("Hollow Watch Admin")); snap = snapshot; }
    private void act(String a, String arg) { ClientPlayNetworking.send(new Payloads.AdminAction(a, arg, "")); }
    @Override protected void init() {
        for (int i = 0; i < TABS.length; i++) { final int t = i; addRenderableWidget(Button.builder(Component.literal(TABS[i]), b -> { tab = t; rebuildWidgets(); }).bounds(10 + i * 62, 8, 60, 20).build()); }
        int y = 40, x = 10;
        switch (tab) {
            case 0 -> { btn(x, y, "Enable", "global.enable", "true"); btn(x + 90, y, "Pause", "global.enable", "false"); btn(x, y + 24, "Intensity 0.5", "global.intensity", "0.5"); btn(x + 90, y + 24, "Intensity 1", "global.intensity", "1"); btn(x + 180, y + 24, "Intensity 2", "global.intensity", "2");
                btn(x, y + 48, "POTATO", "global.quality", "POTATO"); btn(x + 60, y + 48, "LOW", "global.quality", "LOW"); btn(x + 120, y + 48, "MEDIUM", "global.quality", "MEDIUM"); btn(x + 180, y + 48, "HIGH", "global.quality", "HIGH");
                btn(x, y + 72, "Scares on", "global.jumpscares", "true"); btn(x + 90, y + 72, "Scares off", "global.jumpscares", "false"); btn(x, y + 96, "Cinematics on", "global.cinematics", "true"); btn(x + 90, y + 96, "Cinematics off", "global.cinematics", "false");
                btn(x, y + 120, "Fog on", "global.fog", "true"); btn(x + 90, y + 120, "Fog off", "global.fog", "false"); btn(x, y + 144, "Sanity on", "global.sanity", "true"); btn(x + 90, y + 144, "Sanity off", "global.sanity", "false"); btn(x, y + 168, "Chat on", "global.chat", "true"); btn(x + 90, y + 168, "Chat off", "global.chat", "false"); }
            case 2 -> { btn(x, y, "Sanity 100", "player.sanity.set", "100"); btn(x + 90, y, "Sanity 50", "player.sanity.set", "50"); btn(x + 180, y, "Sanity 10", "player.sanity.set", "10"); btn(x, y + 24, "Reset sanity", "player.sanity.reset", "");
                btn(x, y + 72, "Start encounter", "player.encounter.start", ""); btn(x + 90, y + 72, "Stop encounters", "player.encounter.stop", ""); btn(x + 180, y + 72, "Intensity 0.5", "player.intensity", "0.5"); btn(x, y + 48, "Test scare: stalker", "player.scare.test", "pale_stalker"); btn(x + 130, y + 48, "Test cinematic: giant", "player.cinematic.test", "mask_giant"); }
            case 3 -> { btn(x, y, "Clear fog now", "event.fog.clear", ""); btn(x, y + 24, "Test whisper", "event.whisper", "whispers"); btn(x, y + 48, "Test mirage", "event.mirage", "turner"); btn(x + 90, y + 48, "Test sound: knock", "event.sound", "knock"); btn(x, y + 72, "Test sound: help", "event.sound", "help"); }
            case 4 -> btn(x, y, "Reset horror state", "world.reset", "");
            case 1 -> { int i = 0; for (var d : dev.hollowwatch.Creatures.ALL) { final String id = d.id(); addRenderableWidget(Button.builder(Component.literal(d.name().length() > 16 ? d.name().substring(0, 15) + "." : d.name()), b -> act("entity.spawn", id)).bounds(x + (i % 4) * 100, y + (i / 4) * 22, 98, 20).build()); i++; }
                int yy = y + ((i + 3) / 4) * 22 + 6; btn(x, yy, "Remove near", "entity.remove_near", ""); btn(x + 90, yy, "Remove ALL", "entity.remove_all", ""); btn(x + 180, yy, "Block break on", "entity.toggle_blockbreak", "true"); btn(x + 270, yy, "Block break off", "entity.toggle_blockbreak", "false"); }
            case 5 -> { btn(x, y, "Stats (chat)", "debug.stats", ""); btn(x + 90, y, "Remove orphans", "debug.cleanup", ""); btn(x + 180, y, "Save data now", "debug.save", ""); addRenderableWidget(Button.builder(Component.literal(dbg ? "State overlay: ON" : "State overlay: OFF"), b -> { dbg = !dbg; rebuildWidgets(); }).bounds(x, y + 24, 140, 20).build()); }
            default -> { }
        }
    }
    private void btn(int x, int y, String label, String a, String arg) { addRenderableWidget(Button.builder(Component.literal(label), b -> act(a, arg)).bounds(x, y, 86, 20).build()); }
    @Override public void render(net.minecraft.client.gui.GuiGraphics g, int mx, int my, float dt) { super.render(g, mx, my, dt); g.drawString(font, snap, 10, height - 14, 0xAAAAAA); if (dbg) { var st = HollowWatchClient.sanity; g.drawString(font, "sanity=" + (int) st.get() + " tier=" + st.tier() + " fogMixin=" + ClientEffects.fogMixinApplied + " fovMixin=" + ClientEffects.fovMixinApplied + " cin=" + (HollowWatchClient.active != null), 10, height - 28, 0xFFDD66); } }
}
