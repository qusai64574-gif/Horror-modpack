package dev.hollowwatch.client;
// NOT COMPILED. Applies fog, FOV, camera shake, scare overlay, mirage visuals. Mixin hooks live in client/mixin/* with require=0 (a failed injection logs and does nothing). Mixin-FREE fallback: HUD vignette overlay approximates fog.
import dev.hollowwatch.core.*; import net.minecraft.client.Minecraft; import net.minecraft.client.gui.GuiGraphics;
public final class ClientEffects {
    public static volatile boolean fogMixinApplied = false;   // set by FogMixin on its first successful run
    public static volatile boolean fovMixinApplied = false;
    public static int flickerTicks, fovWarpTicks; public static String fakeCreature; public static int fakeCreatureTicks;
    /** Called by FogMixin: returns {start,end,r,g,b} or null to leave vanilla fog untouched. Cheap, no allocation (static buffer). */
    private static final float[] FOGBUF = new float[5];
    public static float[] fog() { if (!dev.hollowwatch.HollowWatch.CFG.fog || HollowWatchClient.BREAKER.ok("fog") == false) return null; var f = HollowWatchClient.FOG; FOGBUF[0] = f.start; FOGBUF[1] = f.end; FOGBUF[2] = f.r; FOGBUF[3] = f.g; FOGBUF[4] = f.b; return FOGBUF; }
    /** FOV multiplier from cinematic + mirage warp. */
    public static float fovScale() { float s = ScareOverlay.fovScale(); if (fovWarpTicks > 0) s *= 1f + 0.15f * (float) Math.sin(fovWarpTicks * 0.5); return s; }
    public static void tick() { if (flickerTicks > 0) flickerTicks--; if (fovWarpTicks > 0) fovWarpTicks--; if (fakeCreatureTicks > 0 && --fakeCreatureTicks == 0) fakeCreature = null; }
    /** Draw-order: fallback fog (only if the mixin did not apply), red vignette, flicker, scare sprite + glitch noise, fake-creature silhouette. All drawn with GuiGraphics fills/blits of pre-baked textures. */
    public static void drawOverlays(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance(); int w = mc.getWindow().getGuiScaledWidth(), h = mc.getWindow().getGuiScaledHeight(); Sanity s = HollowWatchClient.sanity;
        if (!fogMixinApplied && dev.hollowwatch.HollowWatch.CFG.fog) { int a = (int) (Math.min(0.55f, 0.15f + s.fogThickening() * 0.4f + HollowWatchClient.prox * 0.2f) * 255); g.fill(0, 0, w, h, (a << 24) | 0x0a0c10); }
        if (s.redTint() > 0) g.fill(0, 0, w, h, ((int) (s.redTint() * 90) << 24) | 0x7a0000);
        if (flickerTicks > 0 && (flickerTicks / 3) % 2 == 0) g.fill(0, 0, w, h, 0x99000000);
        var c = HollowWatchClient.active; if (c != null && c.active() && ScareOverlay.active()) {
            int fade = (int) (Math.min(1f, c.progress() * 6f) * 255); var tex = net.minecraft.resources.Identifier.fromNamespaceAndPath("hollowwatch", "textures/entity/" + ScareOverlay.creature() + ".png");
            // face slammed into view: enlarge the head region of the entity texture (pre-baked sprite, no geometry); shake via offset
            int sz = (int) (h * (0.6f + 0.5f * c.progress())); int sx = (int) ((Math.sin(System.nanoTime() / 4e7) * c.shake() * 3)); int sy = (int) ((Math.cos(System.nanoTime() / 3e7) * c.shake() * 3));
            g.fill(0, 0, w, h, (Math.min(220, fade) << 24)); g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, tex, w / 2 - sz / 2 + sx, h / 2 - sz / 2 + sy, 0, 0, sz, sz, 64, 64, 256, 256, (fade << 24) | 0xFFFFFF);
            var noise = net.minecraft.resources.Identifier.fromNamespaceAndPath("hollowwatch", "textures/gui/glitch_noise.png"); g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, noise, 0, 0, (int) (Math.random() * 32), (int) (Math.random() * 32), w, h, 32, 32, 64, 64, ((fade / 3) << 24) | 0xFFFFFF);
        }
        if (fakeCreature != null) { var tex = net.minecraft.resources.Identifier.fromNamespaceAndPath("hollowwatch", "textures/entity/" + fakeCreature + ".png"); int sz = h / 3; g.blit(net.minecraft.client.renderer.RenderPipelines.GUI_TEXTURED, tex, w - sz - 10, h / 2 - sz / 2, 0, 0, sz, sz, 64, 64, 256, 256, 0x55FFFFFF); }
    }
    /** Cinematic kill camera: faces the viewer to the creature and freezes movement for at most Cinematic.HARD_TIMEOUT_TICKS. No input is consumed (player may still open the pause menu: that releases the cinematic). */
    public static void cinematicCamera(Minecraft mc) {
        var c = HollowWatchClient.active; if (c == null || !c.active() || mc.player == null || mc.level == null) return;
        var best = mc.level.getEntitiesOfClass(dev.hollowwatch.entity.HorrorEntity.class, mc.player.getBoundingBox().inflate(8), e -> e.def.id().equals(c.creature)); if (best.isEmpty()) return; var e = best.get(0);
        double dx = e.getX() - mc.player.getX(), dz = e.getZ() - mc.player.getZ(), dy = (e.getEyeY() - mc.player.getEyeY()); float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90f), pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        mc.player.setYRot(mc.player.getYRot() + net.minecraft.util.Mth.wrapDegrees(yaw - mc.player.getYRot()) * 0.5f); mc.player.setXRot(mc.player.getXRot() + (pitch - mc.player.getXRot()) * 0.5f); mc.player.setDeltaMovement(mc.player.getDeltaMovement().multiply(0.2, 1, 0.2));
    }
}
