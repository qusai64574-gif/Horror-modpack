package dev.hollowwatch.client;
// NOT COMPILED: HUD via Fabric HudElementRegistry (assumed). Original design: 5 mind icons above the hotbar-left, fill L->R, tier color, pulse + shake when low.
import dev.hollowwatch.core.Sanity;
import net.minecraft.client.gui.GuiGraphics; import net.minecraft.client.Minecraft;
public final class SanityHud {
    public static void register() {
        net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry.addLast(net.minecraft.resources.Identifier.fromNamespaceAndPath("hollowwatch", "sanity"), (g, tick) -> HollowWatchClient.BREAKER.run("hud", () -> draw(g), null));
    }
    private static void draw(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance(); if (mc.player == null || mc.options.hideGui || !dev.hollowwatch.HollowWatch.CFG.sanity) return; Sanity s = HollowWatchClient.sanity;
        int w = mc.getWindow().getGuiScaledWidth(), h = mc.getWindow().getGuiScaledHeight(); long t = System.currentTimeMillis();
        float pulse = s.hudPulseHz() == 0 ? 1f : 1f + 0.12f * (float) Math.sin(t / 1000.0 * Math.PI * 2 * s.hudPulseHz()); int shake = s.hudShake() == 0 ? 0 : (int) (Math.sin(t / 37.0) * s.hudShake());
        int x0 = w / 2 - 91 + shake, y0 = h - 49 - 22; int tier = s.tier().color;
        for (int i = 0; i < Sanity.SEGMENTS; i++) { float f = s.segmentFill(i); int x = x0 + i * 18; g.fill(x + 2, y0 + 2, x + 16, y0 + 16, 0x66000000); int fh = (int) (14 * f * pulse); g.fill(x + 2, y0 + 16 - fh, x + 16, y0 + 16, tier); }
    }
}
