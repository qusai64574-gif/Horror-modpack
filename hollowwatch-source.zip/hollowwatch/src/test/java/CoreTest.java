import dev.hollowwatch.core.*; import java.io.*; import java.util.*;
public class CoreTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else { fail++; System.out.println("FAIL " + n); } }
    public static void main(String[] a) throws Exception {
        // ChatBank
        check("chat >=100 lines", ChatBank.total() >= 100); check("chat 12 categories", ChatBank.LINES.size() == 12);
        Set<String> all = new HashSet<>(); for (String[] arr : ChatBank.LINES.values()) all.addAll(Arrays.asList(arr)); check("chat lines unique", all.size() == ChatBank.total());
        ChatBank cb = new ChatBank(1, 100); String l1 = cb.next("watching", 0); check("chat first ok", l1 != null); check("chat cooldown", cb.next("watching", 50) == null);
        Set<String> seen = new HashSet<>(); long t = 200; int n = ChatBank.LINES.get("watching").length; boolean dup = false;
        seen.add(l1); for (int i = 1; i < n; i++) { String s = cb.next("watching", t); t += 200; if (!seen.add(s)) dup = true; } check("chat no repeats within a bag", !dup);
        // Sanity
        Sanity s = new Sanity(); s.add(-130); check("sanity clamp low", s.get() == 0); s.add(500); check("sanity clamp high", s.get() == 100);
        s.set(55); check("sanity seg fill", Math.abs(s.segmentFill(2) - 0.75f) < 1e-4 && s.segmentFill(0) == 1f && s.segmentFill(4) == 0f); check("sanity tier", s.tier() == Sanity.Tier.UNEASY);
        s.set(10); check("sanity broken-ish", s.tier() == Sanity.Tier.BROKEN && s.redTint() > .4f && s.spawnWeight() > 2.5f);
        check("sanity corrupt -> default", Sanity.deserialize("garbage").get() == 100f); check("sanity roundtrip", Sanity.deserialize(new Sanity() {{ set(42.5f); }}.serialize()).get() == 42.5f);
        check("sanity NaN safe", new Sanity() {{ set(Float.NaN); }}.get() == 100f);
        // Config
        File f = File.createTempFile("hwtest", ".properties"); try (Writer w = new FileWriter(f)) { w.write("intensity=notanumber\nquality=ultra\nfog=false\n"); }
        HorrorConfig c = new HorrorConfig(); c.load(f); check("config bad value -> default", c.intensity == 1.0f); check("config bad enum -> default", c.quality == Quality.MEDIUM); check("config bool read", !c.fog);
        c.intensity = 2f; c.save(f); HorrorConfig c2 = new HorrorConfig(); c2.load(f); check("config roundtrip", c2.intensity == 2f);
        try (Writer w = new FileWriter(f)) { w.write("\u0000\u0001garbage"); } HorrorConfig c3 = new HorrorConfig(); c3.load(f); check("config garbage no crash", c3.enabled);
        check("quality auto", Quality.fromFps(15) == Quality.POTATO && Quality.fromFps(200) == Quality.HIGH && Quality.POTATO.groundMistParticles == 0 && !Quality.POTATO.shaders);
        // StalkerBrain: full path + fairness
        HorrorConfig cfg = new HorrorConfig(); StalkerBrain b = new StalkerBrain(cfg); StalkerBrain.Obs o = new StalkerBrain.Obs(); o.night = true; o.hasCover = true; o.dist = 30; o.targetSanity = 30;
        o.observed = true; b.tick(o, 10); check("never leaves DORMANT while observed (no spawn in LOS)", b.state == StalkerBrain.State.DORMANT);
        o.observed = false; b.tick(o, 10); check("DORMANT->DISTANT_WATCH", b.state == StalkerBrain.State.DISTANT_WATCH);
        for (int i = 0; i < 25; i++) b.tick(o, 10); check("->APPROACH_HIDDEN", b.state == StalkerBrain.State.APPROACH_HIDDEN);
        o.observed = true; b.tick(o, 10); check("retreats when observed", b.state == StalkerBrain.State.RETREAT_WHEN_OBSERVED);
        o.observed = false; o.dist = 10; for (int i = 0; i < 12; i++) b.tick(o, 10); check("->FOLLOW", b.state == StalkerBrain.State.FOLLOW);
        o.dist = 6; b.tick(o, 10); check("->STALK_CLOSE at low sanity", b.state == StalkerBrain.State.STALK_CLOSE);
        o.dist = 3; b.tick(o, 10); check("->ATTACK", b.state == StalkerBrain.State.ATTACK);
        o.targetLight = true; b.tick(o, 10); check("light forces ABANDON (counterplay)", b.state == StalkerBrain.State.ABANDON);
        for (int i = 0; i < 6; i++) b.tick(o, 10); check("->RETURN_LATER with cooldown", b.state == StalkerBrain.State.RETURN_LATER && b.cooldownTicks > 0);
        StalkerBrain b2 = new StalkerBrain(cfg); b2.state = StalkerBrain.State.STALK_CLOSE; b2.encounterTicks = cfg.maxEncounterSeconds * 20 + 10; StalkerBrain.Obs o2 = new StalkerBrain.Obs(); b2.tick(o2, 10); check("time cap forces ABANDON", b2.state == StalkerBrain.State.ABANDON);
        StalkerBrain b3 = new StalkerBrain(cfg); b3.state = StalkerBrain.State.ATTACK; for (int i = 0; i < b3.maxHits(); i++) b3.registerHit(); b3.tick(o2, 10); check("lethality cap forces ABANDON", b3.state == StalkerBrain.State.ABANDON);
        // Fog
        FogController fc = new FogController(); fc.target(64, 192, true, false, 1f, 1f, 1f, 3f, false); for (int i = 0; i < 600; i++) fc.step(0.05f);
        check("fog survivable floor", fc.end >= fc.minEnd - 0.01f); check("fog red tint at low sanity", fc.r > fc.g); fc.clearInstantly(); for (int i = 0; i < 600; i++) fc.step(0.05f); check("fog clears", fc.end > 200);
        // Cinematic
        Cinematic ci = new Cinematic("x", 9999); int ticks = 0; while (ci.active() && ticks < 10000) { ci.tick(); ticks++; } check("cinematic hard timeout <= 80 ticks", ticks <= Cinematic.HARD_TIMEOUT_TICKS);
        Cinematic c4 = new Cinematic("y", 60); c4.tick(); c4.release(); check("cinematic release", !c4.active());
        // Circuit breaker
        CircuitBreaker cbk = new CircuitBreaker(3); int[] trips = {0}; for (int i = 0; i < 6; i++) cbk.run("render", () -> { throw new RuntimeException("boom"); }, () -> trips[0]++); check("breaker trips once, then feature off", trips[0] == 1 && !cbk.ok("render"));

        // Animation
        Anim.Player ap = new Anim.Player(); float[] o3 = new float[6]; ap.pose("leg_l", o3); check("anim rest pose no T-pose (idle sampled)", Math.abs(o3[0]) < 1e-3);
        ap.play("run"); ap.tick(.05f); ap.pose("leg_l", o3); float mid = o3[0]; ap.tick(.05f); ap.pose("leg_l", o3); check("anim blends within 2 ticks", Anim.Player.BLEND_TICKS == 2 && o3[0] != mid);
        for (String cn : Anim.LIB.keySet()) { Anim.Clip ac = Anim.LIB.get(cn); for (String bn : ac.tracks.keySet()) { float[] t3 = new float[6]; Anim.sample(ac, bn, 0.123f, t3); for (float v : t3) if (Float.isNaN(v)) check("anim NaN " + cn, false); } }
        String[] need = {"idle","walk","run","sprint","attack","grab","look","crouch","peek","neck_twist","spawn_reveal","vanish","death"}; boolean allc = true; for (String nn : need) allc &= Anim.LIB.containsKey(nn); check("anim required clips present", allc);
        Anim.Clip nt = Anim.LIB.get("neck_twist"); float[] hh = new float[6]; Anim.sample(nt, "head", 1.6f, hh); check("neck twist passes 180 deg", hh[1] > 180);
        ap.play("nonexistent"); check("anim unknown clip ignored", ap.current().equals("run")); check("anim choose", Anim.choose("", 6).equals("sprint") && Anim.choose("", 0).equals("idle") && Anim.choose("TWIST", 0).equals("neck_twist"));
        // Creature AIs
        HorrorConfig hc = new HorrorConfig(); String[] ids = {"mask_giant","rotted_skull","horned_peeper","charred_brute","long_crawler","broken_script","cave_wall_face","birch_anomaly","cave_colossus","turner","follower","ceiling_hanger","wall_crawler","fake_torch","window_face","window_hand","roof_silhouette","hollow_titan","marsh_walker"};
        for (String id : ids) { CreatureAI.Brain br = CreatureAI.create(id, hc); check("ai exists " + id, br != null); CreatureAI.Obs ob = new CreatureAI.Obs(); ob.dist = 12; ob.night = true; ob.targetInCave = true; ob.sanity = 30; boolean despawned = false;
            for (int i = 0; i < 3000 && !despawned; i++) { if (i == 50) ob.observed = true; if (i == 90) ob.observed = false; CreatureAI.Order od = br.tick(ob, 10); if (od.despawn) despawned = true; if (od.anim == null || !Anim.LIB.containsKey(od.anim)) check("ai anim valid " + id, false); }
            check("ai always despawns within bounded time (no leak) " + id, despawned); }
        CreatureAI.Brain g = CreatureAI.create("mask_giant", hc); CreatureAI.Obs go = new CreatureAI.Obs(); go.dist = 20; go.observed = true; go.sanity = 80; for (int i = 0; i < 4; i++) g.tick(go, 10); CreatureAI.Order og = g.tick(go, 10); check("giant frozen while watched", og.frozen && og.speed == 0);
        go.observed = false; og = g.tick(go, 10); check("giant moves when unwatched", !og.frozen && og.speed > 0);
        CreatureAI.Brain tn = CreatureAI.create("turner", hc); CreatureAI.Obs to = new CreatureAI.Obs(); to.dist = 8; CreatureAI.Order ot = tn.tick(to, 10); check("turner spawns in FRONT", ot.spawnInFront); boolean behind = false; for (int i = 0; i < 20; i++) behind |= tn.tick(to, 10).spawnBehind; check("turner goes BEHIND", behind);
        CreatureAI.Brain pk = CreatureAI.create("horned_peeper", hc); CreatureAI.Obs po = new CreatureAI.Obs(); po.dist = 5; boolean dmg = false, knock = false, vanish = false; for (int i = 0; i < 200; i++) { if (i > 5) po.observed = i < 40; CreatureAI.Order op = pk.tick(po, 10); dmg |= op.melee; knock |= op.doKnock; vanish |= op.vanish; } check("peeper never damages, vanishes then knocks", !dmg && knock && vanish);
        CreatureAI.Brain fl = CreatureAI.create("follower", hc); CreatureAI.Obs fo = new CreatureAI.Obs(); fo.dist = 6; fo.sanity = 90; fo.targetStopped = false; boolean f1a = fl.tick(fo, 10).footstepsAudible; fo.targetStopped = true; CreatureAI.Order f2 = fl.tick(fo, 10); check("follower footsteps stop when player stops", f1a && !f2.footstepsAudible && f2.speed == 0);
        CreatureAI.Brain cc = CreatureAI.create("cave_colossus", hc); CreatureAI.Obs co = new CreatureAI.Obs(); co.targetInCave = true; co.dist = 30; co.sanity = 90; CreatureAI.Order c1 = cc.tick(co, 10); check("colossus shadow first (rumble, steps, not hunting)", c1.footstepsAudible && "rumble".equals(c1.sound) && c1.speed == 0);
        CreatureAI.Brain dk = CreatureAI.create("rotted_skull", hc); CreatureAI.Obs dko = new CreatureAI.Obs(); dko.targetLight = true; dko.dist = 5; boolean ab = false; for (int i = 0; i < 10; i++) ab |= dk.tick(dko, 10).vanish; check("light is counterplay (skull flees)", ab);
        CreatureAI.Brain ck = CreatureAI.create("mask_giant", hc); CreatureAI.Obs ko = new CreatureAI.Obs(); ko.dist = 1.5; ko.sanity = 10; boolean kill = false; for (int i = 0; i < 40; i++) { CreatureAI.Order ok = ck.tick(ko, 10); kill |= ok.cinematicKill; } check("giant cinematic kill on catch", kill);
        // PlayerStore
        java.nio.file.Path dir = java.nio.file.Files.createTempDirectory("hwstore"); UUID uid = UUID.randomUUID(); PlayerStore.Data pd = new PlayerStore.Data(); pd.sanity = 33.5f; pd.encounters = 4; check("store save", PlayerStore.save(dir, uid, pd)); PlayerStore.Data ld = PlayerStore.load(dir, uid); check("store roundtrip", ld.sanity == 33.5f && ld.encounters == 4);
        check("store migrates v1", PlayerStore.parse("version=1\nsanity=40\n").personalIntensity == 1f && PlayerStore.parse("version=1\nsanity=40\n").sanity == 40f); check("store corrupt -> defaults", PlayerStore.parse("\u0000garbage==\n sanity=abc").sanity == 100f);
        check("store clamps hostile values", PlayerStore.parse("sanity=99999\nencounters=-5\npersonalIntensity=NaN").sanity == 100f && PlayerStore.parse("encounters=-5").encounters == 0); check("store missing file -> defaults", PlayerStore.load(dir, UUID.randomUUID()).sanity == 100f);
        // Mirage + items
        Mirage mg = new Mirage(1, Quality.MEDIUM); Sanity lo = new Sanity(); lo.set(5); int evs = 0; boolean anyDmg = false; for (int i = 0; i < 600; i++) { Mirage.Event e = mg.tick(lo, true); if (e != null) { evs++; anyDmg |= Mirage.damages(e); } } check("mirages occur at low sanity, never damage", evs > 5 && evs < 200 && !anyDmg);
        Mirage m2 = new Mirage(1, Quality.MEDIUM); Sanity hi = new Sanity(); int e2 = 0; for (int i = 0; i < 600; i++) if (m2.tick(hi, true) != null) e2++; check("no mirages at full sanity", e2 == 0);
        Sanity ts = new Sanity(); ts.set(20); long cd = Items.useTonic(ts, 100, 0); check("tonic +30 and cooldown", ts.get() == 50f && cd > 100); Items.useTonic(ts, 200, cd); check("tonic cooldown blocks", ts.get() == 50f);
        check("shard/ember drops", Items.SHARD.equals(Items.dropFor("pale_stalker", .1)) && Items.dropFor("pale_stalker", .9) == null && Items.EMBER.equals(Items.dropFor("charred_brute", .1)));

        // MeshBuilder
        float[] mc = MeshBuilder.cube(new float[]{4, 8, 2}, new float[]{-2, 0, -1}, new int[]{10, 20}, 2, 256, 256); boolean uvok = true, nrm = true; for (int v = 0; v < MeshBuilder.VERTS; v++) { float u = mc[v * 8 + 3], w2 = mc[v * 8 + 4]; uvok &= u >= 0 && u <= 1 && w2 >= 0 && w2 <= 1; float L = mc[v*8+5]*mc[v*8+5]+mc[v*8+6]*mc[v*8+6]+mc[v*8+7]*mc[v*8+7]; nrm &= Math.abs(L - 1) < 1e-4; }
        check("mesh 24 verts, uv in [0,1], unit normals", mc.length == 24 * 8 && uvok && nrm);
        check("mesh front face uv matches generator layout", Math.abs(mc[3] - (10 + 2 * 2) / 256f) < 1e-6 && Math.abs(mc[4] - (20 + 2 * 2) / 256f) < 1e-6 && Math.abs(mc[8 + 3] - (10 + 2 * 2 + 4 * 2) / 256f) < 1e-6);
        System.out.println("CoreTest: " + pass + " passed, " + fail + " failed"); System.exit(fail == 0 ? 0 : 1);
    }
}
